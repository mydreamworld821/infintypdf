# InfinityPDF - Web-Based PDF Processing Platform

## Overview

InfinityPDF (tagline: "Unlimited PDF Tools. One Powerful Platform.") is a full-stack web application providing 35 PDF tools across 7 categories: Page Management (merge, split, rotate, remove/reorder/organize pages), Conversion (office/Word/PPT/Excel to/from PDF, OCR, PDF to JPG, image to PDF), Editing (watermark, edit, sign, redact, PDF filler), Optimize (compress, repair, PDF/A), Security (unlock, protect), Organize (page numbers, copy, crop), and Advanced (compare, HTML to PDF, scan to PDF, workflow). 13 tools are marked as premium (OCR variants, watermark, edit, sign, redact, filler, PDF/A, crop, compare, web-to-pdf, workflow). The app uses React SPA frontend served by Express backend, with server-side processing via pdf-lib, Puppeteer/Chromium, poppler, tesseract, ghostscript, and qpdf.

## User Preferences

Preferred communication style: Simple, everyday language.

## System Architecture

### Frontend
- **Framework**: React 18 with TypeScript, bundled by Vite
- **Routing**: Wouter (lightweight client-side router) — routes include `/`, `/tool/:id`, `/auth`, `/admin`, `/dashboard`, `/features`, `/pricing`, `/faq`, `/security`, `/privacy`, `/terms`, `/cookies`, `/about`, `/contact`, `/blog`, `/press`, `/solutions`, and a 404 catch-all
- **State Management**: TanStack React Query for server state (auth, API calls); React Context for theme
- **UI Components**: shadcn/ui (New York style) built on Radix UI primitives with Tailwind CSS
- **Animations**: Framer Motion for page transitions and micro-interactions
- **Styling**: Tailwind CSS with CSS custom properties for theming (light/dark mode supported via class strategy)
- **Path aliases**: `@/` maps to `client/src/`, `@shared/` maps to `shared/`

### Backend
- **Runtime**: Node.js with Express, written in TypeScript and run via `tsx`
- **API Pattern**: REST endpoints under `/api/` prefix. PDF processing endpoint at `POST /api/pdf/process` accepts multipart file uploads via multer
- **PDF Processing**: `pdf-lib` library handles core PDF operations server-side (merge, split, rotate, compress, watermark, page numbers, unlock). Puppeteer/Chromium handles HTML-to-PDF conversion. Files are saved to `uploads/` and `outputs/` directories on disk
- **File Handling**: Multer with disk storage, 50MB file size limit, supports up to 30 files per request
- **Build**: Custom build script (`script/build.ts`) uses Vite for client and esbuild for server, outputting to `dist/`

### Authentication
- **Method**: Standalone email/password authentication with bcryptjs password hashing (12 salt rounds)
- **Sessions**: Server-side sessions stored in PostgreSQL via `connect-pg-simple`, with a 1-week TTL
- **User Storage**: Users are created on registration with `id` (UUID), `email`, `firstName`, `lastName`, `passwordHash`
- **Auth Routes**: `GET /api/auth/user` (current user or 401), `POST /api/auth/register`, `POST /api/auth/login`, `POST /api/auth/logout`
- **Password Requirements**: Minimum 8 characters, requires uppercase, lowercase, number, and special character
- **Session Middleware**: `setupAuth()` in `replitAuth.ts` attaches session middleware and loads `req.user` from DB on every request
- **Auth files are in**: `server/replit_integrations/auth/`

### Database
- **Database**: PostgreSQL (required, connection via `DATABASE_URL` environment variable)
- **ORM**: Drizzle ORM with `drizzle-kit` for schema management
- **Schema location**: `shared/schema.ts` which re-exports from `shared/models/auth.ts`
- **Tables**: `sessions` (for express-session storage), `users` (with premium status, admin flag, and password hash), `pdf_jobs` (file processing history), `orders` (payment orders with admin approval workflow)
- **Push command**: `npm run db:push` to sync schema to database

### Project Structure
```
client/              # React frontend
  src/
    components/      # UI components (shadcn/ui + custom)
      app-header.tsx # Header with nav, auth controls, mega dropdown
      app-footer.tsx # Footer with links
      theme-provider.tsx # Dark/light theme context
    hooks/           # Custom React hooks (use-auth, use-toast, use-mobile)
    lib/             # Utilities, API client, PDF tool definitions
      pdf-tools.ts   # 35 tool definitions + detailed tool descriptions
      queryClient.ts # TanStack Query client with default fetcher
      auth-utils.ts  # Auth utility functions
    pages/           # Page components
      landing.tsx    # Public landing page with tool grid
      dashboard.tsx  # Authenticated dashboard with tools, file history, billing
      tool-page.tsx  # Individual tool page with file upload, processing, download
      auth.tsx       # Sign In / Sign Up page
      admin.tsx      # Admin panel for order/user management
      features.tsx, pricing.tsx, faq.tsx, etc. # Static content pages
server/              # Express backend
  index.ts           # Server entry point
  routes.ts          # API route registration (PDF processing, orders, admin, jobs)
  pdf-processor.ts   # PDF manipulation logic (35 tool implementations)
  storage.ts         # Database storage layer (IStorage interface)
  db.ts              # Drizzle database connection
  vite.ts            # Vite dev server middleware
  static.ts          # Production static file serving
  replit_integrations/auth/
    index.ts         # Auth exports
    replitAuth.ts    # Session setup + user-loading middleware
    routes.ts        # Register/login/logout/user API routes
    storage.ts       # Auth-specific DB operations
shared/              # Shared types and schemas
  schema.ts          # Main schema export
  models/auth.ts     # User, session, pdf_jobs, orders table definitions + types
```

### Key Design Decisions
- **PDF tool registry**: All 35 tools are defined as data in `client/src/lib/pdf-tools.ts` with metadata (id, name, category, premium status, icon, color, acceptMultiple, acceptTypes). Detailed tool descriptions (headline, whatIs, whyUse, howItWorks, security, useCases) are also in this file. This drives both the UI rendering and the processing logic
- **Free vs Premium**: Tools have an `isPremium` boolean flag. Premium tools are gated on both frontend (locked UI with upgrade prompt) and backend (403 response for non-premium users). Admin must manually approve orders to activate premium access
- **Payment Flow**: User submits order with payment reference -> Admin reviews in admin panel -> Admin approves -> User gets premium status "active"
- **Admin Panel**: Available at `/admin` route, only accessible to users with `isAdmin=true`. Manages orders and user premium status
- **File History**: All PDF processing jobs are recorded in `pdf_jobs` table for logged-in users, viewable in dashboard
- **File-based processing**: PDFs are temporarily saved to disk for processing rather than streaming in memory, which simplifies operations with `pdf-lib` but requires cleanup scheduling
- **Merge file limits**: Free users: 10 files, ad-unlock: 30 files, premium: unlimited
- **Drag-and-drop reordering**: Tool page supports HTML5 drag-and-drop for reordering uploaded files with visual feedback (number overlays, drag handles)
- **Monorepo structure**: Client, server, and shared code live in one repo with path aliases configured in both TypeScript and Vite

## External Dependencies

### Required Services
- **PostgreSQL**: Database for user accounts, sessions, jobs, and orders. Must have `DATABASE_URL` environment variable set
- **SESSION_SECRET**: Environment variable for signing session cookies (falls back to a default in development)

### Key NPM Packages
- **pdf-lib**: Core PDF manipulation library (merge, split, rotate, watermark, etc.)
- **bcryptjs**: Password hashing for authentication
- **drizzle-orm** + **drizzle-kit**: Database ORM and migration tooling
- **multer**: Multipart file upload handling
- **connect-pg-simple**: PostgreSQL session store
- **express-session**: Session management
- **puppeteer**: HTML-to-PDF conversion via Chromium
- **@tanstack/react-query**: Server state management
- **framer-motion**: Animations
- **pdfjs-dist**: Client-side PDF thumbnail rendering
- **shadcn/ui ecosystem**: Radix UI, class-variance-authority, tailwind-merge, clsx

## Recent Changes
- **2026-02-14**: Migrated from Replit OIDC to standalone email/password auth with bcryptjs
- **2026-02-14**: Fixed session race condition in auth.tsx (await invalidateQueries before navigate)
- **2026-02-14**: Removed duplicate user-loading middleware from routes.ts
- **2026-02-14**: Updated redirectToLogin to use /auth instead of /api/login
- **2026-02-14**: HTML-to-PDF tool uses Puppeteer/Chromium instead of LibreOffice
- **2026-02-14**: Added drag-and-drop file reordering with visual feedback
