import { Switch, Route } from "wouter";
import { queryClient } from "./lib/queryClient";
import { QueryClientProvider } from "@tanstack/react-query";
import { Toaster } from "@/components/ui/toaster";
import { TooltipProvider } from "@/components/ui/tooltip";
import { ThemeProvider } from "@/components/theme-provider";
import { AppHeader } from "@/components/app-header";
import { AppFooter } from "@/components/app-footer";
import { useAuth } from "@/hooks/use-auth";
import { getToolBySlug } from "@/lib/pdf-tools";
import LandingPage from "@/pages/landing";
import DashboardPage from "@/pages/dashboard";
import ToolPage from "@/pages/tool-page";
import FeaturesPage from "@/pages/features";
import PricingPage from "@/pages/pricing";
import FAQPage from "@/pages/faq";
import SecurityPage from "@/pages/security";
import PrivacyPolicyPage from "@/pages/privacy-policy";
import TermsPage from "@/pages/terms";
import CookiesPage from "@/pages/cookies";
import AboutPage from "@/pages/about";
import ContactPage from "@/pages/contact";
import BlogPage from "@/pages/blog";
import PressPage from "@/pages/press";
import SolutionsPage from "@/pages/solutions";
import AuthPage from "@/pages/auth";
import AdminPage from "@/pages/admin";
import NotFound from "@/pages/not-found";

function HomePage() {
  const { isAuthenticated, isLoading } = useAuth();

  if (isLoading) {
    return (
      <div className="flex min-h-[60vh] items-center justify-center">
        <div className="h-8 w-8 animate-spin rounded-full border-2 border-primary border-t-transparent" />
      </div>
    );
  }

  return isAuthenticated ? <DashboardPage /> : <LandingPage />;
}

function Router() {
  return (
    <Switch>
      <Route path="/" component={HomePage} />
      <Route path="/dashboard" component={DashboardPage} />
      <Route path="/tool/:id" component={ToolPage} />
      <Route path="/features" component={FeaturesPage} />
      <Route path="/pricing" component={PricingPage} />
      <Route path="/faq" component={FAQPage} />
      <Route path="/security" component={SecurityPage} />
      <Route path="/privacy" component={PrivacyPolicyPage} />
      <Route path="/terms" component={TermsPage} />
      <Route path="/cookies" component={CookiesPage} />
      <Route path="/about" component={AboutPage} />
      <Route path="/contact" component={ContactPage} />
      <Route path="/blog" component={BlogPage} />
      <Route path="/press" component={PressPage} />
      <Route path="/solutions" component={SolutionsPage} />
      <Route path="/auth" component={AuthPage} />
      <Route path="/admin" component={AdminPage} />
      <Route path="/:slug">{(params) => {
        const tool = getToolBySlug(params.slug);
        if (tool) return <ToolPage />;
        return <NotFound />;
      }}</Route>
      <Route component={NotFound} />
    </Switch>
  );
}

function App() {
  return (
    <QueryClientProvider client={queryClient}>
      <ThemeProvider>
        <TooltipProvider>
          <div className="min-h-screen bg-background text-foreground flex flex-col">
            <AppHeader />
            <main className="flex-1">
              <Router />
            </main>
            <AppFooter />
          </div>
          <Toaster />
        </TooltipProvider>
      </ThemeProvider>
    </QueryClientProvider>
  );
}

export default App;
