import { useState } from "react";
import { Button } from "@/components/ui/button";
import { Card } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { PDF_TOOLS, PDF_CATEGORIES, getToolsByCategory } from "@/lib/pdf-tools";
import { motion } from "framer-motion";
import {
  FileText, Merge, Scissors, RotateCw, Hash, FileDown, Stamp,
  Unlock, GitCompare, Crop, EyeOff, Lock, Globe, ScanText,
  ArrowRight, Shield, Zap, Cloud, Layers, ArrowRightLeft, Pencil,
  Gauge, FolderOpen, CheckCircle2,
  FileX2, ArrowUpDown, LayoutGrid, FileSpreadsheet, FileType,
  Presentation, Table, PenLine, PenTool, Archive,
  Wrench, Copy, ScanLine, Workflow, ImagePlus,
  Image as ImageIcon, ClipboardEdit, Sparkles, Clock, Trash2,
  Star, Users, Monitor,
} from "lucide-react";

const iconMap: Record<string, any> = {
  Merge, Scissors, RotateCw, Hash, FileDown, Stamp, ImageIcon,
  Unlock, GitCompare, Crop, EyeOff, Lock, Globe, ScanText,
  Layers, ArrowRightLeft, Pencil, Gauge, Shield, FolderOpen,
  FileX2, ArrowUpDown, LayoutGrid, FileSpreadsheet, FileType,
  Presentation, Table, PenLine, PenTool, Archive,
  Wrench, Copy, ScanLine, Workflow, ImagePlus, ClipboardEdit, Sparkles,
};

const fadeUp = {
  hidden: { opacity: 0, y: 16 },
  visible: (i: number) => ({
    opacity: 1, y: 0,
    transition: { delay: i * 0.03, duration: 0.3, ease: "easeOut" },
  }),
};

const stagger = {
  visible: { transition: { staggerChildren: 0.04 } },
};

export default function LandingPage() {
  const [activeCategory, setActiveCategory] = useState<string>("all");
  const totalToolCount = PDF_TOOLS.length;

  const filteredTools = activeCategory === "all"
    ? PDF_TOOLS
    : PDF_TOOLS.filter((t) => t.category === activeCategory);

  return (
    <div className="min-h-screen">
      <section className="py-14 sm:py-20">
        <div className="mx-auto max-w-4xl px-4 sm:px-6 text-center">
          <motion.h1
            className="font-serif text-3xl font-bold tracking-tight sm:text-4xl lg:text-5xl"
            initial={{ opacity: 0, y: 16 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.4 }}
            data-testid="text-hero-title"
          >
            Unlimited Online PDF Tools &ndash; Fast, Secure & Easy
          </motion.h1>

          <motion.p
            className="mx-auto mt-4 max-w-2xl text-muted-foreground text-base sm:text-lg"
            initial={{ opacity: 0, y: 12 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.4, delay: 0.1 }}
            data-testid="text-hero-subtitle"
          >
            Welcome to InfinityPDF, your all-in-one platform for powerful and secure PDF tools.
            Merge, split, compress, convert, edit, compare and secure PDF files instantly.
            No software installation required.
          </motion.p>

          <motion.div
            className="mt-6 flex items-center justify-center gap-3 flex-wrap"
            initial={{ opacity: 0, y: 12 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.4, delay: 0.2 }}
          >
            <Button size="lg" asChild data-testid="button-hero-get-started">
              <a href="/auth">
                Get Started Free
                <ArrowRight className="ml-2 h-4 w-4" />
              </a>
            </Button>
            <Button size="lg" variant="outline" asChild data-testid="button-hero-browse-tools">
              <a href="#tools">
                Browse {totalToolCount} Tools
              </a>
            </Button>
          </motion.div>
        </div>
      </section>

      <section className="pb-10 sm:pb-14">
        <div className="mx-auto max-w-7xl px-4 sm:px-6">
          <motion.h2
            className="text-center text-2xl font-bold sm:text-3xl mb-3"
            initial={{ opacity: 0, y: 12 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.4, delay: 0.12 }}
          >
            Popular PDF Tools
          </motion.h2>
          <motion.p
            className="text-center text-muted-foreground mb-8 max-w-xl mx-auto"
            initial={{ opacity: 0, y: 12 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.4, delay: 0.14 }}
          >
            Whether you need to merge PDF files, split documents, compress large PDFs, or convert files &ndash; InfinityPDF makes it simple.
          </motion.p>
          <div className="grid gap-4 sm:grid-cols-2 lg:grid-cols-4">
            {[
              { id: "merge", title: "Merge PDF Online", desc: "Combine multiple PDF files into one single document in seconds. Maintain quality and structure while organizing pages the way you want." },
              { id: "split", title: "Split PDF Files", desc: "Extract specific pages or divide large PDFs into smaller documents quickly and easily." },
              { id: "compress", title: "Compress PDF", desc: "Reduce PDF file size without losing quality. Perfect for email attachments and faster uploads." },
              { id: "pdf-to-word", title: "PDF to Word Converter", desc: "Convert PDF documents into fully editable Word files with high accuracy and preserved formatting." },
            ].map((item, i) => {
              const tool = PDF_TOOLS.find(t => t.id === item.id);
              const ToolIcon = tool ? iconMap[tool.icon] : FileText;
              return (
                <motion.div key={item.id} initial={{ opacity: 0, y: 16 }} animate={{ opacity: 1, y: 0 }} transition={{ delay: 0.15 + i * 0.05 }}>
                  <a href={`/${tool?.slug || item.id}`} data-testid={`card-popular-${item.id}`}>
                    <Card className="p-5 h-full hover-elevate cursor-pointer">
                      <div className="flex items-start gap-3">
                        <div
                          className="flex h-10 w-10 shrink-0 items-center justify-center rounded-md"
                          style={{ backgroundColor: tool ? `hsl(${tool.color} / 0.1)` : undefined }}
                        >
                          {ToolIcon && <ToolIcon className="h-5 w-5" style={{ color: tool ? `hsl(${tool.color})` : undefined }} />}
                        </div>
                        <div>
                          <h3 className="text-sm font-semibold mb-1">{item.title}</h3>
                          <p className="text-xs text-muted-foreground leading-relaxed">{item.desc}</p>
                        </div>
                      </div>
                    </Card>
                  </a>
                </motion.div>
              );
            })}
          </div>
        </div>
      </section>

      <section id="tools" className="pb-16 sm:pb-24">
        <div className="mx-auto max-w-7xl px-4 sm:px-6">
          <h2 className="text-center text-2xl font-bold sm:text-3xl mb-2">All PDF Tools</h2>
          <p className="text-center text-muted-foreground mb-8">
            {totalToolCount} tools across {PDF_CATEGORIES.length} categories to handle any PDF task
          </p>
          <motion.div
            className="flex flex-wrap items-center justify-center gap-2 mb-10"
            initial={{ opacity: 0, y: 12 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.4, delay: 0.15 }}
            data-testid="category-filters"
          >
            <Button
              variant={activeCategory === "all" ? "default" : "outline"}
              size="sm"
              onClick={() => setActiveCategory("all")}
              className="rounded-full"
              data-testid="filter-all"
            >
              All
            </Button>
            {PDF_CATEGORIES.map((cat) => (
              <Button
                key={cat.id}
                variant={activeCategory === cat.id ? "default" : "outline"}
                size="sm"
                onClick={() => setActiveCategory(cat.id)}
                className="rounded-full"
                data-testid={`filter-${cat.id}`}
              >
                {cat.name}
              </Button>
            ))}
          </motion.div>

          <motion.div
            className="grid gap-4 sm:grid-cols-2 md:grid-cols-3 lg:grid-cols-4 xl:grid-cols-6"
            initial="hidden"
            animate="visible"
            variants={stagger}
            key={activeCategory}
            data-testid="tools-grid"
          >
            {filteredTools.map((tool, i) => {
              const ToolIcon = iconMap[tool.icon];
              return (
                <motion.div key={tool.id} variants={fadeUp} custom={i}>
                  <a href={`/${tool.slug}`} data-testid={`card-tool-${tool.id}`}>
                    <Card className="group p-5 h-full hover-elevate cursor-pointer">
                      <div className="flex flex-col items-center text-center">
                        <div
                          className="flex h-14 w-14 items-center justify-center rounded-md mb-3"
                          style={{ backgroundColor: `hsl(${tool.color} / 0.1)` }}
                        >
                          {ToolIcon && (
                            <ToolIcon
                              className="h-7 w-7"
                              style={{ color: `hsl(${tool.color})` }}
                            />
                          )}
                        </div>
                        <h3 className="text-sm font-semibold mb-1" data-testid={`text-tool-title-${tool.id}`}>
                          {tool.name}
                        </h3>
                        <p className="text-xs text-muted-foreground leading-relaxed">
                          {tool.description}
                        </p>
                      </div>
                    </Card>
                  </a>
                </motion.div>
              );
            })}
          </motion.div>
        </div>
      </section>

      <section className="py-14 sm:py-20 bg-card/50">
        <div className="mx-auto max-w-7xl px-4 sm:px-6">
          <h2 className="text-center text-2xl font-bold sm:text-3xl mb-3">Why Choose InfinityPDF?</h2>
          <p className="text-center text-muted-foreground mb-10 max-w-xl mx-auto">
            InfinityPDF is built with performance, privacy, and simplicity in mind.
            Designed for students, professionals, businesses, and developers.
          </p>
          <motion.div
            className="grid gap-6 sm:grid-cols-2 lg:grid-cols-3"
            initial="hidden"
            whileInView="visible"
            viewport={{ once: true, margin: "-100px" }}
            variants={stagger}
          >
            {[
              {
                icon: Zap,
                title: "Fast Cloud Processing",
                description: "Process your PDFs in seconds with our optimized cloud-based engine. No waiting, no delays.",
              },
              {
                icon: Shield,
                title: "Secure & Private",
                description: "Your files are processed securely with encryption. All uploads are automatically deleted after processing.",
              },
              {
                icon: Monitor,
                title: "No Software Required",
                description: "Works on any device with a modern web browser. No downloads, no installations needed.",
              },
              {
                icon: Clock,
                title: "Auto File Deletion",
                description: "All uploaded files are automatically deleted after processing. Your documents stay private.",
              },
              {
                icon: Users,
                title: "User-Friendly Interface",
                description: "Clean, intuitive design that makes PDF processing accessible to everyone, regardless of technical skill.",
              },
              {
                icon: Star,
                title: "Free & Premium Plans",
                description: "Access essential tools for free. Upgrade to Premium for advanced features like OCR, editing, and comparison.",
              },
            ].map((feature, i) => (
              <motion.div key={feature.title} variants={fadeUp} custom={i}>
                <Card className="p-6">
                  <div className="mb-4 flex h-10 w-10 items-center justify-center rounded-md bg-primary/10">
                    <feature.icon className="h-5 w-5 text-primary" />
                  </div>
                  <h3 className="text-lg font-semibold">{feature.title}</h3>
                  <p className="mt-2 text-sm text-muted-foreground leading-relaxed">{feature.description}</p>
                </Card>
              </motion.div>
            ))}
          </motion.div>
        </div>
      </section>

      <section className="py-14 sm:py-20">
        <div className="mx-auto max-w-7xl px-4 sm:px-6">
          <div className="grid gap-8 lg:grid-cols-2 items-center">
            <div>
              <h2 className="text-2xl font-bold sm:text-3xl mb-4">Secure & Private PDF Processing</h2>
              <p className="text-muted-foreground leading-relaxed mb-4">
                Your privacy is our priority. All files uploaded to InfinityPDF are securely processed and automatically deleted after a short time.
                We never store, sell, or share your documents.
              </p>
              <ul className="space-y-3">
                {[
                  "Encrypted file transfer and processing",
                  "Automatic file deletion after processing",
                  "No third-party access to your documents",
                  "Secure cloud infrastructure",
                ].map((item) => (
                  <li key={item} className="flex items-center gap-2 text-sm">
                    <CheckCircle2 className="h-4 w-4 text-primary shrink-0" />
                    <span>{item}</span>
                  </li>
                ))}
              </ul>
            </div>
            <Card className="p-8 text-center">
              <Shield className="h-16 w-16 text-primary mx-auto mb-4 opacity-80" />
              <h3 className="text-xl font-semibold mb-2">Your Files Are Safe</h3>
              <p className="text-sm text-muted-foreground">
                All documents are processed in an isolated environment and permanently removed after completion.
              </p>
            </Card>
          </div>
        </div>
      </section>

      <section className="py-14 sm:py-20 bg-card/50">
        <div className="mx-auto max-w-7xl px-4 sm:px-6">
          <Card className="relative overflow-visible p-8 sm:p-12 text-center">
            <div className="absolute inset-0 -z-10 rounded-md bg-gradient-to-br from-primary/5 to-accent/5" />
            <h2 className="font-serif text-2xl font-bold sm:text-3xl">
              Upgrade to InfinityPDF Premium
            </h2>
            <p className="mx-auto mt-3 max-w-lg text-muted-foreground">
              Unlock advanced tools including Edit PDF, Compare PDF, HTML to PDF, OCR, Redact PDF,
              and enjoy unlimited access with faster processing.
            </p>
            <div className="flex flex-wrap justify-center gap-2 mt-6">
              {["Edit PDF", "Compare PDF", "HTML to PDF", "OCR PDF", "Redact PDF", "Unlimited Access", "Faster Processing"].map((item) => (
                <Badge key={item} variant="secondary">{item}</Badge>
              ))}
            </div>
            <div className="mt-8">
              <Button size="lg" asChild data-testid="button-cta-upgrade">
                <a href="/pricing">
                  View Premium Plans
                  <ArrowRight className="ml-2 h-4 w-4" />
                </a>
              </Button>
            </div>
          </Card>
        </div>
      </section>

      <section className="py-14 sm:py-20">
        <div className="mx-auto max-w-7xl px-4 sm:px-6">
          <Card className="relative overflow-visible p-8 sm:p-12 text-center">
            <div className="absolute inset-0 -z-10 rounded-md bg-gradient-to-br from-primary/5 to-accent/5" />
            <h2 className="font-serif text-2xl font-bold sm:text-3xl">
              Ready to Get Started?
            </h2>
            <p className="mx-auto mt-3 max-w-md text-muted-foreground">
              Sign up for free and start processing your PDFs instantly.
              No credit card required.
            </p>
            <div className="mt-8">
              <Button size="lg" asChild data-testid="button-cta-signup">
                <a href="/auth">
                  Create Free Account
                  <ArrowRight className="ml-2 h-4 w-4" />
                </a>
              </Button>
            </div>
          </Card>
        </div>
      </section>
    </div>
  );
}
