import { Badge } from "@/components/ui/badge";

export default function PrivacyPolicyPage() {
  return (
    <div className="min-h-screen py-16">
      <div className="mx-auto max-w-3xl px-4 sm:px-6">
        <div className="text-center mb-12">
          <Badge variant="secondary" className="mb-4" data-testid="badge-privacy">Legal</Badge>
          <h1 className="font-serif text-3xl font-bold sm:text-4xl" data-testid="text-privacy-title">
            Privacy Policy
          </h1>
          <p className="text-lg text-muted-foreground mt-2">InfinityPDF – Unlimited PDF Tools. One Powerful Platform.</p>
          <p className="text-muted-foreground mt-2 text-sm">Last updated: {new Date().toLocaleDateString("en-US", { month: "long", day: "numeric", year: "numeric" })}</p>
        </div>

        <p className="text-sm text-muted-foreground leading-relaxed mb-8">
          At <span className="font-medium text-foreground">InfinityPDF</span>, we value your privacy and are committed to protecting your personal information. This Privacy Policy explains how we collect, use, store, and safeguard your data when you use our website and services.
        </p>

        <div className="space-y-8 text-sm text-muted-foreground leading-relaxed">
          <section>
            <h2 className="font-serif text-lg font-semibold text-foreground mb-3" data-testid="section-info-collect">1. Information We Collect</h2>
            <p className="mb-3">We may collect the following types of information:</p>

            <h3 className="font-medium text-foreground mb-2">Personal Information</h3>
            <ul className="list-disc list-inside space-y-1 mb-4 pl-2">
              <li>Name</li>
              <li>Email address</li>
              <li>Payment details (processed securely via third-party payment providers)</li>
              <li>Account login credentials</li>
            </ul>

            <h3 className="font-medium text-foreground mb-2">Usage Information</h3>
            <ul className="list-disc list-inside space-y-1 mb-4 pl-2">
              <li>IP address</li>
              <li>Browser type and device information</li>
              <li>Pages visited and tools used</li>
              <li>Upload/download activity logs</li>
            </ul>

            <h3 className="font-medium text-foreground mb-2">Uploaded Files</h3>
            <ul className="list-disc list-inside space-y-1 pl-2">
              <li>PDF and document files you upload for processing</li>
            </ul>
          </section>

          <section>
            <h2 className="font-serif text-lg font-semibold text-foreground mb-3" data-testid="section-how-use">2. How We Use Your Information</h2>
            <p className="mb-2">We use your information to:</p>
            <ul className="list-disc list-inside space-y-1 pl-2">
              <li>Provide and operate our PDF tools</li>
              <li>Process payments and manage subscriptions</li>
              <li>Improve website performance and user experience</li>
              <li>Communicate updates, support, and account notifications</li>
              <li>Prevent fraud and unauthorized access</li>
            </ul>
          </section>

          <section>
            <h2 className="font-serif text-lg font-semibold text-foreground mb-3" data-testid="section-file-privacy">3. File Privacy & Security</h2>
            <p className="mb-2">Your uploaded files are:</p>
            <ul className="list-disc list-inside space-y-1 mb-4 pl-2">
              <li>Processed securely</li>
              <li>Automatically deleted from our servers after a limited time (e.g., 24 hours)</li>
              <li>Never accessed manually unless required for technical support</li>
            </ul>
            <p>We do <span className="font-medium text-foreground">not</span> sell, share, or distribute your documents.</p>
          </section>

          <section>
            <h2 className="font-serif text-lg font-semibold text-foreground mb-3" data-testid="section-payment">4. Payment Security</h2>
            <p>All payments are processed through trusted third-party payment providers (e.g., Stripe, PayPal, Razorpay). We do <span className="font-medium text-foreground">not store your full credit/debit card details</span> on our servers.</p>
          </section>

          <section>
            <h2 className="font-serif text-lg font-semibold text-foreground mb-3" data-testid="section-cookies">5. Cookies & Tracking Technologies</h2>
            <p className="mb-2">InfinityPDF may use cookies to:</p>
            <ul className="list-disc list-inside space-y-1 mb-4 pl-2">
              <li>Keep you logged in</li>
              <li>Remember preferences</li>
              <li>Analyze website traffic</li>
              <li>Improve functionality</li>
            </ul>
            <p>You may disable cookies in your browser settings, though some features may not work properly.</p>
          </section>

          <section>
            <h2 className="font-serif text-lg font-semibold text-foreground mb-3" data-testid="section-data-protection">6. Data Protection</h2>
            <p className="mb-2">We implement:</p>
            <ul className="list-disc list-inside space-y-1 mb-4 pl-2">
              <li>SSL encryption (HTTPS)</li>
              <li>Secure authentication systems</li>
              <li>Regular security monitoring</li>
            </ul>
            <p>However, no system is 100% secure. We continuously work to maintain strong security standards.</p>
          </section>

          <section>
            <h2 className="font-serif text-lg font-semibold text-foreground mb-3" data-testid="section-third-party">7. Third-Party Services</h2>
            <p className="mb-2">We may use third-party services for:</p>
            <ul className="list-disc list-inside space-y-1 mb-4 pl-2">
              <li>Payment processing</li>
              <li>Analytics</li>
              <li>Cloud storage</li>
              <li>Authentication</li>
            </ul>
            <p>These providers have their own privacy policies.</p>
          </section>

          <section>
            <h2 className="font-serif text-lg font-semibold text-foreground mb-3" data-testid="section-premium">8. Premium Features & Accounts</h2>
            <p className="mb-2">If you subscribe to premium features:</p>
            <ul className="list-disc list-inside space-y-1 pl-2">
              <li>Your account status will be stored securely</li>
              <li>Subscription data is managed through our payment provider</li>
              <li>You may cancel according to our Terms & Conditions</li>
            </ul>
          </section>

          <section>
            <h2 className="font-serif text-lg font-semibold text-foreground mb-3" data-testid="section-rights">9. Your Rights</h2>
            <p className="mb-2">Depending on your location, you may have the right to:</p>
            <ul className="list-disc list-inside space-y-1 mb-4 pl-2">
              <li>Access your personal data</li>
              <li>Request correction of inaccurate data</li>
              <li>Request deletion of your account</li>
              <li>Withdraw consent</li>
            </ul>
            <p>To exercise these rights, contact us through our <a href="/contact" className="underline font-medium text-foreground" data-testid="link-contact-rights">Contact page</a>.</p>
          </section>

          <section>
            <h2 className="font-serif text-lg font-semibold text-foreground mb-3" data-testid="section-children">10. Children's Privacy</h2>
            <p>InfinityPDF does not knowingly collect personal data from children under 13 years of age.</p>
          </section>

          <section>
            <h2 className="font-serif text-lg font-semibold text-foreground mb-3" data-testid="section-changes">11. Changes to This Policy</h2>
            <p>We may update this Privacy Policy periodically. Any changes will be posted on this page with an updated revision date.</p>
          </section>

          <section>
            <h2 className="font-serif text-lg font-semibold text-foreground mb-3" data-testid="section-contact">12. Contact Us</h2>
            <p>If you have any questions about this Privacy Policy, please contact us through our <a href="/contact" className="underline font-medium text-foreground" data-testid="link-contact-us">Contact page</a>.</p>
          </section>
        </div>
      </div>
    </div>
  );
}
