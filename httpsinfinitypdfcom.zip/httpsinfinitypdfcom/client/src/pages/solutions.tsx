import { Badge } from "@/components/ui/badge";
import { Card } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Briefcase, GraduationCap, ArrowRight, CheckCircle2 } from "lucide-react";

const solutions = [
  {
    icon: Briefcase,
    title: "Business",
    slug: "business",
    description: "Streamline your business document workflows with InfinityPDF.",
    benefits: [
      "Merge contracts and agreements into single documents",
      "Protect sensitive business documents with encryption",
      "Convert between PDF and Office formats seamlessly",
      "Add watermarks to confidential documents",
      "Compress large files for easy email sharing",
      "Redact sensitive information before sharing",
    ],
  },
  {
    icon: GraduationCap,
    title: "Education",
    slug: "education",
    description: "Help students and educators manage academic documents effortlessly.",
    benefits: [
      "Merge lecture notes and study materials",
      "Convert assignments between Word and PDF",
      "Add page numbers to research papers",
      "Compress large academic papers for submission",
      "Split textbook chapters for focused study",
      "OCR scanned handwritten notes into searchable text",
    ],
  },
];

export default function SolutionsPage() {
  return (
    <div className="min-h-screen py-16">
      <div className="mx-auto max-w-5xl px-4 sm:px-6">
        <div className="text-center mb-12">
          <Badge variant="secondary" className="mb-4" data-testid="badge-solutions">Solutions</Badge>
          <h1 className="font-serif text-3xl font-bold sm:text-4xl" data-testid="text-solutions-title">
            InfinityPDF for Every Need
          </h1>
          <p className="mx-auto mt-4 max-w-xl text-muted-foreground">
            Discover how InfinityPDF can help in your specific field.
          </p>
        </div>

        <div className="grid gap-8 md:grid-cols-2">
          {solutions.map((solution) => (
            <Card key={solution.slug} className="p-8" data-testid={`card-solution-${solution.slug}`}>
              <div className="flex items-center gap-3 mb-4">
                <div className="flex h-10 w-10 items-center justify-center rounded-md bg-primary/10">
                  <solution.icon className="h-5 w-5 text-primary" />
                </div>
                <h2 className="font-serif text-xl font-bold">{solution.title}</h2>
              </div>
              <p className="text-muted-foreground mb-6">{solution.description}</p>
              <div className="space-y-3 mb-6">
                {solution.benefits.map((benefit) => (
                  <div key={benefit} className="flex items-start gap-2">
                    <CheckCircle2 className="h-4 w-4 text-green-500 mt-0.5 shrink-0" />
                    <span className="text-sm">{benefit}</span>
                  </div>
                ))}
              </div>
              <Button variant="outline" asChild data-testid={`button-explore-${solution.slug}`}>
                <a href="/">
                  Explore Tools
                  <ArrowRight className="ml-2 h-4 w-4" />
                </a>
              </Button>
            </Card>
          ))}
        </div>
      </div>
    </div>
  );
}
