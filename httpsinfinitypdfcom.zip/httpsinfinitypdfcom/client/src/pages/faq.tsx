import { Badge } from "@/components/ui/badge";

const faqs = [
  {
    question: "Is InfinityPDF really free?",
    answer: "Yes, all 35 PDF tools are completely free to use with no hidden charges, subscriptions, or premium tiers.",
  },
  {
    question: "Do I need to create an account?",
    answer: "You can use all tools without creating an account. Signing in lets you access your processing history and preferences.",
  },
  {
    question: "What is the maximum file size?",
    answer: "You can upload PDF files up to 50MB in size. For most documents, this is more than sufficient.",
  },
  {
    question: "Are my files secure?",
    answer: "Yes. Files are processed on our secure servers and automatically deleted after processing. We never store or share your files.",
  },
  {
    question: "What file formats are supported for conversion?",
    answer: "We support conversion between PDF and Word (.docx), Excel (.xlsx), PowerPoint (.pptx), JPG/PNG images, and more.",
  },
  {
    question: "Can I merge multiple PDFs at once?",
    answer: "Yes, our merge tool supports combining up to 20 PDF files in a single operation. Simply upload all your files and arrange them in your preferred order.",
  },
  {
    question: "Does the OCR tool support multiple languages?",
    answer: "Our OCR tool uses Tesseract engine which supports English text recognition. The extracted text is embedded into the PDF for searchability.",
  },
  {
    question: "How does the Protect PDF tool work?",
    answer: "The Protect tool encrypts your PDF with a password using AES-256 encryption. Anyone who wants to open the file will need the password you set.",
  },
  {
    question: "Can I use InfinityPDF on mobile devices?",
    answer: "Yes, InfinityPDF works in any modern web browser including mobile browsers on iOS and Android devices.",
  },
  {
    question: "What happens to my files after processing?",
    answer: "All uploaded and processed files are automatically deleted from our servers shortly after processing is complete.",
  },
];

export default function FAQPage() {
  return (
    <div className="min-h-screen py-16">
      <div className="mx-auto max-w-3xl px-4 sm:px-6">
        <div className="text-center mb-12">
          <Badge variant="secondary" className="mb-4" data-testid="badge-faq">FAQ</Badge>
          <h1 className="font-serif text-3xl font-bold sm:text-4xl" data-testid="text-faq-title">
            Frequently Asked Questions
          </h1>
          <p className="mx-auto mt-4 max-w-xl text-muted-foreground">
            Find answers to common questions about InfinityPDF and how to use our platform.
          </p>
        </div>

        <div className="space-y-6">
          {faqs.map((faq, i) => (
            <div key={i} className="border-b pb-6 last:border-b-0" data-testid={`faq-item-${i}`}>
              <h3 className="font-semibold text-lg mb-2">{faq.question}</h3>
              <p className="text-muted-foreground text-sm leading-relaxed">{faq.answer}</p>
            </div>
          ))}
        </div>
      </div>
    </div>
  );
}
