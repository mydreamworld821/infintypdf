import { Card } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { getToolById } from "@/lib/pdf-tools";
import {
  Merge, Scissors, RotateCw, FileDown, Stamp, Unlock,
  Shield, Zap, Cloud, Layers, Globe, ScanText,
  FileText, Lock, Crop, EyeOff, Pencil, Hash,
} from "lucide-react";

const features = [
  {
    icon: Layers,
    title: "35 PDF Tools",
    description: "A complete suite covering merging, splitting, converting, editing, securing, and optimizing PDFs.",
  },
  {
    icon: Zap,
    title: "Fast Processing",
    description: "Server-side processing handles your files quickly so you can get back to work.",
  },
  {
    icon: Shield,
    title: "Secure & Private",
    description: "Your files are processed securely and automatically deleted after processing.",
  },
  {
    icon: Cloud,
    title: "No Installation",
    description: "Works entirely in your browser. No software to download or install.",
  },
  {
    icon: Globe,
    title: "Access Anywhere",
    description: "Use InfinityPDF from any device with a web browser, anytime, anywhere.",
  },
  {
    icon: FileText,
    title: "All Formats Supported",
    description: "Convert between PDF and Word, Excel, PowerPoint, images, and more.",
  },
];

const toolHighlights = [
  { icon: Merge, label: "Merge PDFs", id: "merge" },
  { icon: Scissors, label: "Split PDFs", id: "split" },
  { icon: RotateCw, label: "Rotate Pages", id: "rotate" },
  { icon: FileDown, label: "Compress", id: "compress" },
  { icon: Stamp, label: "Watermark", id: "watermark" },
  { icon: Unlock, label: "Unlock PDF", id: "unlock" },
  { icon: Lock, label: "Protect PDF", id: "protect" },
  { icon: Crop, label: "Crop Pages", id: "crop" },
  { icon: EyeOff, label: "Redact", id: "redact" },
  { icon: Pencil, label: "Edit PDF", id: "edit-pdf" },
  { icon: Hash, label: "Page Numbers", id: "page-numbers" },
  { icon: ScanText, label: "OCR", id: "ocr" },
];

export default function FeaturesPage() {
  return (
    <div className="min-h-screen py-16">
      <div className="mx-auto max-w-7xl px-4 sm:px-6">
        <div className="text-center mb-12">
          <Badge variant="secondary" className="mb-4" data-testid="badge-features">Features</Badge>
          <h1 className="font-serif text-3xl font-bold sm:text-4xl" data-testid="text-features-title">
            Everything You Need for PDF Management
          </h1>
          <p className="mx-auto mt-4 max-w-2xl text-muted-foreground">
            InfinityPDF provides a comprehensive set of tools to handle all your PDF needs,
            completely free and without any restrictions.
          </p>
        </div>

        <div className="grid gap-6 sm:grid-cols-2 lg:grid-cols-3 mb-16">
          {features.map((feature) => (
            <Card key={feature.title} className="p-6" data-testid={`card-feature-${feature.title.toLowerCase().replace(/\s+/g, "-")}`}>
              <div className="flex h-10 w-10 items-center justify-center rounded-md bg-primary/10 mb-4">
                <feature.icon className="h-5 w-5 text-primary" />
              </div>
              <h3 className="font-semibold text-lg mb-2">{feature.title}</h3>
              <p className="text-sm text-muted-foreground">{feature.description}</p>
            </Card>
          ))}
        </div>

        <div className="text-center mb-8">
          <h2 className="font-serif text-2xl font-bold sm:text-3xl">Popular Tools</h2>
          <p className="mt-3 text-muted-foreground">Quick access to our most-used PDF tools</p>
        </div>

        <div className="grid grid-cols-2 gap-3 sm:grid-cols-3 md:grid-cols-4 lg:grid-cols-6">
          {toolHighlights.map((tool) => (
            <a
              key={tool.id}
              href={`/${getToolById(tool.id)?.slug || tool.id}`}
              className="flex flex-col items-center gap-2 rounded-md border p-4 text-center hover-elevate"
              data-testid={`link-tool-${tool.id}`}
            >
              <tool.icon className="h-6 w-6 text-primary" />
              <span className="text-sm font-medium">{tool.label}</span>
            </a>
          ))}
        </div>
      </div>
    </div>
  );
}
