import { Badge } from "@/components/ui/badge";
import { Card } from "@/components/ui/card";
import {
  Shield, Lock, Trash2, Server, Globe, Cloud, HardDrive,
  KeyRound, Users, Fingerprint, ShieldCheck, CreditCard,
  Eye, RefreshCw, FileCheck, UserCheck
} from "lucide-react";

const privacyPrinciples = [
  { label: "Data Collection", text: "We collect only the information necessary for providing our services." },
  { label: "Data Security", text: "Your data is securely stored and protected." },
  { label: "Data Sharing", text: "We do not sell your data to third parties." },
  { label: "Cookies", text: "We use cookies to enhance your experience." },
  { label: "Your Rights", text: "You have the right to control your data and its usage." },
];

const productSecurityItems = [
  {
    icon: Cloud,
    title: "Cloud Infrastructure",
    description: "InfinityPDF utilizes robust cloud infrastructure partnerships for a secure and adaptable environment, ensuring resilience to meet user demands effectively.",
  },
  {
    icon: Globe,
    title: "Network Communications",
    description: "We rely on a global content delivery and DDoS protection service, guaranteeing rapid access worldwide and robust security against online threats.",
  },
  {
    icon: HardDrive,
    title: "Storage",
    description: "Our cloud infrastructure is bolstered by a leading data storage provider. It's important to emphasize that InfinityPDF does not retain user documents.",
  },
];

const internalSecurityItems = [
  {
    icon: Users,
    title: "Centralized Account Management",
    description: "We employ a centralized account management system, streamlining the control and oversight of user accounts to enhance security.",
  },
  {
    icon: KeyRound,
    title: "Password Management System",
    description: "We maintain the integrity and security of your login credentials through a robust password management system with regular password rotation.",
  },
  {
    icon: ShieldCheck,
    title: "Two-Factor Authentication (2FA)",
    description: "We enforce Two-Factor Authentication for all nominal accounts, adding an additional layer of protection to user accounts.",
  },
  {
    icon: Fingerprint,
    title: "Controlled Physical Access",
    description: "Implementing security measures such as alarms, fingerprint authentication, fire protection, and anti-robbery safeguards for physical access control.",
  },
  {
    icon: UserCheck,
    title: "Employee Onboarding & Offboarding",
    description: "Our procedures include a checklist that prioritizes security best practices, ensuring employees' access aligns with our security standards.",
  },
  {
    icon: Eye,
    title: "Principle of Least Privilege",
    description: "Access privileges are meticulously managed, granting users only the minimum level of access required to perform their tasks.",
  },
];

export default function SecurityPage() {
  return (
    <div className="min-h-screen py-16">
      <div className="mx-auto max-w-4xl px-4 sm:px-6">

        <div className="text-center mb-12">
          <Badge variant="secondary" className="mb-4" data-testid="badge-security">Legal & Privacy</Badge>
          <h1 className="font-serif text-3xl font-bold sm:text-4xl" data-testid="text-security-title">
            Security and Data Protection
          </h1>
          <p className="mx-auto mt-4 max-w-2xl text-muted-foreground leading-relaxed">
            This page is dedicated to outlining our comprehensive measures and protocols designed to ensure the confidentiality, integrity, and safety of your files. Learn about the robust security practices we employ to protect your data.
          </p>
        </div>

        <section className="mb-14">
          <h2 className="font-serif text-xl font-bold mb-2" data-testid="section-data-privacy">Data Privacy and Security</h2>
          <p className="text-sm text-muted-foreground leading-relaxed mb-6">
            Discover how we prioritize your privacy. Explore the summary of our approach to data handling in this section.
          </p>

          <Card className="p-6 mb-6">
            <h3 className="font-semibold text-lg mb-3" data-testid="text-privacy-policy-overview">InfinityPDF Privacy Policy</h3>
            <p className="text-sm text-muted-foreground leading-relaxed mb-4">
              We want to be transparent about how we handle your data. In our commitment to ensuring your privacy, we adhere to the following principles:
            </p>
            <ul className="space-y-3">
              {privacyPrinciples.map((item) => (
                <li key={item.label} className="flex gap-3 text-sm">
                  <span className="font-medium text-foreground min-w-[120px]">{item.label}:</span>
                  <span className="text-muted-foreground">{item.text}</span>
                </li>
              ))}
            </ul>
            <p className="text-sm text-muted-foreground mt-4">
              For more details, check the complete{" "}
              <a href="/privacy" className="underline font-medium text-foreground" data-testid="link-privacy-full">Privacy Policy</a>.
            </p>
          </Card>
        </section>

        <section className="mb-14">
          <h2 className="font-serif text-xl font-bold mb-2" data-testid="section-security-policy">Security Policy Overview</h2>
          <p className="text-sm text-muted-foreground leading-relaxed mb-6">
            The InfinityPDF Security Policy focuses on preventing, detecting, and responding to security incidents to safeguard confidential data and ensure uninterrupted service.
          </p>

          <div className="space-y-6">
            <Card className="p-6">
              <h3 className="font-semibold mb-2">Key Responsibilities</h3>
              <p className="text-sm text-muted-foreground leading-relaxed">
                Responsibilities include resource allocation by executive management, policy oversight by the Security Committee, adherence to security measures, and reporting incidents by employees and authorized users.
              </p>
            </Card>

            <Card className="p-6">
              <h3 className="font-semibold mb-2">Key Security Measures</h3>
              <p className="text-sm text-muted-foreground leading-relaxed">
                Critical security measures encompass access control, security training, regular system updates, and essential risk mitigation strategies. Additionally, InfinityPDF emphasizes data encryption, security audits, and a robust Continuous Improvement Plan to maintain information security and resilience.
              </p>
            </Card>

            <Card className="p-6">
              <h3 className="font-semibold mb-2">Ongoing Evaluation and Improvement</h3>
              <p className="text-sm text-muted-foreground leading-relaxed">
                We manage and protect information security with a Continuous Improvement Plan. We regularly review our policies to ensure their effectiveness and relevance in a changing landscape. Additionally, we actively seek opportunities for improvement in our information security processes. This commitment allows us to stay ahead of emerging threats and continuously enhance our safeguards for user data.
              </p>
            </Card>
          </div>
        </section>

        <section className="mb-14">
          <h2 className="font-serif text-xl font-bold mb-2" data-testid="section-certifications">Certifications and Compliance</h2>
          <p className="text-sm text-muted-foreground leading-relaxed mb-6">
            Security, privacy, and trust in focus: Our adherence to standards and regulations.
          </p>

          <div className="grid gap-6 sm:grid-cols-3">
            <Card className="p-6">
              <div className="flex h-10 w-10 items-center justify-center rounded-md bg-primary/10 mb-4">
                <Shield className="h-5 w-5 text-primary" />
              </div>
              <h3 className="font-semibold mb-2">ISO/IEC 27001</h3>
              <p className="text-sm text-muted-foreground leading-relaxed">
                Rigorous adherence to global information security standards ensuring the highest level of data protection.
              </p>
            </Card>

            <Card className="p-6">
              <div className="flex h-10 w-10 items-center justify-center rounded-md bg-primary/10 mb-4">
                <Lock className="h-5 w-5 text-primary" />
              </div>
              <h3 className="font-semibold mb-2">GDPR Compliant</h3>
              <p className="text-sm text-muted-foreground leading-relaxed">
                Fully GDPR compliant, ensuring utmost respect for data privacy. We guarantee your rights, including access, rectification, and erasure of personal data.
              </p>
            </Card>

            <Card className="p-6">
              <div className="flex h-10 w-10 items-center justify-center rounded-md bg-primary/10 mb-4">
                <FileCheck className="h-5 w-5 text-primary" />
              </div>
              <h3 className="font-semibold mb-2">eIDAS Compliance</h3>
              <p className="text-sm text-muted-foreground leading-relaxed">
                We integrate services provided by Qualified Trust Service Providers (QTSP) under eIDAS, ensuring legal validity and integrity of signed documents.
              </p>
            </Card>
          </div>
        </section>

        <section className="mb-14">
          <h2 className="font-serif text-xl font-bold mb-2" data-testid="section-product-security">Product Security</h2>
          <p className="text-sm text-muted-foreground leading-relaxed mb-6">
            Find details on how we secure and protect user data and document processing.
          </p>

          <div className="grid gap-6 sm:grid-cols-3 mb-8">
            {productSecurityItems.map((item) => (
              <Card key={item.title} className="p-6" data-testid={`card-${item.title.toLowerCase().replace(/\s+/g, "-")}`}>
                <div className="flex h-10 w-10 items-center justify-center rounded-md bg-primary/10 mb-4">
                  <item.icon className="h-5 w-5 text-primary" />
                </div>
                <h3 className="font-semibold mb-2">{item.title}</h3>
                <p className="text-sm text-muted-foreground leading-relaxed">{item.description}</p>
              </Card>
            ))}
          </div>

          <Card className="p-6 mb-6">
            <h3 className="font-semibold mb-2">Data Encryption</h3>
            <p className="text-sm text-muted-foreground leading-relaxed mb-3">
              Data encryption is a fundamental pillar of our product security. We implement robust encryption protocols, including the use of the HTTPS (Hypertext Transfer Protocol Secure) protocol, to protect your data both in transit and at rest. This stringent encryption guarantees the confidentiality and integrity of your data, offering peace of mind when using our services.
            </p>
            <p className="text-sm text-muted-foreground leading-relaxed">
              Additionally, we employ end-to-end encryption to ensure the highest level of security for your data from the moment you upload it until it's processed and delivered back to you.
            </p>
          </Card>

          <Card className="p-6 mb-6">
            <div className="flex h-10 w-10 items-center justify-center rounded-md bg-primary/10 mb-4">
              <Trash2 className="h-5 w-5 text-primary" />
            </div>
            <h3 className="font-semibold mb-2">Data Retention and Removal</h3>
            <p className="text-sm text-muted-foreground leading-relaxed">
              Respecting your privacy and adhering to applicable regulations are core principles of our data retention and removal policies. All files processed within our platform are automatically and permanently deleted shortly after being processed. We also provide users with the option to manually delete files from the download screen, giving you even more control over your data's lifecycle.
            </p>
          </Card>
        </section>

        <section className="mb-14">
          <h2 className="font-serif text-xl font-bold mb-2" data-testid="section-user-protection">User Protection</h2>
          <p className="text-sm text-muted-foreground leading-relaxed mb-6">
            At InfinityPDF, we prioritize user protection. As part of our commitment to enhancing security, we offer Two-Factor Authentication (2FA). With 2FA, your account is fortified with an additional layer of security, ensuring that only authorized users can access it.
          </p>

          <Card className="p-6">
            <div className="flex h-10 w-10 items-center justify-center rounded-md bg-primary/10 mb-4">
              <CreditCard className="h-5 w-5 text-primary" />
            </div>
            <h3 className="font-semibold mb-2">Payment Information</h3>
            <p className="text-sm text-muted-foreground leading-relaxed">
              For seamless and secure transactions, InfinityPDF is powered by Stripe, a renowned and trusted payment gateway. Stripe offers top-tier security for your payment information and is certified as a PCI Level 1 Service Provider. We do not collect any payment information and are therefore not subject to PCI obligations.
            </p>
          </Card>
        </section>

        <section>
          <h2 className="font-serif text-xl font-bold mb-2" data-testid="section-internal-security">Internal Security</h2>
          <p className="text-sm text-muted-foreground leading-relaxed mb-6">
            Discover the comprehensive measures and protocols implemented to secure InfinityPDF' internal operations and data.
          </p>

          <div className="grid gap-6 sm:grid-cols-2 lg:grid-cols-3">
            {internalSecurityItems.map((item) => (
              <Card key={item.title} className="p-6" data-testid={`card-${item.title.toLowerCase().replace(/\s+/g, "-")}`}>
                <div className="flex h-10 w-10 items-center justify-center rounded-md bg-primary/10 mb-4">
                  <item.icon className="h-5 w-5 text-primary" />
                </div>
                <h3 className="font-semibold mb-2">{item.title}</h3>
                <p className="text-sm text-muted-foreground leading-relaxed">{item.description}</p>
              </Card>
            ))}
          </div>
        </section>

      </div>
    </div>
  );
}
