import { useState, useCallback, useRef, useEffect } from "react";
import { useRoute, useLocation } from "wouter";
import { Card } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Progress } from "@/components/ui/progress";
import { getToolById, getToolBySlug, getToolUrl, getToolDetail, getToolsByCategory, PDF_TOOLS } from "@/lib/pdf-tools";
import type { PdfTool } from "@/lib/pdf-tools";
import { useAuth } from "@/hooks/use-auth";
import { useToast } from "@/hooks/use-toast";
import { motion, AnimatePresence } from "framer-motion";
import {
  Merge, Scissors, RotateCw, Hash, FileDown, Stamp,
  Unlock, GitCompare, Crop, EyeOff, Lock, Globe, ScanText,
  Upload, X, FileText, Download, ArrowLeft, Loader2,
  Plus, Crown, Shield, CheckCircle2, Zap, Users, Search,
  FileX2, ArrowUpDown, LayoutGrid, FileSpreadsheet, FileType,
  Presentation, Table, PenLine, PenTool, Archive,
  Wrench, Copy, ScanLine, Workflow as WorkflowIcon, ImagePlus,
  Image as ImageIcon, ClipboardEdit, Sparkles, ArrowRight,
  GripVertical, Play, Timer, AlertTriangle, HelpCircle,
} from "lucide-react";
import { Link } from "wouter";
import * as pdfjsLib from "pdfjs-dist";
import pdfjsWorker from "pdfjs-dist/build/pdf.worker.min.mjs?url";

pdfjsLib.GlobalWorkerOptions.workerSrc = pdfjsWorker;

const iconMap: Record<string, any> = {
  Merge, Scissors, RotateCw, Hash, FileDown, Stamp, ImageIcon,
  Unlock, GitCompare, Crop, EyeOff, Lock, Globe, ScanText,
  FileX2, ArrowUpDown, LayoutGrid, FileSpreadsheet, FileType,
  Presentation, Table, PenLine, PenTool, Archive,
  Wrench, Copy, ScanLine, Workflow: WorkflowIcon, ImagePlus,
  ClipboardEdit, Sparkles,
};

interface UploadedFile {
  id: string;
  file: File;
  name: string;
  size: string;
  thumbnailUrl?: string;
}

function PdfThumbnail({ file, onLoad }: { file: File; onLoad: (url: string) => void }) {
  const canvasRef = useRef<HTMLCanvasElement>(null);
  const [loaded, setLoaded] = useState(false);

  useEffect(() => {
    let cancelled = false;
    const render = async () => {
      try {
        const arrayBuffer = await file.arrayBuffer();
        const pdf = await pdfjsLib.getDocument({ data: arrayBuffer }).promise;
        const page = await pdf.getPage(1);
        const viewport = page.getViewport({ scale: 0.5 });
        const canvas = canvasRef.current;
        if (!canvas || cancelled) return;
        canvas.width = viewport.width;
        canvas.height = viewport.height;
        const ctx = canvas.getContext("2d");
        if (!ctx) return;
        await (page.render({ canvasContext: ctx, viewport } as any)).promise;
        if (!cancelled) {
          setLoaded(true);
          onLoad(canvas.toDataURL());
        }
      } catch {
        if (!cancelled) setLoaded(true);
      }
    };
    if (file.type === "application/pdf" || file.name.toLowerCase().endsWith(".pdf")) {
      render();
    } else {
      setLoaded(true);
    }
    return () => { cancelled = true; };
  }, [file]);

  return (
    <div className="flex items-center justify-center bg-muted/30 rounded-md aspect-[3/4] overflow-hidden" data-testid="thumbnail-container">
      <canvas
        ref={canvasRef}
        data-testid="thumbnail-canvas"
        className={`max-w-full max-h-full object-contain ${loaded ? "block" : "hidden"}`}
      />
      {!loaded && (
        <div className="flex flex-col items-center justify-center gap-2">
          <Loader2 className="h-5 w-5 animate-spin text-muted-foreground" />
        </div>
      )}
    </div>
  );
}

export default function ToolPage() {
  const [matchTool, toolParams] = useRoute("/tool/:id");
  const [matchSlug, slugParams] = useRoute("/:slug");
  const [, navigate] = useLocation();

  let tool: PdfTool | undefined;
  let resolvedByOldUrl = false;

  if (matchSlug && slugParams?.slug) {
    tool = getToolBySlug(slugParams.slug);
  }
  if (!tool && matchTool && toolParams?.id) {
    tool = getToolById(toolParams.id);
    resolvedByOldUrl = true;
  }

  useEffect(() => {
    if (tool && resolvedByOldUrl) {
      navigate(getToolUrl(tool), { replace: true });
    }
  }, [tool, resolvedByOldUrl, navigate]);

  const { user, isAuthenticated } = useAuth();
  const { toast } = useToast();

  const [files, setFiles] = useState<UploadedFile[]>([]);
  const [isDragging, setIsDragging] = useState(false);
  const [isProcessing, setIsProcessing] = useState(false);
  const [progress, setProgress] = useState(0);
  const [resultUrl, setResultUrl] = useState<string | null>(null);
  const [resultFilename, setResultFilename] = useState<string>("");
  const fileInputRef = useRef<HTMLInputElement>(null);

  const [rotationAngle, setRotationAngle] = useState("90");
  const [watermarkText, setWatermarkText] = useState("");
  const [splitPages, setSplitPages] = useState("all");
  const [pageNumberPosition, setPageNumberPosition] = useState("bottom-center");
  const [pagesToRemove, setPagesToRemove] = useState("");
  const [pageOrder, setPageOrder] = useState("");
  const [password, setPassword] = useState("");
  const [editText, setEditText] = useState("");
  const [editPage, setEditPage] = useState("1");
  const [editX, setEditX] = useState("40");
  const [editY, setEditY] = useState("700");
  const [signatureName, setSignatureName] = useState("");
  const [redactText, setRedactText] = useState("");
  const [fieldData, setFieldData] = useState("");
  const [cropTop, setCropTop] = useState("0");
  const [cropBottom, setCropBottom] = useState("0");
  const [cropLeft, setCropLeft] = useState("0");
  const [cropRight, setCropRight] = useState("0");
  const [webUrl, setWebUrl] = useState("");
  const [workflowSteps, setWorkflowSteps] = useState("");
  const [jpgQuality, setJpgQuality] = useState("200");
  const [compressionLevel, setCompressionLevel] = useState("recommended");

  const [draggedIdx, setDraggedIdx] = useState<number | null>(null);
  const [dragOverIdx, setDragOverIdx] = useState<number | null>(null);

  const [showAdModal, setShowAdModal] = useState(false);
  const [adCountdown, setAdCountdown] = useState(0);
  const [adWatched, setAdWatched] = useState(false);
  const [mergeAdUnlocked, setMergeAdUnlocked] = useState(false);

  const FREE_MERGE_LIMIT = 10;
  const AD_MERGE_LIMIT = 30;

  const isPremiumUser = user?.premiumStatus === "active";

  const getMergeLimit = () => {
    if (isPremiumUser) return Infinity;
    if (mergeAdUnlocked) return AD_MERGE_LIMIT;
    return FREE_MERGE_LIMIT;
  };

  const startAdCountdown = () => {
    setShowAdModal(true);
    setAdCountdown(15);
    setAdWatched(false);
  };

  useEffect(() => {
    if (!showAdModal || adCountdown <= 0) return;
    const timer = setTimeout(() => {
      const next = adCountdown - 1;
      setAdCountdown(next);
      if (next === 0) {
        setAdWatched(true);
      }
    }, 1000);
    return () => clearTimeout(timer);
  }, [showAdModal, adCountdown]);

  const claimAdReward = async () => {
    try {
      const res = await fetch("/api/merge/ad-unlock", {
        method: "POST",
        credentials: "include",
      });
      if (res.ok) {
        setMergeAdUnlocked(true);
        setShowAdModal(false);
        toast({ title: "Unlocked!", description: `You can now merge up to ${AD_MERGE_LIMIT} files. This session only.` });
      }
    } catch {
      toast({ title: "Error", description: "Failed to unlock. Please try again.", variant: "destructive" });
    }
  };

  if (!tool) {
    return (
      <div className="flex min-h-[60vh] items-center justify-center">
        <div className="text-center">
          <h2 className="text-xl font-semibold">Tool not found</h2>
          <p className="mt-2 text-muted-foreground">The requested PDF tool doesn't exist.</p>
          <Button asChild className="mt-4" data-testid="button-back-home">
            <Link href="/">Go Home</Link>
          </Button>
        </div>
      </div>
    );
  }

  const ToolIcon = iconMap[tool.icon];

  const formatSize = (bytes: number) => {
    if (bytes < 1024) return bytes + " B";
    if (bytes < 1024 * 1024) return (bytes / 1024).toFixed(1) + " KB";
    return (bytes / (1024 * 1024)).toFixed(1) + " MB";
  };

  const getAcceptTypes = () => {
    if (tool.acceptTypes) return tool.acceptTypes;
    return ".pdf,application/pdf";
  };

  const getFileTypeLabel = () => {
    if (tool.acceptTypes) {
      const types = tool.acceptTypes.split(",").map(t => t.replace(".", "").toUpperCase());
      if (types.length > 4) return "files";
      return types.join("/") + " files";
    }
    return "PDF" + (tool.acceptMultiple ? "s" : "");
  };

  const addFiles = useCallback(
    (newFiles: FileList | File[]) => {
      const fileArray = Array.from(newFiles);
      if (fileArray.length === 0) return;

      if (!tool.acceptTypes) {
        const pdfFiles = fileArray.filter((f) => f.type === "application/pdf" || f.name.toLowerCase().endsWith(".pdf"));
        if (pdfFiles.length === 0) {
          toast({ title: "Invalid file type", description: "Please upload PDF files only.", variant: "destructive" });
          return;
        }
        const mapped: UploadedFile[] = pdfFiles.map((f) => ({
          id: Math.random().toString(36).slice(2),
          file: f, name: f.name, size: formatSize(f.size),
        }));
        if (tool.acceptMultiple) {
          setFiles((prev) => {
            const mergeLimit = getMergeLimit();
            if (tool.id === "merge" && prev.length + mapped.length > mergeLimit) {
              const allowed = mergeLimit - prev.length;
              if (allowed <= 0) {
                toast({
                  title: "File limit reached",
                  description: mergeAdUnlocked
                    ? `You can merge up to ${AD_MERGE_LIMIT} files with ad unlock. Upgrade to Premium for unlimited.`
                    : `Free users can merge up to ${FREE_MERGE_LIMIT} files. Watch an ad or upgrade to merge more.`,
                  variant: "destructive",
                });
                return prev;
              }
              toast({
                title: "Some files skipped",
                description: `Only ${allowed} more file(s) added to stay within the ${mergeLimit}-file limit.`,
              });
              return [...prev, ...mapped.slice(0, allowed)];
            }
            return [...prev, ...mapped];
          });
        } else {
          setFiles(mapped.slice(0, 1));
        }
      } else {
        const mapped: UploadedFile[] = fileArray.map((f) => ({
          id: Math.random().toString(36).slice(2),
          file: f, name: f.name, size: formatSize(f.size),
        }));
        if (tool.acceptMultiple) setFiles((prev) => [...prev, ...mapped]);
        else setFiles(mapped.slice(0, 1));
      }
      setResultUrl(null);
    },
    [tool.acceptMultiple, tool.acceptTypes, tool.id, toast, mergeAdUnlocked, isPremiumUser]
  );

  const removeFile = (id: string) => {
    setFiles((prev) => prev.filter((f) => f.id !== id));
    setResultUrl(null);
  };

  const handleFileDragStart = (e: React.DragEvent, idx: number) => {
    e.dataTransfer.effectAllowed = "move";
    e.dataTransfer.setData("text/plain", "");
    setDraggedIdx(idx);
  };

  const handleFileDragOver = (e: React.DragEvent, idx: number) => {
    e.preventDefault();
    e.dataTransfer.dropEffect = "move";
    if (draggedIdx !== null && draggedIdx !== idx) {
      setDragOverIdx(idx);
    }
  };

  const handleFileDrop = (e: React.DragEvent, targetIdx: number) => {
    e.preventDefault();
    if (draggedIdx === null || draggedIdx === targetIdx) {
      setDraggedIdx(null);
      setDragOverIdx(null);
      return;
    }
    setFiles((prev) => {
      const next = [...prev];
      const [dragged] = next.splice(draggedIdx, 1);
      next.splice(targetIdx, 0, dragged);
      return next;
    });
    setDraggedIdx(null);
    setDragOverIdx(null);
  };

  const handleFileDragEnd = () => {
    setDraggedIdx(null);
    setDragOverIdx(null);
  };

  const handleDragOver = useCallback((e: React.DragEvent) => {
    e.preventDefault();
    setIsDragging(true);
  }, []);

  const handleDragLeave = useCallback((e: React.DragEvent) => {
    e.preventDefault();
    setIsDragging(false);
  }, []);

  const handleDrop = useCallback(
    (e: React.DragEvent) => {
      e.preventDefault();
      setIsDragging(false);
      addFiles(e.dataTransfer.files);
    },
    [addFiles]
  );

  const processFiles = async () => {
    if (tool.inputType === "url") {
      if (!webUrl.trim()) return;
    } else if (files.length === 0) return;

    setIsProcessing(true);
    setProgress(0);
    setResultUrl(null);

    const progressInterval = setInterval(() => {
      setProgress((prev) => Math.min(prev + 5, 85));
    }, 300);

    try {
      const formData = new FormData();
      files.forEach((f) => formData.append("files", f.file));
      formData.append("toolId", tool.id);

      if (tool.id === "rotate") formData.append("angle", rotationAngle);
      if (tool.id === "watermark") formData.append("watermarkText", watermarkText);
      if (tool.id === "split") formData.append("splitPages", splitPages);
      if (tool.id === "page-numbers") formData.append("position", pageNumberPosition);
      if (tool.id === "remove-pages") formData.append("pagesToRemove", pagesToRemove);
      if (tool.id === "reorder-pages" || tool.id === "organize-pages") formData.append("pageOrder", pageOrder);
      if (tool.id === "protect") formData.append("password", password);
      if (tool.id === "edit-pdf") {
        formData.append("editText", editText);
        formData.append("editPage", editPage);
        formData.append("editX", editX);
        formData.append("editY", editY);
      }
      if (tool.id === "sign-pdf") formData.append("signatureName", signatureName);
      if (tool.id === "redact") formData.append("redactText", redactText);
      if (tool.id === "pdf-filler") formData.append("fieldData", fieldData);
      if (tool.id === "crop") {
        formData.append("cropTop", cropTop);
        formData.append("cropBottom", cropBottom);
        formData.append("cropLeft", cropLeft);
        formData.append("cropRight", cropRight);
      }
      if (tool.id === "web-to-pdf") formData.append("url", webUrl);
      if (tool.id === "workflow") formData.append("workflowSteps", workflowSteps);
      if (tool.id === "pdf-to-jpg") formData.append("quality", jpgQuality);
      if (tool.id === "compress") formData.append("compressionLevel", compressionLevel);

      const res = await fetch("/api/pdf/process", {
        method: "POST",
        body: formData,
        credentials: "include",
      });

      clearInterval(progressInterval);

      if (!res.ok) {
        const err = await res.json();
        throw new Error(err.message || "Processing failed");
      }

      const data = await res.json();
      setProgress(100);
      setResultUrl(data.downloadUrl);
      setResultFilename(data.filename);

      toast({ title: "Success", description: "Your file has been processed successfully." });
    } catch (err: any) {
      clearInterval(progressInterval);
      toast({ title: "Error", description: err.message || "Something went wrong.", variant: "destructive" });
    } finally {
      setTimeout(() => {
        setIsProcessing(false);
        setProgress(0);
      }, 500);
    }
  };

  const hasOptions = () => {
    const toolsWithOptions = [
      "rotate", "watermark", "split", "page-numbers", "remove-pages",
      "reorder-pages", "organize-pages", "protect", "edit-pdf", "sign-pdf",
      "redact", "pdf-filler", "crop", "web-to-pdf", "workflow", "pdf-to-jpg",
      "compress",
    ];
    return toolsWithOptions.includes(tool.id);
  };

  const renderOptions = () => {
    switch (tool.id) {
      case "compress":
        return (
          <div className="space-y-2">
            <Label className="text-xs font-semibold uppercase tracking-wider text-muted-foreground">Compression level</Label>
            <div className="space-y-1.5">
              {[
                { value: "extreme", label: "Extreme Compression", desc: "Less quality, high compression", color: "text-destructive" },
                { value: "recommended", label: "Recommended Compression", desc: "Good quality, good compression", color: "text-foreground" },
                { value: "less", label: "Less Compression", desc: "High quality, less compression", color: "text-muted-foreground" },
              ].map((opt) => (
                <button
                  key={opt.value}
                  onClick={() => setCompressionLevel(opt.value)}
                  className={`w-full text-left p-3 rounded-md border transition-colors ${
                    compressionLevel === opt.value
                      ? "border-primary bg-primary/5"
                      : "border-border hover-elevate"
                  }`}
                  data-testid={`button-compression-${opt.value}`}
                >
                  <div className="flex flex-wrap items-center justify-between gap-2">
                    <span className={`text-sm font-semibold ${opt.color}`}>{opt.label}</span>
                    {compressionLevel === opt.value && (
                      <CheckCircle2 className="h-4 w-4 text-foreground" />
                    )}
                  </div>
                  <p className="text-xs text-muted-foreground mt-0.5">{opt.desc}</p>
                </button>
              ))}
            </div>
          </div>
        );
      case "rotate":
        return (
          <div className="space-y-2">
            <Label>Rotation Angle</Label>
            <Select value={rotationAngle} onValueChange={setRotationAngle}>
              <SelectTrigger data-testid="select-rotation-angle">
                <SelectValue />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="90">90° Clockwise</SelectItem>
                <SelectItem value="180">180°</SelectItem>
                <SelectItem value="270">90° Counter-clockwise</SelectItem>
              </SelectContent>
            </Select>
          </div>
        );
      case "watermark":
        return (
          <div className="space-y-2">
            <Label>Watermark Text</Label>
            <Input
              placeholder="Enter watermark text..."
              value={watermarkText}
              onChange={(e) => setWatermarkText(e.target.value)}
              data-testid="input-watermark-text"
            />
          </div>
        );
      case "split":
        return (
          <div className="space-y-2">
            <Label>Pages to Extract</Label>
            <Input
              placeholder='e.g., 1-3,5,7-9 or "all" for individual pages'
              value={splitPages}
              onChange={(e) => setSplitPages(e.target.value)}
              data-testid="input-split-pages"
            />
            <p className="text-xs text-muted-foreground">
              Enter page ranges separated by commas, or "all" to split into individual pages.
            </p>
          </div>
        );
      case "page-numbers":
        return (
          <div className="space-y-2">
            <Label>Position</Label>
            <Select value={pageNumberPosition} onValueChange={setPageNumberPosition}>
              <SelectTrigger data-testid="select-page-number-position">
                <SelectValue />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="bottom-center">Bottom Center</SelectItem>
                <SelectItem value="bottom-left">Bottom Left</SelectItem>
                <SelectItem value="bottom-right">Bottom Right</SelectItem>
                <SelectItem value="top-center">Top Center</SelectItem>
                <SelectItem value="top-left">Top Left</SelectItem>
                <SelectItem value="top-right">Top Right</SelectItem>
              </SelectContent>
            </Select>
          </div>
        );
      case "remove-pages":
        return (
          <div className="space-y-2">
            <Label>Pages to Remove</Label>
            <Input
              placeholder="e.g., 1,3,5-7"
              value={pagesToRemove}
              onChange={(e) => setPagesToRemove(e.target.value)}
              data-testid="input-pages-to-remove"
            />
            <p className="text-xs text-muted-foreground">
              Enter page numbers or ranges to remove (e.g., 1,3,5-7).
            </p>
          </div>
        );
      case "reorder-pages":
      case "organize-pages":
        return (
          <div className="space-y-2">
            <Label>New Page Order</Label>
            <Input
              placeholder="e.g., 3,1,2,5,4"
              value={pageOrder}
              onChange={(e) => setPageOrder(e.target.value)}
              data-testid="input-page-order"
            />
            <p className="text-xs text-muted-foreground">
              Enter the desired page order as comma-separated page numbers.
            </p>
          </div>
        );
      case "protect":
        return (
          <div className="space-y-2">
            <Label>Password</Label>
            <Input
              type="password"
              placeholder="Enter password to protect PDF..."
              value={password}
              onChange={(e) => setPassword(e.target.value)}
              data-testid="input-password"
            />
          </div>
        );
      case "edit-pdf":
        return (
          <div className="space-y-3">
            <div className="space-y-2">
              <Label>Text to Add</Label>
              <Textarea
                placeholder="Enter text to add to the PDF..."
                value={editText}
                onChange={(e) => setEditText(e.target.value)}
                data-testid="input-edit-text"
              />
            </div>
            <div className="space-y-2">
              <Label>Page</Label>
              <Input
                type="number" min="1" value={editPage}
                onChange={(e) => setEditPage(e.target.value)}
                data-testid="input-edit-page"
              />
            </div>
            <div className="grid grid-cols-2 gap-3">
              <div className="space-y-2">
                <Label>X Position</Label>
                <Input
                  type="number" min="0" value={editX}
                  onChange={(e) => setEditX(e.target.value)}
                  data-testid="input-edit-x"
                />
              </div>
              <div className="space-y-2">
                <Label>Y Position</Label>
                <Input
                  type="number" min="0" value={editY}
                  onChange={(e) => setEditY(e.target.value)}
                  data-testid="input-edit-y"
                />
              </div>
            </div>
          </div>
        );
      case "sign-pdf":
        return (
          <div className="space-y-2">
            <Label>Your Full Name</Label>
            <Input
              placeholder="Enter your name for the signature..."
              value={signatureName}
              onChange={(e) => setSignatureName(e.target.value)}
              data-testid="input-signature-name"
            />
            <p className="text-xs text-muted-foreground">
              Your name will be added as a signature on the last page.
            </p>
          </div>
        );
      case "redact":
        return (
          <div className="space-y-2">
            <Label>Content to Redact</Label>
            <Input
              placeholder="Enter text or area to redact..."
              value={redactText}
              onChange={(e) => setRedactText(e.target.value)}
              data-testid="input-redact-text"
            />
            <p className="text-xs text-muted-foreground">
              A black redaction bar will be applied to each page.
            </p>
          </div>
        );
      case "pdf-filler":
        return (
          <div className="space-y-2">
            <Label>Form Field Data (JSON)</Label>
            <Textarea
              placeholder='{"fieldName": "value", "name": "John Doe"}'
              value={fieldData}
              onChange={(e) => setFieldData(e.target.value)}
              data-testid="input-field-data"
            />
            <p className="text-xs text-muted-foreground">
              Enter field names and values as JSON. The fields must match the form field names in your PDF.
            </p>
          </div>
        );
      case "crop":
        return (
          <div className="space-y-3">
            <Label>Crop Margins (in points, 72 points = 1 inch)</Label>
            <div className="grid grid-cols-2 gap-3">
              <div className="space-y-1">
                <Label className="text-xs text-muted-foreground">Top</Label>
                <Input type="number" min="0" value={cropTop} onChange={(e) => setCropTop(e.target.value)} data-testid="input-crop-top" />
              </div>
              <div className="space-y-1">
                <Label className="text-xs text-muted-foreground">Bottom</Label>
                <Input type="number" min="0" value={cropBottom} onChange={(e) => setCropBottom(e.target.value)} data-testid="input-crop-bottom" />
              </div>
              <div className="space-y-1">
                <Label className="text-xs text-muted-foreground">Left</Label>
                <Input type="number" min="0" value={cropLeft} onChange={(e) => setCropLeft(e.target.value)} data-testid="input-crop-left" />
              </div>
              <div className="space-y-1">
                <Label className="text-xs text-muted-foreground">Right</Label>
                <Input type="number" min="0" value={cropRight} onChange={(e) => setCropRight(e.target.value)} data-testid="input-crop-right" />
              </div>
            </div>
          </div>
        );
      case "web-to-pdf":
        return (
          <div className="space-y-2">
            <Label>Web Page URL</Label>
            <Input
              type="url"
              placeholder="https://example.com"
              value={webUrl}
              onChange={(e) => setWebUrl(e.target.value)}
              data-testid="input-web-url"
            />
            <p className="text-xs text-muted-foreground">
              Enter the full URL of the web page to convert.
            </p>
          </div>
        );
      case "workflow":
        return (
          <div className="space-y-2">
            <Label>Workflow Steps (one per line)</Label>
            <Textarea
              placeholder={"rotate:90\ncompress\nwatermark:DRAFT\npage-numbers:bottom-center"}
              value={workflowSteps}
              onChange={(e) => setWorkflowSteps(e.target.value)}
              className="min-h-[120px] font-mono text-sm"
              data-testid="input-workflow-steps"
            />
            <p className="text-xs text-muted-foreground">
              Available steps: rotate:ANGLE, compress, watermark:TEXT, page-numbers:POSITION, unlock
            </p>
          </div>
        );
      case "pdf-to-jpg":
        return (
          <div className="space-y-2">
            <Label>Image Quality (DPI)</Label>
            <Select value={jpgQuality} onValueChange={setJpgQuality}>
              <SelectTrigger data-testid="select-jpg-quality">
                <SelectValue />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="100">Low (100 DPI)</SelectItem>
                <SelectItem value="150">Medium (150 DPI)</SelectItem>
                <SelectItem value="200">High (200 DPI)</SelectItem>
                <SelectItem value="300">Very High (300 DPI)</SelectItem>
              </SelectContent>
            </Select>
          </div>
        );
      default:
        return null;
    }
  };

  const canProcess = () => {
    if (isProcessing) return false;
    if (tool.inputType === "url") return webUrl.trim().length > 0;
    if (files.length === 0) return false;
    if (tool.id === "watermark" && !watermarkText.trim()) return false;
    if (tool.id === "protect" && !password.trim()) return false;
    if (tool.id === "sign-pdf" && !signatureName.trim()) return false;
    if (tool.id === "redact" && !redactText.trim()) return false;
    if (tool.id === "remove-pages" && !pagesToRemove.trim()) return false;
    if ((tool.id === "reorder-pages" || tool.id === "organize-pages") && !pageOrder.trim()) return false;
    if (tool.id === "edit-pdf" && !editText.trim()) return false;
    if (tool.id === "workflow" && !workflowSteps.trim()) return false;
    return true;
  };

  const isUrlTool = tool.inputType === "url";
  const showOptions = hasOptions();
  const detail = getToolDetail(tool.id);

  useEffect(() => {
    if (!detail?.faq || detail.faq.length === 0) return;
    const script = document.createElement("script");
    script.type = "application/ld+json";
    script.id = "faq-schema";
    script.textContent = JSON.stringify({
      "@context": "https://schema.org",
      "@type": "FAQPage",
      mainEntity: detail.faq.map((item) => ({
        "@type": "Question",
        name: item.question,
        acceptedAnswer: {
          "@type": "Answer",
          text: item.answer,
        },
      })),
    });
    document.head.appendChild(script);
    return () => {
      const existing = document.getElementById("faq-schema");
      if (existing) existing.remove();
    };
  }, [detail?.faq, tool.id]);

  const relatedTools = (() => {
    const sameCat = getToolsByCategory(tool.category).filter((t) => t.id !== tool.id);
    if (sameCat.length >= 6) return sameCat.slice(0, 6);
    const others = PDF_TOOLS.filter((t) => t.id !== tool.id && t.category !== tool.category);
    return [...sameCat, ...others].slice(0, 6);
  })();

  const isPremiumLocked = tool.isPremium && user?.premiumStatus !== "active";

  const adModal = showAdModal && (
    <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/60 backdrop-blur-sm" data-testid="modal-ad-overlay">
      <motion.div
        initial={{ opacity: 0, scale: 0.95 }}
        animate={{ opacity: 1, scale: 1 }}
        className="mx-4 w-full max-w-md"
      >
        <Card className="p-6" data-testid="card-ad-modal">
          <div className="text-center space-y-4">
            <div className="flex items-center justify-center rounded-full bg-amber-500/10 mx-auto" style={{ width: "56px", height: "56px" }}>
              <Play className="h-7 w-7 text-amber-500" />
            </div>
            <h3 className="text-lg font-bold" data-testid="text-ad-title">Watch Ad to Unlock</h3>
            <p className="text-sm text-muted-foreground" data-testid="text-ad-desc">
              Watch this short advertisement to unlock merging up to {AD_MERGE_LIMIT} PDF files.
            </p>

            <Card className="p-6 bg-muted/50 border-dashed" data-testid="card-ad-placeholder">
              <div className="flex flex-col items-center justify-center gap-3">
                {!adWatched ? (
                  <>
                    <div className="flex items-center justify-center rounded-full bg-muted" style={{ width: "48px", height: "48px" }}>
                      <Timer className="h-6 w-6 text-muted-foreground" />
                    </div>
                    <p className="text-sm font-medium" data-testid="text-ad-countdown">
                      Ad playing... {adCountdown}s remaining
                    </p>
                    <Progress value={((15 - adCountdown) / 15) * 100} className="h-2 w-full" data-testid="progress-ad" />
                    <p className="text-xs text-muted-foreground">Please wait for the ad to finish</p>
                  </>
                ) : (
                  <>
                    <div className="flex items-center justify-center rounded-full bg-green-500/10" style={{ width: "48px", height: "48px" }}>
                      <CheckCircle2 className="h-6 w-6 text-green-600" />
                    </div>
                    <p className="text-sm font-medium text-green-600" data-testid="text-ad-complete">
                      Ad complete!
                    </p>
                  </>
                )}
              </div>
            </Card>

            <div className="flex flex-wrap items-center justify-center gap-2 pt-2">
              {adWatched ? (
                <Button onClick={claimAdReward} data-testid="button-claim-reward">
                  <CheckCircle2 className="mr-1.5 h-4 w-4" />
                  Unlock {AD_MERGE_LIMIT} Files
                </Button>
              ) : (
                <Button variant="outline" onClick={() => setShowAdModal(false)} data-testid="button-cancel-ad">
                  Cancel
                </Button>
              )}
            </div>
          </div>
        </Card>
      </motion.div>
    </div>
  );

  if (files.length === 0 && !isUrlTool) {
    return (
      <div className="mx-auto max-w-3xl px-4 py-8 sm:px-6">
        {adModal}
        <motion.div initial={{ opacity: 0, y: 12 }} animate={{ opacity: 1, y: 0 }} transition={{ duration: 0.35 }}>
          <Link href="/" data-testid="link-back">
            <Button variant="ghost" size="sm" className="mb-4 -ml-2">
              <ArrowLeft className="mr-1 h-4 w-4" />
              All Tools
            </Button>
          </Link>

          <div className="flex flex-wrap items-center gap-3 mb-6">
            <div
              className="flex h-12 w-12 items-center justify-center rounded-md"
              style={{ backgroundColor: `hsl(${tool.color} / 0.1)` }}
            >
              {ToolIcon && <ToolIcon className="h-6 w-6" style={{ color: `hsl(${tool.color})` }} />}
            </div>
            <div>
              <h1 className="text-xl font-bold tracking-tight sm:text-2xl" data-testid="text-tool-name">
                {tool.name}
              </h1>
              <p className="text-sm text-muted-foreground" data-testid="text-tool-desc">{tool.description}</p>
            </div>
          </div>

          {isPremiumLocked && (
            <Card className="mb-6 p-4 border-primary/30 bg-primary/5" data-testid="card-premium-lock">
              <div className="flex flex-wrap items-center gap-3">
                <div className="flex h-10 w-10 shrink-0 items-center justify-center rounded-md bg-primary/10">
                  <Crown className="h-5 w-5 text-primary" />
                </div>
                <div className="flex-1 min-w-0">
                  <h4 className="text-sm font-medium" data-testid="text-premium-title">Premium Tool</h4>
                  <p className="text-xs text-muted-foreground" data-testid="text-premium-desc">
                    {isAuthenticated
                      ? "Upgrade to Premium to use this tool."
                      : "Sign in and upgrade to Premium to use this tool."}
                  </p>
                </div>
                <Button size="sm" asChild data-testid="button-upgrade-prompt">
                  <Link href={isAuthenticated ? "/" : "/auth"}>
                    {isAuthenticated ? "Upgrade" : "Sign In"}
                  </Link>
                </Button>
              </div>
            </Card>
          )}

          <Card
            className={`relative border-2 border-dashed p-12 text-center transition-colors ${
              isDragging ? "border-primary bg-primary/5" : "border-border"
            }`}
            onDragOver={handleDragOver}
            onDragLeave={handleDragLeave}
            onDrop={handleDrop}
            data-testid="dropzone"
          >
            <input
              ref={fileInputRef}
              type="file"
              accept={getAcceptTypes()}
              multiple={tool.acceptMultiple}
              className="hidden"
              onChange={(e) => e.target.files && addFiles(e.target.files)}
              data-testid="input-file-upload"
            />
            <div
              className="mx-auto flex h-16 w-16 items-center justify-center rounded-md mb-4"
              style={{ backgroundColor: `hsl(${tool.color} / 0.1)` }}
            >
              {ToolIcon && <ToolIcon className="h-8 w-8" style={{ color: `hsl(${tool.color})` }} />}
            </div>
            <h2 className="text-lg font-semibold" data-testid="text-upload-title">
              Select {getFileTypeLabel()} to {tool.name.toLowerCase()}
            </h2>
            <p className="mt-2 text-sm text-muted-foreground">
              or drag and drop {getFileTypeLabel()} here
            </p>
            <Button
              className="mt-5"
              onClick={() => fileInputRef.current?.click()}
              style={{ backgroundColor: `hsl(${tool.color})` }}
              data-testid="button-select-files"
            >
              <Plus className="mr-1.5 h-4 w-4" />
              Select {getFileTypeLabel()}
            </Button>
            {tool.acceptTypes && (
              <p className="mt-4 text-xs text-muted-foreground">
                Accepted: {tool.acceptTypes.split(",").map(t => t.replace(".", "").toUpperCase()).join(", ")}
              </p>
            )}
          </Card>

          {detail && (
            <motion.div
              initial={{ opacity: 0, y: 16 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.4, delay: 0.15 }}
              className="mt-12 space-y-8"
              data-testid="section-tool-detail"
            >
              <div className="border-t pt-8">
                <h2 className="text-lg font-bold tracking-tight sm:text-xl" data-testid="text-detail-headline">
                  {tool.name} &mdash; {detail.headline}
                </h2>
                <p className="mt-3 text-sm leading-relaxed text-muted-foreground" data-testid="text-detail-whatis">
                  {detail.whatIs}
                </p>
              </div>

              {detail.detects && (
                <div>
                  <h3 className="flex flex-wrap items-center gap-2 text-sm font-semibold" data-testid="text-detects-title">
                    <Search className="h-4 w-4 text-primary" />
                    What It Detects
                  </h3>
                  <ul className="mt-3 grid gap-2 sm:grid-cols-2">
                    {detail.detects.map((item, i) => (
                      <li key={i} className="flex items-center gap-2 text-sm text-muted-foreground" data-testid={`text-detects-${i}`}>
                        <CheckCircle2 className="h-3.5 w-3.5 shrink-0 text-primary" />
                        {item}
                      </li>
                    ))}
                  </ul>
                </div>
              )}

              <div>
                <h3 className="flex flex-wrap items-center gap-2 text-sm font-semibold" data-testid="text-why-use-title">
                  <Zap className="h-4 w-4 text-primary" />
                  Why Use InfinityPDF {tool.name}?
                </h3>
                <div className="mt-3 grid gap-3 sm:grid-cols-3">
                  {detail.whyUse.map((feature, i) => (
                    <Card key={i} className="p-4" data-testid={`card-feature-${i}`}>
                      <h4 className="text-sm font-medium" data-testid={`text-feature-title-${i}`}>{feature.title}</h4>
                      <p className="mt-1.5 text-xs leading-relaxed text-muted-foreground" data-testid={`text-feature-desc-${i}`}>{feature.description}</p>
                    </Card>
                  ))}
                </div>
              </div>

              <div>
                <h3 className="flex flex-wrap items-center gap-2 text-sm font-semibold" data-testid="text-how-it-works-title">
                  How It Works
                </h3>
                <ol className="mt-3 space-y-2">
                  {detail.howItWorks.map((step, i) => (
                    <li key={i} className="flex items-start gap-3 text-sm text-muted-foreground" data-testid={`text-step-${i}`}>
                      <Badge variant="secondary" className="shrink-0 no-default-hover-elevate no-default-active-elevate">
                        {i + 1}
                      </Badge>
                      {step}
                    </li>
                  ))}
                </ol>
              </div>

              <div>
                <h3 className="flex flex-wrap items-center gap-2 text-sm font-semibold" data-testid="text-security-title">
                  <Shield className="h-4 w-4 text-primary" />
                  Secure & Private
                </h3>
                <ul className="mt-3 space-y-1.5">
                  {detail.security.map((item, i) => (
                    <li key={i} className="flex items-center gap-2 text-sm text-muted-foreground" data-testid={`text-security-${i}`}>
                      <CheckCircle2 className="h-3.5 w-3.5 shrink-0 text-primary" />
                      {item}
                    </li>
                  ))}
                </ul>
              </div>

              <div>
                <h3 className="flex flex-wrap items-center gap-2 text-sm font-semibold" data-testid="text-use-cases-title">
                  <Users className="h-4 w-4 text-primary" />
                  Use Cases
                </h3>
                <ul className="mt-3 grid gap-2 sm:grid-cols-2">
                  {detail.useCases.map((item, i) => (
                    <li key={i} className="flex items-center gap-2 text-sm text-muted-foreground" data-testid={`text-usecase-${i}`}>
                      <CheckCircle2 className="h-3.5 w-3.5 shrink-0 text-primary" />
                      {item}
                    </li>
                  ))}
                </ul>
              </div>

              <div>
                <h3 className="flex flex-wrap items-center gap-2 text-sm font-semibold" data-testid="text-why-choose-title">
                  <Sparkles className="h-4 w-4 text-primary" />
                  Why Choose InfinityPDF?
                </h3>
                <ul className="mt-3 space-y-1.5">
                  {detail.whyChoose.map((item, i) => (
                    <li key={i} className="flex items-center gap-2 text-sm text-muted-foreground" data-testid={`text-whychoose-${i}`}>
                      <CheckCircle2 className="h-3.5 w-3.5 shrink-0 text-primary" />
                      {item}
                    </li>
                  ))}
                </ul>
              </div>

              <Card className="border-primary/20 bg-primary/5 p-5" data-testid="card-cta">
                <p className="text-sm font-medium" data-testid="text-cta">{detail.cta}</p>
                {isPremiumLocked && (
                  <Button size="sm" className="mt-3" asChild data-testid="button-detail-upgrade">
                    <Link href={isAuthenticated ? "/" : "/auth"}>
                      <Crown className="mr-1.5 h-3.5 w-3.5" />
                      {isAuthenticated ? "Upgrade to Premium" : "Sign In to Get Started"}
                    </Link>
                  </Button>
                )}
              </Card>

              {detail.faq && detail.faq.length > 0 && (
                <div data-testid="section-faq">
                  <h3 className="flex flex-wrap items-center gap-2 text-sm font-semibold" data-testid="text-faq-title">
                    <HelpCircle className="h-4 w-4 text-primary" />
                    Frequently Asked Questions
                  </h3>
                  <div className="mt-3 space-y-2">
                    {detail.faq.map((item, i) => (
                      <details
                        key={i}
                        className="group rounded-md border border-border"
                        data-testid={`faq-item-${i}`}
                      >
                        <summary
                          className="flex cursor-pointer items-center justify-between gap-2 p-3 text-sm font-medium select-none list-none [&::-webkit-details-marker]:hidden"
                          data-testid={`faq-question-${i}`}
                        >
                          <span>{item.question}</span>
                          <ArrowRight className="h-3.5 w-3.5 shrink-0 text-muted-foreground transition-transform group-open:rotate-90" />
                        </summary>
                        <div
                          className="border-t px-3 py-3 text-sm leading-relaxed text-muted-foreground"
                          data-testid={`faq-answer-${i}`}
                        >
                          {item.answer}
                        </div>
                      </details>
                    ))}
                  </div>
                </div>
              )}

              {relatedTools.length > 0 && (
                <div data-testid="section-related-tools">
                  <h3 className="flex flex-wrap items-center gap-2 text-sm font-semibold" data-testid="text-related-tools-title">
                    <Zap className="h-4 w-4 text-primary" />
                    Related Tools
                  </h3>
                  <div className="mt-3 grid gap-3 sm:grid-cols-2 lg:grid-cols-3">
                    {relatedTools.map((rt) => {
                      const RtIcon = iconMap[rt.icon];
                      return (
                        <Link key={rt.id} href={`/${rt.slug}`} data-testid={`link-related-tool-${rt.id}`}>
                          <Card className="p-3 hover-elevate transition-colors h-full">
                            <div className="flex items-start gap-3">
                              <div
                                className="flex h-8 w-8 shrink-0 items-center justify-center rounded-md"
                                style={{ backgroundColor: `hsl(${rt.color} / 0.1)` }}
                              >
                                {RtIcon && <RtIcon className="h-4 w-4" style={{ color: `hsl(${rt.color})` }} />}
                              </div>
                              <div className="min-w-0">
                                <p className="text-sm font-medium truncate" data-testid={`text-related-name-${rt.id}`}>{rt.name}</p>
                                <p className="text-xs text-muted-foreground line-clamp-2 mt-0.5" data-testid={`text-related-desc-${rt.id}`}>{rt.description}</p>
                              </div>
                            </div>
                          </Card>
                        </Link>
                      );
                    })}
                  </div>
                </div>
              )}
            </motion.div>
          )}
        </motion.div>
      </div>
    );
  }

  return (
    <div className="mx-auto max-w-6xl px-4 py-6 sm:px-6">
      {adModal}
      <motion.div initial={{ opacity: 0, y: 12 }} animate={{ opacity: 1, y: 0 }} transition={{ duration: 0.35 }}>
        <Link href="/" data-testid="link-back">
          <Button variant="ghost" size="sm" className="mb-4 -ml-2">
            <ArrowLeft className="mr-1 h-4 w-4" />
            All Tools
          </Button>
        </Link>

        <div className="flex flex-wrap items-center gap-3 mb-6">
          <div
            className="flex h-10 w-10 items-center justify-center rounded-md"
            style={{ backgroundColor: `hsl(${tool.color} / 0.1)` }}
          >
            {ToolIcon && <ToolIcon className="h-5 w-5" style={{ color: `hsl(${tool.color})` }} />}
          </div>
          <h1 className="text-lg font-bold tracking-tight sm:text-xl" data-testid="text-tool-name">
            {tool.name}
          </h1>
          {tool.isPremium && (
            <Badge variant="secondary" className="no-default-hover-elevate" data-testid="badge-premium">
              <Crown className="mr-1 h-3 w-3" /> Premium
            </Badge>
          )}
        </div>

        <div className={`flex flex-col ${showOptions ? "lg:flex-row" : ""} gap-6`}>
          <div className={`flex-1 min-w-0 ${showOptions ? "" : ""}`}>
            {isUrlTool ? (
              <Card className="p-6" data-testid="card-url-input">
                <div className="space-y-2">
                  <Label>Web Page URL</Label>
                  <Input
                    type="url"
                    placeholder="https://example.com"
                    value={webUrl}
                    onChange={(e) => setWebUrl(e.target.value)}
                    data-testid="input-web-url"
                  />
                </div>
              </Card>
            ) : (
              <div
                className={`relative rounded-md border-2 border-dashed p-6 transition-colors ${
                  isDragging ? "border-primary bg-primary/5" : "border-border"
                }`}
                onDragOver={handleDragOver}
                onDragLeave={handleDragLeave}
                onDrop={handleDrop}
                data-testid="dropzone"
              >
                <input
                  ref={fileInputRef}
                  type="file"
                  accept={getAcceptTypes()}
                  multiple={tool.acceptMultiple}
                  className="hidden"
                  onChange={(e) => e.target.files && addFiles(e.target.files)}
                  data-testid="input-file-upload"
                />

                <div className="grid grid-cols-2 sm:grid-cols-3 md:grid-cols-4 gap-4">
                  <AnimatePresence>
                    {files.map((file, idx) => (
                      <motion.div
                        key={file.id}
                        initial={{ opacity: 0, scale: 0.9 }}
                        animate={{ opacity: 1, scale: 1 }}
                        exit={{ opacity: 0, scale: 0.9 }}
                        transition={{ duration: 0.2 }}
                        draggable={tool.acceptMultiple && files.length > 1}
                        onDragStart={(e: any) => handleFileDragStart(e, idx)}
                        onDragOver={(e: any) => handleFileDragOver(e, idx)}
                        onDrop={(e: any) => handleFileDrop(e, idx)}
                        onDragEnd={handleFileDragEnd}
                        className={`relative group cursor-grab active:cursor-grabbing ${
                          draggedIdx === idx ? "opacity-40" : ""
                        } ${dragOverIdx === idx ? "scale-105" : ""}`}
                        style={{ transition: "transform 0.15s ease, opacity 0.15s ease" }}
                        data-testid={`card-file-${idx}`}
                      >
                        {dragOverIdx === idx && draggedIdx !== null && draggedIdx !== idx && (
                          <div
                            className="absolute inset-0 rounded-md border-2 border-primary bg-primary/10 z-20 pointer-events-none"
                            style={{ borderStyle: "solid" }}
                          />
                        )}
                        <Card className="p-2 relative">
                          <button
                            onClick={() => removeFile(file.id)}
                            className="absolute -top-2 -right-2 z-10 flex items-center justify-center rounded-full bg-destructive text-destructive-foreground shadow-sm"
                            style={{ width: "20px", height: "20px" }}
                            data-testid={`button-remove-file-${idx}`}
                          >
                            <X className="h-3 w-3" />
                          </button>

                          <div className="absolute top-1 left-1 z-10 flex items-center justify-center rounded-md bg-foreground/80 text-background"
                            style={{ width: "22px", height: "22px", fontSize: "11px", fontWeight: 700 }}
                            data-testid={`badge-file-number-${idx}`}
                          >
                            {idx + 1}
                          </div>

                          {tool.acceptMultiple && files.length > 1 && (
                            <div className="absolute top-1 right-1 z-10 flex items-center justify-center rounded-md bg-muted/80 text-muted-foreground"
                              style={{ width: "22px", height: "22px" }}
                              data-testid={`drag-handle-${idx}`}
                            >
                              <GripVertical className="h-3.5 w-3.5" />
                            </div>
                          )}

                          <PdfThumbnail
                            file={file.file}
                            onLoad={(url) => {
                              setFiles(prev => prev.map(f =>
                                f.id === file.id ? { ...f, thumbnailUrl: url } : f
                              ));
                            }}
                          />

                          <p className="mt-2 text-xs text-center truncate px-1" data-testid={`text-filename-${idx}`}>
                            {file.name}
                          </p>
                        </Card>
                      </motion.div>
                    ))}
                  </AnimatePresence>

                  {tool.acceptMultiple && (
                    <motion.div
                      initial={{ opacity: 0 }}
                      animate={{ opacity: 1 }}
                      className="flex items-center justify-center"
                    >
                      <button
                        onClick={() => fileInputRef.current?.click()}
                        disabled={tool.id === "merge" && !isPremiumUser && files.length >= getMergeLimit()}
                        className="flex flex-col items-center justify-center gap-2 rounded-md border-2 border-dashed border-border p-4 aspect-[3/4] w-full hover-elevate transition-colors disabled:opacity-40 disabled:cursor-not-allowed"
                        data-testid="button-add-more-files"
                      >
                        <div className="flex items-center justify-center rounded-full bg-primary text-primary-foreground" style={{ width: "28px", height: "28px" }}>
                          <Plus className="h-4 w-4" />
                        </div>
                        <span className="text-xs text-muted-foreground">Add more</span>
                      </button>
                    </motion.div>
                  )}
                </div>

                {tool.acceptMultiple && files.length > 1 && (
                  <p className="mt-3 text-xs text-muted-foreground text-center" data-testid="text-drag-hint">
                    <GripVertical className="inline h-3 w-3 -mt-0.5 mr-0.5" />
                    Drag and drop files to reorder them
                  </p>
                )}

                {tool.id === "merge" && !isPremiumUser && (
                  <div className="mt-4 space-y-3">
                    <div className="flex flex-wrap items-center justify-between gap-2 text-xs text-muted-foreground" data-testid="text-merge-limit-info">
                      <span>
                        {files.length} / {getMergeLimit()} files
                        {mergeAdUnlocked ? " (ad bonus active)" : ""}
                      </span>
                      {files.length >= FREE_MERGE_LIMIT && !mergeAdUnlocked && (
                        <Badge variant="secondary" className="no-default-hover-elevate" data-testid="badge-limit-reached">
                          <AlertTriangle className="mr-1 h-3 w-3" /> Limit reached
                        </Badge>
                      )}
                    </div>

                    {!mergeAdUnlocked && files.length >= FREE_MERGE_LIMIT && (
                      <Card className="p-4 border-amber-500/30 bg-amber-500/5" data-testid="card-merge-limit">
                        <div className="flex flex-col gap-3">
                          <div className="flex flex-wrap items-center gap-2">
                            <AlertTriangle className="h-4 w-4 text-amber-500 shrink-0" />
                            <p className="text-sm font-medium flex-1 min-w-0" data-testid="text-merge-limit-title">
                              Free merge limit reached ({FREE_MERGE_LIMIT} files)
                            </p>
                          </div>
                          <p className="text-xs text-muted-foreground" data-testid="text-merge-limit-desc">
                            Watch a short ad to unlock merging up to {AD_MERGE_LIMIT} files, or upgrade to Premium for unlimited merging.
                          </p>
                          <div className="flex flex-wrap items-center gap-2">
                            <Button
                              size="sm"
                              variant="outline"
                              onClick={startAdCountdown}
                              data-testid="button-watch-ad"
                            >
                              <Play className="mr-1.5 h-3.5 w-3.5" />
                              Watch Ad ({AD_MERGE_LIMIT} files)
                            </Button>
                            <Button size="sm" asChild data-testid="button-upgrade-merge">
                              <Link href="/">
                                <Crown className="mr-1.5 h-3.5 w-3.5" />
                                Upgrade
                              </Link>
                            </Button>
                          </div>
                        </div>
                      </Card>
                    )}

                    {mergeAdUnlocked && (
                      <div className="flex flex-wrap items-center gap-2 text-xs text-muted-foreground rounded-md border border-green-500/30 bg-green-500/5 p-3" data-testid="card-ad-unlocked">
                        <CheckCircle2 className="h-3.5 w-3.5 text-green-600 shrink-0" />
                        <span>Ad bonus active! Merge up to {AD_MERGE_LIMIT} files this session.</span>
                      </div>
                    )}
                  </div>
                )}
              </div>
            )}

            {isProcessing && (
              <motion.div
                initial={{ opacity: 0 }}
                animate={{ opacity: 1 }}
                className="mt-4"
              >
                <Progress value={progress} className="h-2" data-testid="progress-bar" />
                <p className="mt-2 text-center text-sm text-muted-foreground" data-testid="text-processing">
                  Processing your file{files.length > 1 ? "s" : ""}... This may take a moment.
                </p>
              </motion.div>
            )}

            {resultUrl && (
              <motion.div
                initial={{ opacity: 0, y: 8 }}
                animate={{ opacity: 1, y: 0 }}
                className="mt-4 flex justify-center"
              >
                <Button variant="outline" asChild data-testid="button-download">
                  <a href={resultUrl} download={resultFilename}>
                    <Download className="mr-2 h-4 w-4" />
                    Download Result
                  </a>
                </Button>
              </motion.div>
            )}
          </div>

          {showOptions && (
            <div className="w-full lg:w-72 xl:w-80 shrink-0">
              <Card className="p-4 space-y-4" data-testid="card-options">
                <h3 className="text-sm font-semibold" data-testid="text-options-title">
                  {tool.id === "compress" ? "" : "Options"}
                </h3>
                {renderOptions()}
              </Card>

              {isPremiumLocked && (
                <Card className="mt-4 p-4 border-primary/30 bg-primary/5" data-testid="card-premium-lock">
                  <div className="flex flex-wrap items-center gap-2">
                    <Crown className="h-4 w-4 text-primary shrink-0" />
                    <p className="text-xs text-muted-foreground flex-1 min-w-0" data-testid="text-premium-desc">
                      {isAuthenticated
                        ? "Upgrade to Premium to use this tool."
                        : "Sign in and upgrade to Premium."}
                    </p>
                    <Button size="sm" asChild data-testid="button-upgrade-prompt">
                      <Link href={isAuthenticated ? "/" : "/auth"}>
                        {isAuthenticated ? "Upgrade" : "Sign In"}
                      </Link>
                    </Button>
                  </div>
                </Card>
              )}

              <Button
                onClick={processFiles}
                disabled={!canProcess() || isPremiumLocked}
                className="w-full mt-4"
                style={!isPremiumLocked ? { backgroundColor: `hsl(${tool.color})` } : undefined}
                data-testid="button-process"
              >
                {isProcessing ? (
                  <>
                    <Loader2 className="mr-2 h-4 w-4 animate-spin" />
                    Processing...
                  </>
                ) : isPremiumLocked ? (
                  <>
                    <Lock className="mr-2 h-4 w-4" />
                    Premium Required
                  </>
                ) : (
                  <>
                    {tool.name}
                    <ArrowRight className="ml-2 h-4 w-4" />
                  </>
                )}
              </Button>
            </div>
          )}

          {!showOptions && (
            <div className="w-full lg:w-72 xl:w-80 shrink-0">
              {isPremiumLocked && (
                <Card className="mb-4 p-4 border-primary/30 bg-primary/5" data-testid="card-premium-lock">
                  <div className="flex flex-wrap items-center gap-2">
                    <Crown className="h-4 w-4 text-primary shrink-0" />
                    <p className="text-xs text-muted-foreground flex-1 min-w-0" data-testid="text-premium-desc">
                      {isAuthenticated ? "Upgrade to Premium." : "Sign in and upgrade."}
                    </p>
                    <Button size="sm" asChild data-testid="button-upgrade-prompt">
                      <Link href={isAuthenticated ? "/" : "/auth"}>
                        {isAuthenticated ? "Upgrade" : "Sign In"}
                      </Link>
                    </Button>
                  </div>
                </Card>
              )}

              <Button
                onClick={processFiles}
                disabled={!canProcess() || isPremiumLocked}
                className="w-full"
                style={!isPremiumLocked ? { backgroundColor: `hsl(${tool.color})` } : undefined}
                data-testid="button-process"
              >
                {isProcessing ? (
                  <>
                    <Loader2 className="mr-2 h-4 w-4 animate-spin" />
                    Processing...
                  </>
                ) : isPremiumLocked ? (
                  <>
                    <Lock className="mr-2 h-4 w-4" />
                    Premium Required
                  </>
                ) : (
                  <>
                    {tool.name}
                    <ArrowRight className="ml-2 h-4 w-4" />
                  </>
                )}
              </Button>
            </div>
          )}
        </div>
      </motion.div>
    </div>
  );
}
