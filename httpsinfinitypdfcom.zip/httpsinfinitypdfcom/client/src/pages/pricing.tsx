import { Fragment, useState, useEffect } from "react";
import { Card } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { Switch } from "@/components/ui/switch";
import {
  Accordion,
  AccordionContent,
  AccordionItem,
  AccordionTrigger,
} from "@/components/ui/accordion";
import {
  CheckCircle2,
  XCircle,
  ArrowRight,
  Zap,
  Building2,
  User,
  Info,
  Check,
  X,
  GraduationCap,
  Briefcase,
  Code,
} from "lucide-react";
import {
  Tooltip,
  TooltipContent,
  TooltipTrigger,
} from "@/components/ui/tooltip";

const faqs = [
  {
    category: "General Questions",
    items: [
      {
        q: "What do I get with the Free Plan?",
        a: "The Free plan gives you access to essential PDF tools including merge, split, compress, rotate, and more. You can process a limited number of documents per day with standard file size limits.",
      },
      {
        q: "Why should I upgrade to Premium?",
        a: "Premium unlocks unlimited document processing, removes all file size restrictions, gives you an ad-free experience, and provides access to advanced tools like OCR, digital signatures, and batch workflows.",
      },
      {
        q: "Can I switch plans if my needs change?",
        a: "Yes, you can upgrade or downgrade your plan at any time. When upgrading, you get immediate access to new features. When downgrading, your current benefits remain active until the end of your billing cycle.",
      },
    ],
  },
  {
    category: "Billing & Payments",
    items: [
      {
        q: "Can I share single billing for multiple accounts?",
        a: "Yes, our Premium plan supports up to 25 users under a single billing account with volume discounts available. For larger teams, contact our sales team.",
      },
      {
        q: "What payment methods do you accept?",
        a: "We accept all major credit cards (Visa, Mastercard, American Express), PayPal, and bank transfers for annual Business plans.",
      },
      {
        q: "Can you invoice me?",
        a: "Yes, invoicing is available for Business plans. Contact our sales team to set up invoicing for your organization.",
      },
    ],
  },
  {
    category: "Security & Technical Questions",
    items: [
      {
        q: "Is my data safe with InfinityPDF?",
        a: "Absolutely. All files are transmitted over secure HTTPS connections and processed on encrypted servers. Files are automatically deleted after processing. We never store, share, or access your document content.",
      },
      {
        q: "Will InfinityPDF work for my industry?",
        a: "InfinityPDF is designed for universal use across industries including legal, finance, education, healthcare, and more. Our Business plan offers additional compliance features and regional file processing.",
      },
    ],
  },
];

type FeatureValue = boolean | string;

interface ComparisonFeature {
  name: string;
  tooltip?: string;
  basic: FeatureValue;
  premium: FeatureValue;
  business: FeatureValue;
}

interface ComparisonSection {
  section: string;
  features: ComparisonFeature[];
}

const comparisonData: ComparisonSection[] = [
  {
    section: "Features",
    features: [
      { name: "Tools", basic: "Limited tools", premium: "All tools included", business: "All tools included" },
      { name: "Batch processing", basic: "Limited", premium: "Unlimited", business: "Unlimited", tooltip: "Process multiple files simultaneously" },
      { name: "Filesize per task", basic: "Limited", premium: "Unlimited", business: "Unlimited", tooltip: "Maximum file size allowed per processing task" },
      { name: "Teams", basic: false, premium: true, business: true },
      { name: "Volume discount", basic: false, premium: true, business: true },
      { name: "Workflows", basic: false, premium: true, business: true, tooltip: "Automate multi-step PDF operations" },
      { name: "Customer support", basic: "Basic", premium: "Preferential", business: "Dedicated support" },
      { name: "Ad-free service", basic: false, premium: true, business: true },
    ],
  },
  {
    section: "Applications",
    features: [
      { name: "Web", basic: true, premium: true, business: true },
      { name: "Desktop", basic: false, premium: true, business: true, tooltip: "Native desktop application for Windows and macOS" },
      { name: "Mobile", basic: false, premium: true, business: true },
    ],
  },
  {
    section: "e-Signature",
    features: [
      { name: "Simple eSignature (SES)", basic: "Limited", premium: "Unlimited", business: "Unlimited" },
      { name: "Signature Request (SES)", basic: "Limited", premium: "Unlimited", business: "Unlimited" },
      { name: "Advanced eSignature (AES)", basic: false, premium: "Starting at 5/month", business: "Custom" },
      { name: "Signed document custody", basic: true, premium: true, business: true },
      { name: "Audit Trail", basic: false, premium: true, business: true },
      { name: "Notifications & reminders", basic: false, premium: true, business: true },
      { name: "Custom branding", basic: false, premium: true, business: true, tooltip: "Add your company logo and colors to signatures" },
      { name: "Templates", basic: false, premium: true, business: true },
      { name: "Multiple requests", basic: false, premium: true, business: true },
    ],
  },
  {
    section: "Security",
    features: [
      { name: "Secure HTTPS connection", basic: true, premium: true, business: true },
      { name: "ISO 27001 certified", basic: true, premium: true, business: true },
      { name: "Single Sign On (SSO)", basic: false, premium: false, business: true },
      { name: "Regional file processing", basic: false, premium: false, business: true, tooltip: "Choose where your files are processed geographically" },
    ],
  },
];

function FeatureCell({ value }: { value: FeatureValue }) {
  if (typeof value === "boolean") {
    return value ? (
      <CheckCircle2 className="h-4 w-4 text-green-500 mx-auto" />
    ) : (
      <XCircle className="h-4 w-4 text-muted-foreground/40 mx-auto" />
    );
  }
  return <span className="text-sm">{value}</span>;
}

export default function PricingPage() {
  const [yearly, setYearly] = useState(true);
  const monthlyPrice = 7;
  const yearlyPrice = 4;
  const price = yearly ? yearlyPrice : monthlyPrice;
  const billedText = yearly ? `$${yearlyPrice * 12} Billed annually` : "Billed monthly";
  const savings = Math.round((1 - yearlyPrice / monthlyPrice) * 100);

  useEffect(() => {
    document.title = "Pricing Plans – InfinityPDF";
    const meta = document.querySelector('meta[name="description"]');
    if (meta) {
      meta.setAttribute("content", "Choose the InfinityPDF plan that suits you. Free, Premium, and Business plans with PDF tools, e-signatures, batch processing, and more.");
    }
    return () => {
      document.title = "InfinityPDF – Unlimited PDF Tools. One Powerful Platform.";
    };
  }, []);

  return (
    <div className="min-h-screen">
      <section className="py-14 sm:py-20">
        <div className="mx-auto max-w-5xl px-4 sm:px-6">
          <div className="text-center mb-10">
            <Badge variant="secondary" className="mb-4" data-testid="badge-pricing">Pricing</Badge>
            <h1 className="font-serif text-3xl font-bold sm:text-4xl" data-testid="text-pricing-title">
              Choose the plan that suits you
            </h1>
          </div>

          <div className="flex items-center justify-center gap-3 mb-10" data-testid="billing-toggle">
            <span className={`text-sm font-medium ${!yearly ? "text-foreground" : "text-muted-foreground"}`}>
              Monthly Billing
            </span>
            <Switch
              checked={yearly}
              onCheckedChange={setYearly}
              data-testid="switch-billing"
            />
            <span className={`text-sm font-medium ${yearly ? "text-foreground" : "text-muted-foreground"}`}>
              Yearly Billing
            </span>
            {yearly && (
              <Badge variant="default" className="ml-1" data-testid="badge-savings">
                -{savings}%
              </Badge>
            )}
          </div>

          <div className="grid gap-6 md:grid-cols-3 items-start">
            <Card className="p-6 sm:p-8" data-testid="card-plan-basic">
              <div className="flex items-center gap-3 mb-4">
                <div className="flex h-10 w-10 items-center justify-center rounded-md bg-muted">
                  <User className="h-5 w-5 text-muted-foreground" />
                </div>
                <div>
                  <h3 className="font-semibold text-lg">Basic</h3>
                  <p className="text-xs text-muted-foreground">1 user</p>
                </div>
              </div>

              <div className="mb-6">
                <div className="flex items-baseline gap-1">
                  <span className="text-4xl font-bold">Free</span>
                </div>
              </div>

              <Button variant="outline" className="w-full mb-6" asChild data-testid="button-start-free">
                <a href="/">
                  Start for free
                </a>
              </Button>

              <div className="space-y-3">
                <p className="text-sm font-medium text-muted-foreground">Free features include:</p>
                {[
                  "Access to essential InfinityPDF tools",
                  "Limited document processing",
                ].map((f) => (
                  <div key={f} className="flex items-start gap-2">
                    <CheckCircle2 className="h-4 w-4 text-green-500 mt-0.5 shrink-0" />
                    <span className="text-sm">{f}</span>
                  </div>
                ))}
              </div>
            </Card>

            <Card className="p-6 sm:p-8 border-primary/50 relative" data-testid="card-plan-premium">
              <Badge variant="default" className="absolute -top-3 left-1/2 -translate-x-1/2" data-testid="badge-popular">
                Most Popular
              </Badge>
              <div className="flex items-center gap-3 mb-4">
                <div className="flex h-10 w-10 items-center justify-center rounded-md bg-primary/10">
                  <Zap className="h-5 w-5 text-primary" />
                </div>
                <div>
                  <h3 className="font-semibold text-lg">Premium</h3>
                  <p className="text-xs text-muted-foreground">1 – 25 users</p>
                </div>
              </div>

              <div className="mb-6">
                <div className="flex items-baseline gap-1">
                  <span className="text-4xl font-bold">${price}</span>
                  <span className="text-muted-foreground">/ month</span>
                </div>
                <p className="text-xs text-muted-foreground mt-1">{billedText}</p>
              </div>

              <Button className="w-full mb-6" asChild data-testid="button-go-premium">
                <a href="/auth">
                  Go Premium
                  <ArrowRight className="ml-2 h-4 w-4" />
                </a>
              </Button>

              <div className="space-y-3">
                <p className="text-sm font-medium text-muted-foreground">Premium features include:</p>
                {[
                  "Full access to all InfinityPDF tools",
                  "Unlimited document processing",
                  "Access across Web, Mobile, and Desktop",
                  "Digital Signatures",
                  "Workflows",
                  "Ad-free experience",
                  "Priority customer support",
                ].map((f) => (
                  <div key={f} className="flex items-start gap-2">
                    <CheckCircle2 className="h-4 w-4 text-green-500 mt-0.5 shrink-0" />
                    <span className="text-sm">{f}</span>
                  </div>
                ))}
              </div>
            </Card>

            <Card className="p-6 sm:p-8" data-testid="card-plan-business">
              <div className="flex items-center gap-3 mb-4">
                <div className="flex h-10 w-10 items-center justify-center rounded-md bg-muted">
                  <Building2 className="h-5 w-5 text-muted-foreground" />
                </div>
                <div>
                  <h3 className="font-semibold text-lg">Business</h3>
                  <p className="text-xs text-muted-foreground">25+ users</p>
                </div>
              </div>

              <div className="mb-6">
                <div className="flex items-baseline gap-1">
                  <span className="text-4xl font-bold">Let's talk</span>
                </div>
                <p className="text-xs text-muted-foreground mt-1">Scalable solutions with custom pricing</p>
              </div>

              <Button variant="outline" className="w-full mb-6" asChild data-testid="button-contact-sales">
                <a href="/contact">
                  Contact sales
                </a>
              </Button>

              <div className="space-y-3">
                <p className="text-sm font-medium text-muted-foreground">What's included:</p>
                {[
                  "All Premium features",
                  "Custom contracts for scalability",
                  "Dedicated Account Manager",
                  "Single Sign On (SSO)",
                  "Regional file processing",
                ].map((f) => (
                  <div key={f} className="flex items-start gap-2">
                    <CheckCircle2 className="h-4 w-4 text-green-500 mt-0.5 shrink-0" />
                    <span className="text-sm">{f}</span>
                  </div>
                ))}
              </div>
            </Card>
          </div>

          <Card className="mt-6 p-6 sm:p-8 text-center" data-testid="card-education">
            <p className="text-sm text-muted-foreground">
              InfinityPDF is committed to supporting education. Are you a student or academic professional?{" "}
              <a href="/contact" className="font-medium text-foreground underline" data-testid="link-education">
                Get a full year of Premium for free
              </a>
            </p>
          </Card>
        </div>
      </section>

      <section className="py-14 sm:py-20 bg-card/50">
        <div className="mx-auto max-w-5xl px-4 sm:px-6">
          <h2 className="font-serif text-2xl font-bold sm:text-3xl text-center mb-10" data-testid="text-compare-title">
            Compare the plans
          </h2>

          <div className="overflow-x-auto">
            <table className="w-full min-w-[600px]" data-testid="table-compare">
              <thead>
                <tr className="border-b">
                  <th className="text-left py-3 pr-4 w-[40%]" />
                  <th className="py-3 px-2 text-center w-[20%]" data-testid="th-basic">
                    <div className="flex flex-col items-center gap-1">
                      <User className="h-5 w-5 text-muted-foreground" />
                      <span className="text-sm font-semibold">Basic</span>
                      <span className="text-xs text-muted-foreground">Best for simple use</span>
                    </div>
                  </th>
                  <th className="py-3 px-2 text-center w-[20%]" data-testid="th-premium">
                    <div className="flex flex-col items-center gap-1">
                      <Zap className="h-5 w-5 text-primary" />
                      <span className="text-sm font-semibold">Premium</span>
                      <span className="text-xs text-muted-foreground">Best for advanced use</span>
                    </div>
                  </th>
                  <th className="py-3 px-2 text-center w-[20%]" data-testid="th-business">
                    <div className="flex flex-col items-center gap-1">
                      <Building2 className="h-5 w-5 text-muted-foreground" />
                      <span className="text-sm font-semibold">Business</span>
                      <span className="text-xs text-muted-foreground">Best for growing teams</span>
                    </div>
                  </th>
                </tr>
              </thead>
              <tbody>
                {comparisonData.map((section) => (
                  <Fragment key={section.section}>
                    <tr>
                      <td colSpan={4} className="pt-6 pb-2">
                        <span className="text-sm font-semibold text-muted-foreground uppercase tracking-wide">
                          {section.section}
                        </span>
                      </td>
                    </tr>
                    {section.features.map((feature) => (
                      <tr key={feature.name} className="border-b last:border-b-0">
                        <td className="py-3 pr-4 text-sm flex items-center gap-1 flex-wrap">
                          {feature.name}
                          {feature.tooltip && (
                            <Tooltip>
                              <TooltipTrigger asChild>
                                <Info className="h-3.5 w-3.5 text-muted-foreground/50 shrink-0 cursor-help" />
                              </TooltipTrigger>
                              <TooltipContent>
                                <p className="text-xs max-w-[200px]">{feature.tooltip}</p>
                              </TooltipContent>
                            </Tooltip>
                          )}
                        </td>
                        <td className="py-3 px-2 text-center">
                          <FeatureCell value={feature.basic} />
                        </td>
                        <td className="py-3 px-2 text-center">
                          <FeatureCell value={feature.premium} />
                        </td>
                        <td className="py-3 px-2 text-center">
                          <FeatureCell value={feature.business} />
                        </td>
                      </tr>
                    ))}
                  </Fragment>
                ))}
              </tbody>
            </table>
          </div>

          <div className="grid gap-4 md:grid-cols-3 mt-8">
            <Button variant="outline" className="w-full" asChild data-testid="button-compare-basic">
              <a href="/">Start for free</a>
            </Button>
            <Button className="w-full" asChild data-testid="button-compare-premium">
              <a href="/auth">Go Premium</a>
            </Button>
            <Button variant="outline" className="w-full" asChild data-testid="button-compare-business">
              <a href="/contact">Contact sales</a>
            </Button>
          </div>
        </div>
      </section>

      <section className="py-14 sm:py-20" data-testid="section-free-vs-premium">
        <div className="mx-auto max-w-4xl px-4 sm:px-6">
          <div className="text-center mb-10">
            <h2 className="font-serif text-2xl font-bold sm:text-3xl" data-testid="text-free-vs-premium-title">
              Free vs Premium
            </h2>
            <p className="mt-3 text-muted-foreground text-sm max-w-lg mx-auto">
              See exactly what you get with each plan
            </p>
          </div>

          <Card className="p-0 overflow-visible" data-testid="card-free-vs-premium">
            <div className="overflow-x-auto">
              <table className="w-full" data-testid="table-free-vs-premium">
                <thead>
                  <tr className="border-b">
                    <th className="text-left py-4 px-6 w-[50%]">
                      <span className="text-sm font-semibold">Feature</span>
                    </th>
                    <th className="py-4 px-4 text-center w-[25%]" data-testid="th-free-plan">
                      <span className="text-sm font-semibold">Free Plan</span>
                    </th>
                    <th className="py-4 px-4 text-center w-[25%]" data-testid="th-premium-plan">
                      <span className="text-sm font-semibold text-primary">Premium Plan</span>
                    </th>
                  </tr>
                </thead>
                <tbody>
                  {[
                    { feature: "Tools available", free: "22 free tools", premium: "35 all tools", type: "text" as const },
                    { feature: "Merge file limit", free: "10 files", premium: "Unlimited", type: "text" as const },
                    { feature: "File size limit", free: "50MB", premium: "50MB", type: "text" as const },
                    { feature: "Processing speed", free: "Standard", premium: "Priority", type: "text" as const },
                    { feature: "OCR tools", free: false, premium: true, type: "bool" as const },
                    { feature: "Edit PDF", free: false, premium: true, type: "bool" as const },
                    { feature: "Compare PDF", free: false, premium: true, type: "bool" as const },
                    { feature: "HTML to PDF", free: false, premium: true, type: "bool" as const },
                    { feature: "Watermark", free: false, premium: true, type: "bool" as const },
                    { feature: "Sign PDF", free: false, premium: true, type: "bool" as const },
                    { feature: "Redact PDF", free: false, premium: true, type: "bool" as const },
                    { feature: "PDF Filler", free: false, premium: true, type: "bool" as const },
                    { feature: "File History", free: true, premium: true, type: "bool" as const },
                    { feature: "Secure Processing", free: true, premium: true, type: "bool" as const },
                    { feature: "Support", free: "Standard", premium: "Priority", type: "text" as const },
                  ].map((row, idx) => (
                    <tr key={row.feature} className={`border-b last:border-b-0 ${idx % 2 === 0 ? "bg-muted/30" : ""}`} data-testid={`row-feature-${row.feature.toLowerCase().replace(/\s+/g, "-")}`}>
                      <td className="py-3 px-6 text-sm font-medium">{row.feature}</td>
                      <td className="py-3 px-4 text-center">
                        {row.type === "bool" ? (
                          row.free ? (
                            <Check className="h-4 w-4 text-green-500 mx-auto" data-testid={`icon-free-check-${row.feature.toLowerCase().replace(/\s+/g, "-")}`} />
                          ) : (
                            <X className="h-4 w-4 text-muted-foreground/40 mx-auto" data-testid={`icon-free-x-${row.feature.toLowerCase().replace(/\s+/g, "-")}`} />
                          )
                        ) : (
                          <span className="text-sm text-muted-foreground" data-testid={`text-free-${row.feature.toLowerCase().replace(/\s+/g, "-")}`}>{row.free as string}</span>
                        )}
                      </td>
                      <td className="py-3 px-4 text-center">
                        {row.type === "bool" ? (
                          row.premium ? (
                            <Check className="h-4 w-4 text-green-500 mx-auto" data-testid={`icon-premium-check-${row.feature.toLowerCase().replace(/\s+/g, "-")}`} />
                          ) : (
                            <X className="h-4 w-4 text-muted-foreground/40 mx-auto" data-testid={`icon-premium-x-${row.feature.toLowerCase().replace(/\s+/g, "-")}`} />
                          )
                        ) : (
                          <span className="text-sm font-medium" data-testid={`text-premium-${row.feature.toLowerCase().replace(/\s+/g, "-")}`}>{row.premium as string}</span>
                        )}
                      </td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          </Card>

          <div className="mt-8 flex flex-wrap items-center justify-center gap-3">
            <Button variant="outline" asChild data-testid="button-fvp-start-free">
              <a href="/">Start for free</a>
            </Button>
            <Button asChild data-testid="button-fvp-go-premium">
              <a href="/auth">
                Go Premium
                <ArrowRight className="ml-2 h-4 w-4" />
              </a>
            </Button>
          </div>
        </div>
      </section>

      <section className="py-14 sm:py-20 bg-card/50" data-testid="section-who-is-it-for">
        <div className="mx-auto max-w-5xl px-4 sm:px-6">
          <div className="text-center mb-10">
            <h2 className="font-serif text-2xl font-bold sm:text-3xl" data-testid="text-who-is-it-for-title">
              Who is it for?
            </h2>
            <p className="mt-3 text-muted-foreground text-sm max-w-lg mx-auto">
              The right plan for every workflow
            </p>
          </div>

          <div className="grid gap-6 sm:grid-cols-2">
            <Card className="p-6" data-testid="card-persona-students">
              <div className="flex items-center gap-3 mb-3">
                <div className="flex h-10 w-10 items-center justify-center rounded-md bg-muted">
                  <GraduationCap className="h-5 w-5 text-muted-foreground" />
                </div>
                <h3 className="font-semibold">Students</h3>
              </div>
              <p className="text-sm text-muted-foreground leading-relaxed mb-4">
                Access essential tools for free. Merge lecture notes, compress assignments, and convert documents without any cost.
              </p>
              <Button variant="outline" size="sm" asChild data-testid="link-students-tools">
                <a href="/tools/merge-pdf">
                  Try Merge PDF
                  <ArrowRight className="ml-2 h-3 w-3" />
                </a>
              </Button>
            </Card>

            <Card className="p-6" data-testid="card-persona-professionals">
              <div className="flex items-center gap-3 mb-3">
                <div className="flex h-10 w-10 items-center justify-center rounded-md bg-muted">
                  <Briefcase className="h-5 w-5 text-muted-foreground" />
                </div>
                <h3 className="font-semibold">Professionals</h3>
              </div>
              <p className="text-sm text-muted-foreground leading-relaxed mb-4">
                Unlock advanced editing, signing, and redaction tools. Streamline your document workflows with priority processing.
              </p>
              <Button variant="outline" size="sm" asChild data-testid="link-professionals-tools">
                <a href="/tools/sign-pdf">
                  Try Sign PDF
                  <ArrowRight className="ml-2 h-3 w-3" />
                </a>
              </Button>
            </Card>

            <Card className="p-6" data-testid="card-persona-businesses">
              <div className="flex items-center gap-3 mb-3">
                <div className="flex h-10 w-10 items-center justify-center rounded-md bg-muted">
                  <Building2 className="h-5 w-5 text-muted-foreground" />
                </div>
                <h3 className="font-semibold">Businesses</h3>
              </div>
              <p className="text-sm text-muted-foreground leading-relaxed mb-4">
                Full suite of tools for document workflow automation. Manage teams, batch process files, and maintain compliance at scale.
              </p>
              <Button variant="outline" size="sm" asChild data-testid="link-businesses-tools">
                <a href="/tools/edit-pdf">
                  Try Edit PDF
                  <ArrowRight className="ml-2 h-3 w-3" />
                </a>
              </Button>
            </Card>

            <Card className="p-6" data-testid="card-persona-developers">
              <div className="flex items-center gap-3 mb-3">
                <div className="flex h-10 w-10 items-center justify-center rounded-md bg-muted">
                  <Code className="h-5 w-5 text-muted-foreground" />
                </div>
                <h3 className="font-semibold">Developers</h3>
              </div>
              <p className="text-sm text-muted-foreground leading-relaxed mb-4">
                HTML to PDF conversion and workflow automation. Integrate document processing into your applications seamlessly.
              </p>
              <Button variant="outline" size="sm" asChild data-testid="link-developers-tools">
                <a href="/tools/html-to-pdf">
                  Try HTML to PDF
                  <ArrowRight className="ml-2 h-3 w-3" />
                </a>
              </Button>
            </Card>
          </div>
        </div>
      </section>

      <section className="py-14 sm:py-20">
        <div className="mx-auto max-w-3xl px-4 sm:px-6">
          <h2 className="font-serif text-2xl font-bold sm:text-3xl text-center mb-3" data-testid="text-faq-title">
            Frequently Asked Questions
          </h2>
          <p className="text-center text-muted-foreground text-sm mb-10">
            Our support team answers these questions almost daily
          </p>

          <div className="space-y-8" data-testid="pricing-faq">
            {faqs.map((group) => (
              <div key={group.category}>
                <h3 className="text-sm font-semibold text-muted-foreground uppercase tracking-wide mb-3">
                  {group.category}
                </h3>
                <Accordion type="multiple">
                  {group.items.map((item, i) => (
                    <AccordionItem key={i} value={`${group.category}-${i}`}>
                      <AccordionTrigger className="text-left text-sm font-medium" data-testid={`faq-trigger-${group.category.replace(/\s+/g, "-").toLowerCase()}-${i}`}>
                        {item.q}
                      </AccordionTrigger>
                      <AccordionContent>
                        <p className="text-sm text-muted-foreground leading-relaxed">{item.a}</p>
                      </AccordionContent>
                    </AccordionItem>
                  ))}
                </Accordion>
              </div>
            ))}
          </div>
        </div>
      </section>

      <section className="py-14 sm:py-20 bg-card/50">
        <div className="mx-auto max-w-3xl px-4 sm:px-6 text-center">
          <h2 className="font-serif text-2xl font-bold sm:text-3xl" data-testid="text-cta-title">
            Become Premium
          </h2>
          <p className="mt-3 max-w-lg mx-auto text-muted-foreground text-sm">
            Empower your business with InfinityPDF. Streamline your document workflows,
            speed up approvals, and work smarter as a team.
          </p>
          <div className="mt-8 flex flex-wrap items-center justify-center gap-3">
            <Button size="lg" asChild data-testid="button-cta-premium">
              <a href="/auth">
                Go Premium
                <ArrowRight className="ml-2 h-4 w-4" />
              </a>
            </Button>
            <Button size="lg" variant="outline" asChild data-testid="button-cta-sales">
              <a href="/contact">Contact Sales</a>
            </Button>
          </div>
        </div>
      </section>
    </div>
  );
}
