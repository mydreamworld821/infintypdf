import { Badge } from "@/components/ui/badge";

export default function TermsPage() {
  return (
    <div className="min-h-screen py-16">
      <div className="mx-auto max-w-3xl px-4 sm:px-6">
        <div className="text-center mb-12">
          <Badge variant="secondary" className="mb-4" data-testid="badge-terms">Legal</Badge>
          <h1 className="font-serif text-3xl font-bold sm:text-4xl" data-testid="text-terms-title">
            Terms & Conditions
          </h1>
          <p className="text-muted-foreground mt-4">Last updated: {new Date().toLocaleDateString("en-US", { month: "long", day: "numeric", year: "numeric" })}</p>
        </div>

        <div className="space-y-8 text-sm text-muted-foreground leading-relaxed">
          <section>
            <h2 className="font-serif text-lg font-semibold text-foreground mb-3">1. Acceptance of Terms</h2>
            <p>By accessing and using InfinityPDF, you accept and agree to be bound by these terms and conditions. If you do not agree to these terms, please do not use our service.</p>
          </section>

          <section>
            <h2 className="font-serif text-lg font-semibold text-foreground mb-3">2. Description of Service</h2>
            <p>InfinityPDF provides online PDF processing tools including merging, splitting, converting, editing, compressing, and securing PDF documents. All tools are provided free of charge.</p>
          </section>

          <section>
            <h2 className="font-serif text-lg font-semibold text-foreground mb-3">3. User Responsibilities</h2>
            <p>You agree to use InfinityPDF only for lawful purposes. You are responsible for ensuring that you have the right to process any files you upload. You must not upload files containing malicious content.</p>
          </section>

          <section>
            <h2 className="font-serif text-lg font-semibold text-foreground mb-3">4. File Processing</h2>
            <p>Files are uploaded temporarily for processing and automatically deleted afterward. We do not guarantee permanent storage of any files. You are responsible for downloading your processed files promptly.</p>
          </section>

          <section>
            <h2 className="font-serif text-lg font-semibold text-foreground mb-3">5. Limitation of Liability</h2>
            <p>InfinityPDF is provided "as is" without warranties of any kind. We are not liable for any loss or damage resulting from the use of our service, including but not limited to data loss or file corruption.</p>
          </section>

          <section>
            <h2 className="font-serif text-lg font-semibold text-foreground mb-3">6. Service Availability</h2>
            <p>We strive to keep InfinityPDF available at all times but do not guarantee uninterrupted access. We may perform maintenance or updates that temporarily affect availability.</p>
          </section>

          <section>
            <h2 className="font-serif text-lg font-semibold text-foreground mb-3">7. Changes to Terms</h2>
            <p>We reserve the right to modify these terms at any time. Continued use of InfinityPDF after changes constitutes acceptance of the new terms.</p>
          </section>
        </div>
      </div>
    </div>
  );
}
