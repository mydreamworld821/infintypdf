import { Badge } from "@/components/ui/badge";
import { Card } from "@/components/ui/card";
import { FileText } from "lucide-react";

export default function PressPage() {
  return (
    <div className="min-h-screen py-16">
      <div className="mx-auto max-w-4xl px-4 sm:px-6">
        <div className="text-center mb-12">
          <Badge variant="secondary" className="mb-4" data-testid="badge-press">Company</Badge>
          <h1 className="font-serif text-3xl font-bold sm:text-4xl" data-testid="text-press-title">
            Press
          </h1>
          <p className="mx-auto mt-4 max-w-xl text-muted-foreground">
            Media resources and press information about InfinityPDF.
          </p>
        </div>

        <Card className="p-12 text-center" data-testid="card-press-empty">
          <div className="flex h-12 w-12 items-center justify-center rounded-md bg-primary/10 mx-auto mb-4">
            <FileText className="h-6 w-6 text-primary" />
          </div>
          <h3 className="font-semibold text-lg mb-2">Press Kit Coming Soon</h3>
          <p className="text-muted-foreground text-sm">
            For media inquiries, please contact us at press@infinitypdf.com.
            Our press kit with logos and brand assets will be available here soon.
          </p>
        </Card>
      </div>
    </div>
  );
}
