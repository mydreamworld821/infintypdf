import { Badge } from "@/components/ui/badge";
import { Card } from "@/components/ui/card";
import { FileText } from "lucide-react";

export default function BlogPage() {
  return (
    <div className="min-h-screen py-16">
      <div className="mx-auto max-w-4xl px-4 sm:px-6">
        <div className="text-center mb-12">
          <Badge variant="secondary" className="mb-4" data-testid="badge-blog">Company</Badge>
          <h1 className="font-serif text-3xl font-bold sm:text-4xl" data-testid="text-blog-title">
            Blog
          </h1>
          <p className="mx-auto mt-4 max-w-xl text-muted-foreground">
            Tips, guides, and updates from the InfinityPDF team.
          </p>
        </div>

        <Card className="p-12 text-center" data-testid="card-blog-empty">
          <div className="flex h-12 w-12 items-center justify-center rounded-md bg-primary/10 mx-auto mb-4">
            <FileText className="h-6 w-6 text-primary" />
          </div>
          <h3 className="font-semibold text-lg mb-2">Coming Soon</h3>
          <p className="text-muted-foreground text-sm">
            We are working on helpful guides and tips for getting the most out of InfinityPDF.
            Check back soon for our first posts.
          </p>
        </Card>
      </div>
    </div>
  );
}
