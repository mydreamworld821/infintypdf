import { Badge } from "@/components/ui/badge";
import { Card } from "@/components/ui/card";
import { Mail, MessageSquare, HelpCircle } from "lucide-react";

export default function ContactPage() {
  return (
    <div className="min-h-screen py-16">
      <div className="mx-auto max-w-4xl px-4 sm:px-6">
        <div className="text-center mb-12">
          <Badge variant="secondary" className="mb-4" data-testid="badge-contact">Company</Badge>
          <h1 className="font-serif text-3xl font-bold sm:text-4xl" data-testid="text-contact-title">
            Contact Us
          </h1>
          <p className="mx-auto mt-4 max-w-xl text-muted-foreground">
            Have a question or need help? We are here for you.
          </p>
        </div>

        <div className="grid gap-6 sm:grid-cols-3">
          <Card className="p-6 text-center" data-testid="card-contact-email">
            <div className="flex h-10 w-10 items-center justify-center rounded-md bg-primary/10 mx-auto mb-4">
              <Mail className="h-5 w-5 text-primary" />
            </div>
            <h3 className="font-semibold mb-2">Email</h3>
            <p className="text-sm text-muted-foreground">Send us an email and we will get back to you within 24 hours.</p>
            <p className="mt-3 text-sm font-medium text-foreground">support@infinitypdf.com</p>
          </Card>

          <Card className="p-6 text-center" data-testid="card-contact-feedback">
            <div className="flex h-10 w-10 items-center justify-center rounded-md bg-primary/10 mx-auto mb-4">
              <MessageSquare className="h-5 w-5 text-primary" />
            </div>
            <h3 className="font-semibold mb-2">Feedback</h3>
            <p className="text-sm text-muted-foreground">We love hearing from our users. Share your ideas and suggestions.</p>
            <p className="mt-3 text-sm font-medium text-foreground">info@infinitypdf.com</p>
          </Card>

          <Card className="p-6 text-center" data-testid="card-contact-support">
            <div className="flex h-10 w-10 items-center justify-center rounded-md bg-primary/10 mx-auto mb-4">
              <HelpCircle className="h-5 w-5 text-primary" />
            </div>
            <h3 className="font-semibold mb-2">Help Center</h3>
            <p className="text-sm text-muted-foreground">Check our FAQ for quick answers to common questions.</p>
            <a href="/faq" className="mt-3 text-sm font-medium text-foreground underline inline-block" data-testid="link-faq">Visit FAQ</a>
          </Card>
        </div>
      </div>
    </div>
  );
}
