import { Card } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { useAuth } from "@/hooks/use-auth";
import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { apiRequest } from "@/lib/queryClient";
import { useToast } from "@/hooks/use-toast";
import { Redirect } from "wouter";
import {
  ShieldCheck, Users, CreditCard, CheckCircle2, XCircle,
  Clock, Loader2, Crown, ArrowLeft, AlertCircle,
} from "lucide-react";
import { Textarea } from "@/components/ui/textarea";
import { Label } from "@/components/ui/label";
import { useState } from "react";
import {
  Dialog,
  DialogContent,
  DialogHeader,
  DialogTitle,
} from "@/components/ui/dialog";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import { Link } from "wouter";

type OrderWithUser = {
  id: string;
  userId: string;
  planId: string;
  billingCycle: string;
  amount: number;
  currency: string;
  status: string;
  paymentReference: string | null;
  adminNote: string | null;
  createdAt: string | null;
  updatedAt: string | null;
  userEmail: string | null;
  userName: string | null;
};

type AdminUser = {
  id: string;
  email: string | null;
  firstName: string | null;
  lastName: string | null;
  isAdmin: boolean;
  premiumStatus: string;
  premiumApprovedAt: string | null;
  createdAt: string | null;
};

export default function AdminPage() {
  const { user, isLoading } = useAuth();

  if (isLoading) {
    return (
      <div className="flex min-h-[60vh] items-center justify-center">
        <Loader2 className="h-8 w-8 animate-spin text-muted-foreground" />
      </div>
    );
  }

  if (!user?.isAdmin) {
    return <Redirect to="/" />;
  }

  return (
    <div className="mx-auto max-w-7xl px-4 py-8 sm:px-6">
      <div className="flex items-center gap-3 mb-6 flex-wrap">
        <Button variant="outline" size="icon" asChild data-testid="button-back-dashboard">
          <Link href="/"><ArrowLeft className="h-4 w-4" /></Link>
        </Button>
        <div>
          <h1 className="text-2xl font-bold tracking-tight flex items-center gap-2" data-testid="text-admin-title">
            <ShieldCheck className="h-6 w-6" /> Admin Panel
          </h1>
          <p className="text-sm text-muted-foreground">Manage orders, users, and premium access</p>
        </div>
      </div>

      <Tabs defaultValue="orders">
        <TabsList data-testid="admin-tabs">
          <TabsTrigger value="orders" data-testid="admin-tab-orders">
            <CreditCard className="mr-1.5 h-4 w-4" /> Orders
          </TabsTrigger>
          <TabsTrigger value="users" data-testid="admin-tab-users">
            <Users className="mr-1.5 h-4 w-4" /> Users
          </TabsTrigger>
        </TabsList>

        <TabsContent value="orders">
          <OrdersManagement />
        </TabsContent>
        <TabsContent value="users">
          <UsersManagement />
        </TabsContent>
      </Tabs>
    </div>
  );
}

function OrdersManagement() {
  const queryClient = useQueryClient();
  const { toast } = useToast();
  const [selectedOrder, setSelectedOrder] = useState<OrderWithUser | null>(null);
  const [adminNote, setAdminNote] = useState("");
  const [newStatus, setNewStatus] = useState("");

  const { data: orders, isLoading } = useQuery<OrderWithUser[]>({
    queryKey: ["/api/admin/orders"],
  });

  const updateMutation = useMutation({
    mutationFn: async ({ id, status, adminNote }: { id: string; status: string; adminNote: string }) => {
      const res = await apiRequest("PATCH", `/api/admin/orders/${id}`, { status, adminNote });
      return res.json();
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/admin/orders"] });
      queryClient.invalidateQueries({ queryKey: ["/api/admin/users"] });
      toast({ title: "Order updated" });
      setSelectedOrder(null);
      setAdminNote("");
    },
    onError: (err: any) => {
      toast({ title: "Error", description: err.message, variant: "destructive" });
    },
  });

  if (isLoading) {
    return (
      <div className="flex items-center justify-center py-16">
        <Loader2 className="h-6 w-6 animate-spin text-muted-foreground" />
      </div>
    );
  }

  if (!orders || orders.length === 0) {
    return (
      <Card className="mt-4 p-8 text-center" data-testid="card-no-admin-orders">
        <CreditCard className="mx-auto h-10 w-10 text-muted-foreground/40" />
        <h3 className="mt-3 font-medium">No orders yet</h3>
        <p className="mt-1 text-sm text-muted-foreground">Orders from users will appear here.</p>
      </Card>
    );
  }

  return (
    <div className="mt-4 space-y-3" data-testid="admin-orders-list">
      {orders.map((order) => (
        <Card key={order.id} className="p-4" data-testid={`admin-order-${order.id}`}>
          <div className="flex items-start justify-between gap-4 flex-wrap">
            <div>
              <div className="flex items-center gap-2 flex-wrap">
                <span className="text-sm font-medium capitalize">{order.planId} Plan</span>
                <Badge variant="secondary" className="text-xs capitalize">{order.billingCycle}</Badge>
                <OrderStatusBadge status={order.status} />
              </div>
              <p className="mt-1 text-sm text-muted-foreground">
                {order.userName || "Unknown"} &middot; {order.userEmail || "No email"}
              </p>
              <p className="text-xs text-muted-foreground">
                ${(order.amount / 100).toFixed(2)} {order.currency} &middot; {order.createdAt ? new Date(order.createdAt).toLocaleString() : ""}
              </p>
              {order.paymentReference && (
                <p className="mt-1 text-xs">
                  <span className="text-muted-foreground">Payment Ref:</span> {order.paymentReference}
                </p>
              )}
              {order.adminNote && (
                <p className="mt-1 text-xs text-muted-foreground italic">Note: {order.adminNote}</p>
              )}
            </div>
            <div className="flex items-center gap-2 flex-wrap">
              {order.status === "pending" && (
                <>
                  <Button
                    size="sm"
                    onClick={() => updateMutation.mutate({ id: order.id, status: "approved", adminNote: "" })}
                    disabled={updateMutation.isPending}
                    data-testid={`button-approve-${order.id}`}
                  >
                    <CheckCircle2 className="mr-1 h-3 w-3" /> Approve
                  </Button>
                  <Button
                    size="sm"
                    variant="outline"
                    onClick={() => {
                      setSelectedOrder(order);
                      setNewStatus("rejected");
                      setAdminNote("");
                    }}
                    data-testid={`button-reject-${order.id}`}
                  >
                    <XCircle className="mr-1 h-3 w-3" /> Reject
                  </Button>
                </>
              )}
              <Button
                size="sm"
                variant="outline"
                onClick={() => {
                  setSelectedOrder(order);
                  setNewStatus(order.status);
                  setAdminNote(order.adminNote || "");
                }}
                data-testid={`button-edit-order-${order.id}`}
              >
                Edit
              </Button>
            </div>
          </div>
        </Card>
      ))}

      <Dialog open={!!selectedOrder} onOpenChange={(open) => !open && setSelectedOrder(null)}>
        <DialogContent>
          <DialogHeader>
            <DialogTitle>Update Order</DialogTitle>
          </DialogHeader>
          <div className="space-y-4 pt-2">
            <div>
              <Label>Status</Label>
              <Select value={newStatus} onValueChange={setNewStatus}>
                <SelectTrigger data-testid="select-order-status">
                  <SelectValue />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="pending">Pending</SelectItem>
                  <SelectItem value="approved">Approved</SelectItem>
                  <SelectItem value="rejected">Rejected</SelectItem>
                </SelectContent>
              </Select>
            </div>
            <div>
              <Label>Admin Note</Label>
              <Textarea
                value={adminNote}
                onChange={(e) => setAdminNote(e.target.value)}
                placeholder="Add a note for this order..."
                data-testid="input-admin-note"
              />
            </div>
            <Button
              className="w-full"
              onClick={() => {
                if (selectedOrder) {
                  updateMutation.mutate({ id: selectedOrder.id, status: newStatus, adminNote });
                }
              }}
              disabled={updateMutation.isPending}
              data-testid="button-save-order"
            >
              {updateMutation.isPending && <Loader2 className="mr-2 h-4 w-4 animate-spin" />}
              Save Changes
            </Button>
          </div>
        </DialogContent>
      </Dialog>
    </div>
  );
}

function UsersManagement() {
  const queryClient = useQueryClient();
  const { toast } = useToast();

  const { data: users, isLoading } = useQuery<AdminUser[]>({
    queryKey: ["/api/admin/users"],
  });

  const updatePremiumMutation = useMutation({
    mutationFn: async ({ userId, premiumStatus }: { userId: string; premiumStatus: string }) => {
      const res = await apiRequest("PATCH", `/api/admin/users/${userId}/premium`, { premiumStatus });
      return res.json();
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/admin/users"] });
      toast({ title: "User updated" });
    },
    onError: (err: any) => {
      toast({ title: "Error", description: err.message, variant: "destructive" });
    },
  });

  if (isLoading) {
    return (
      <div className="flex items-center justify-center py-16">
        <Loader2 className="h-6 w-6 animate-spin text-muted-foreground" />
      </div>
    );
  }

  if (!users || users.length === 0) {
    return (
      <Card className="mt-4 p-8 text-center">
        <Users className="mx-auto h-10 w-10 text-muted-foreground/40" />
        <h3 className="mt-3 font-medium">No users yet</h3>
      </Card>
    );
  }

  return (
    <div className="mt-4 space-y-3" data-testid="admin-users-list">
      {users.map((u) => (
        <Card key={u.id} className="p-4" data-testid={`admin-user-${u.id}`}>
          <div className="flex items-center justify-between gap-4 flex-wrap">
            <div>
              <div className="flex items-center gap-2 flex-wrap">
                <span className="text-sm font-medium">
                  {u.firstName || ""} {u.lastName || ""}
                </span>
                {u.isAdmin && (
                  <Badge variant="default" className="text-xs">
                    <ShieldCheck className="mr-0.5 h-3 w-3" /> Admin
                  </Badge>
                )}
                <PremiumStatusBadge status={u.premiumStatus} />
              </div>
              <p className="mt-0.5 text-xs text-muted-foreground">{u.email || "No email"}</p>
              <p className="text-xs text-muted-foreground">
                Joined {u.createdAt ? new Date(u.createdAt).toLocaleDateString() : "Unknown"}
              </p>
            </div>
            <div className="flex items-center gap-2 flex-wrap">
              <Select
                value={u.premiumStatus}
                onValueChange={(val) => updatePremiumMutation.mutate({ userId: u.id, premiumStatus: val })}
              >
                <SelectTrigger className="w-[140px]" data-testid={`select-premium-${u.id}`}>
                  <SelectValue />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="none">None</SelectItem>
                  <SelectItem value="pending">Pending</SelectItem>
                  <SelectItem value="active">Active</SelectItem>
                  <SelectItem value="rejected">Rejected</SelectItem>
                </SelectContent>
              </Select>
            </div>
          </div>
        </Card>
      ))}
    </div>
  );
}

function OrderStatusBadge({ status }: { status: string }) {
  switch (status) {
    case "approved":
      return <Badge variant="default" className="text-xs"><CheckCircle2 className="mr-1 h-3 w-3" /> Approved</Badge>;
    case "rejected":
      return <Badge variant="destructive" className="text-xs"><XCircle className="mr-1 h-3 w-3" /> Rejected</Badge>;
    case "pending":
      return <Badge variant="secondary" className="text-xs"><Clock className="mr-1 h-3 w-3" /> Pending</Badge>;
    default:
      return <Badge variant="secondary" className="text-xs">{status}</Badge>;
  }
}

function PremiumStatusBadge({ status }: { status: string }) {
  switch (status) {
    case "active":
      return <Badge variant="default" className="text-xs"><Crown className="mr-1 h-3 w-3" /> Premium</Badge>;
    case "pending":
      return <Badge variant="secondary" className="text-xs"><Clock className="mr-1 h-3 w-3" /> Pending</Badge>;
    case "rejected":
      return <Badge variant="destructive" className="text-xs"><XCircle className="mr-1 h-3 w-3" /> Rejected</Badge>;
    default:
      return <Badge variant="secondary" className="text-xs">Free</Badge>;
  }
}
