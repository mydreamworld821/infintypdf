import { Badge } from "@/components/ui/badge";
import { Card } from "@/components/ui/card";
import { Heart, Users, Globe } from "lucide-react";
import logoImg from "@assets/ChatGPT_Image_Feb_13,_2026,_08_10_21_PM_1770995717930.png";

const values = [
  {
    icon: Heart,
    title: "Free for Everyone",
    description: "We believe PDF tools should be accessible to everyone, which is why all 35 tools are completely free.",
  },
  {
    icon: Users,
    title: "User First",
    description: "Every feature we build starts with our users' needs. Simple, fast, and reliable tools.",
  },
  {
    icon: Globe,
    title: "Accessible Anywhere",
    description: "Use InfinityPDF from any device, anywhere in the world, without installing any software.",
  },
];

export default function AboutPage() {
  return (
    <div className="min-h-screen py-16">
      <div className="mx-auto max-w-4xl px-4 sm:px-6">
        <div className="text-center mb-12">
          <Badge variant="secondary" className="mb-4" data-testid="badge-about">Company</Badge>
          <h1 className="font-serif text-3xl font-bold sm:text-4xl" data-testid="text-about-title">
            About InfinityPDF
          </h1>
          <p className="mx-auto mt-4 max-w-xl text-muted-foreground">
            Making PDF management simple, fast, and free for everyone.
          </p>
        </div>

        <div className="mb-12">
          <Card className="p-8">
            <div className="flex items-center gap-3 mb-4">
              <img src={logoImg} alt="InfinityPDF" className="h-10 w-10 rounded-md object-cover" />
              <h2 className="font-serif text-xl font-bold">Our Mission</h2>
            </div>
            <p className="text-muted-foreground leading-relaxed">
              InfinityPDF was created with a simple goal: provide powerful PDF tools that anyone can use,
              without the complexity of desktop software or the cost of premium subscriptions. We offer
              35 professional-grade PDF tools covering everything from basic operations like merging and
              splitting to advanced features like OCR, document comparison, and workflow automation.
            </p>
          </Card>
        </div>

        <div className="grid gap-6 sm:grid-cols-3 mb-12">
          {values.map((value) => (
            <Card key={value.title} className="p-6 text-center" data-testid={`card-value-${value.title.toLowerCase().replace(/\s+/g, "-")}`}>
              <div className="flex h-10 w-10 items-center justify-center rounded-md bg-primary/10 mx-auto mb-4">
                <value.icon className="h-5 w-5 text-primary" />
              </div>
              <h3 className="font-semibold mb-2">{value.title}</h3>
              <p className="text-sm text-muted-foreground">{value.description}</p>
            </Card>
          ))}
        </div>
      </div>
    </div>
  );
}
