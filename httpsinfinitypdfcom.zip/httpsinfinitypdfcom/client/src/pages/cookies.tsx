import { Badge } from "@/components/ui/badge";

export default function CookiesPage() {
  return (
    <div className="min-h-screen py-16">
      <div className="mx-auto max-w-3xl px-4 sm:px-6">
        <div className="text-center mb-12">
          <Badge variant="secondary" className="mb-4" data-testid="badge-cookies">Legal</Badge>
          <h1 className="font-serif text-3xl font-bold sm:text-4xl" data-testid="text-cookies-title">
            Cookie Policy
          </h1>
          <p className="text-muted-foreground mt-4">Last updated: {new Date().toLocaleDateString("en-US", { month: "long", day: "numeric", year: "numeric" })}</p>
        </div>

        <div className="space-y-8 text-sm text-muted-foreground leading-relaxed">
          <section>
            <h2 className="font-serif text-lg font-semibold text-foreground mb-3">What Are Cookies</h2>
            <p>Cookies are small text files stored on your device when you visit a website. They help the website remember your preferences and improve your experience.</p>
          </section>

          <section>
            <h2 className="font-serif text-lg font-semibold text-foreground mb-3">Cookies We Use</h2>
            <p>InfinityPDF uses only essential cookies required for the service to function:</p>
            <ul className="list-disc list-inside mt-2 space-y-1">
              <li><strong className="text-foreground">Session Cookie</strong> - Maintains your login session when you sign in. Expires when you close your browser or after 7 days.</li>
              <li><strong className="text-foreground">Theme Preference</strong> - Remembers your light/dark mode preference. Stored in localStorage, not as a cookie.</li>
            </ul>
          </section>

          <section>
            <h2 className="font-serif text-lg font-semibold text-foreground mb-3">Third-Party Cookies</h2>
            <p>We do not use any third-party cookies for tracking, advertising, or analytics purposes.</p>
          </section>

          <section>
            <h2 className="font-serif text-lg font-semibold text-foreground mb-3">Managing Cookies</h2>
            <p>You can control and delete cookies through your browser settings. Disabling cookies may affect the functionality of InfinityPDF, particularly the sign-in feature.</p>
          </section>
        </div>
      </div>
    </div>
  );
}
