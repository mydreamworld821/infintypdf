import { useEffect, useState } from "react";
import { Card } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { useAuth } from "@/hooks/use-auth";
import { useToast } from "@/hooks/use-toast";
import { useLocation } from "wouter";
import { useMutation, useQueryClient } from "@tanstack/react-query";
import { apiRequest } from "@/lib/queryClient";
import {
  Shield,
  Zap,
  Lock,
  CheckCircle2,
  Eye,
  EyeOff,
  Loader2,
} from "lucide-react";
import logoImg from "@assets/ChatGPT_Image_Feb_13,_2026,_08_10_21_PM_1770995717930.png";

const benefits = [
  { icon: Zap, text: "Unlimited PDF processing" },
  { icon: Shield, text: "Secure file handling" },
  { icon: Lock, text: "Your files are always private" },
];

const passwordRules = [
  { test: (p: string) => p.length >= 8, label: "At least 8 characters" },
  { test: (p: string) => /[A-Z]/.test(p), label: "One uppercase letter" },
  { test: (p: string) => /[a-z]/.test(p), label: "One lowercase letter" },
  { test: (p: string) => /[0-9]/.test(p), label: "One number" },
  { test: (p: string) => /[^A-Za-z0-9]/.test(p), label: "One special character" },
];

export default function AuthPage() {
  const { isAuthenticated, isLoading } = useAuth();
  const [, navigate] = useLocation();
  const { toast } = useToast();
  const queryClient = useQueryClient();
  const [activeTab, setActiveTab] = useState("signin");

  const [loginEmail, setLoginEmail] = useState("");
  const [loginPassword, setLoginPassword] = useState("");
  const [showLoginPassword, setShowLoginPassword] = useState(false);

  const [signupName, setSignupName] = useState("");
  const [signupEmail, setSignupEmail] = useState("");
  const [signupPassword, setSignupPassword] = useState("");
  const [showSignupPassword, setShowSignupPassword] = useState(false);

  useEffect(() => {
    if (!isLoading && isAuthenticated) {
      navigate("/");
    }
  }, [isAuthenticated, isLoading, navigate]);

  useEffect(() => {
    document.title = "Sign In – InfinityPDF";
    const meta = document.querySelector('meta[name="description"]');
    if (meta) {
      meta.setAttribute("content", "Sign in or create a free InfinityPDF account. Access 35 PDF tools with Google, GitHub, Apple, or email login.");
    }
    return () => {
      document.title = "InfinityPDF – Unlimited PDF Tools. One Powerful Platform.";
    };
  }, []);

  const loginMutation = useMutation({
    mutationFn: async (data: { email: string; password: string }) => {
      const res = await apiRequest("POST", "/api/auth/login", data);
      return res.json();
    },
    onSuccess: async () => {
      await queryClient.invalidateQueries({ queryKey: ["/api/auth/user"] });
      navigate("/");
    },
    onError: (error: Error) => {
      const msg = error.message.includes(":")
        ? error.message.split(": ").slice(1).join(": ")
        : error.message;
      toast({ title: "Sign in failed", description: msg, variant: "destructive" });
    },
  });

  const registerMutation = useMutation({
    mutationFn: async (data: { name: string; email: string; password: string }) => {
      const res = await apiRequest("POST", "/api/auth/register", data);
      return res.json();
    },
    onSuccess: async () => {
      await queryClient.invalidateQueries({ queryKey: ["/api/auth/user"] });
      navigate("/");
    },
    onError: (error: Error) => {
      const msg = error.message.includes(":")
        ? error.message.split(": ").slice(1).join(": ")
        : error.message;
      toast({ title: "Sign up failed", description: msg, variant: "destructive" });
    },
  });

  const handleLogin = (e: React.FormEvent) => {
    e.preventDefault();
    loginMutation.mutate({ email: loginEmail, password: loginPassword });
  };

  const handleRegister = (e: React.FormEvent) => {
    e.preventDefault();
    registerMutation.mutate({ name: signupName, email: signupEmail, password: signupPassword });
  };

  const allRulesPassed = passwordRules.every((r) => r.test(signupPassword));

  if (isLoading) {
    return (
      <div className="flex min-h-[60vh] items-center justify-center">
        <div className="h-8 w-8 animate-spin rounded-full border-2 border-primary border-t-transparent" />
      </div>
    );
  }

  return (
    <div className="min-h-[calc(100vh-3.5rem)]">
      <div className="grid min-h-[calc(100vh-3.5rem)] lg:grid-cols-2">
        <div className="hidden lg:flex flex-col justify-between bg-primary/5 p-10 xl:p-14">
          <div>
            <div className="flex items-center gap-2 mb-12">
              <img src={logoImg} alt="InfinityPDF" className="h-10 w-10 rounded-md object-cover" />
              <span className="text-xl font-semibold tracking-tight">InfinityPDF</span>
            </div>

            <h1 className="font-serif text-3xl font-bold tracking-tight xl:text-4xl mb-4">
              Everything you need for PDF management
            </h1>
            <p className="text-muted-foreground max-w-md leading-relaxed">
              Join thousands of users who trust InfinityPDF for their document workflows.
              Merge, split, compress, convert, and protect your PDFs with ease.
            </p>

            <div className="mt-10 space-y-4">
              {benefits.map((b) => (
                <div key={b.text} className="flex items-center gap-3">
                  <div className="flex h-9 w-9 items-center justify-center rounded-md bg-primary/10 shrink-0">
                    <b.icon className="h-4 w-4 text-primary" />
                  </div>
                  <span className="text-sm font-medium">{b.text}</span>
                </div>
              ))}
            </div>
          </div>

          <p className="text-xs text-muted-foreground mt-8">
            &copy; {new Date().getFullYear()} InfinityPDF. All rights reserved.
          </p>
        </div>

        <div className="flex items-center justify-center p-6 sm:p-10">
          <div className="w-full max-w-md">
            <div className="text-center mb-8 lg:hidden">
              <div className="flex items-center justify-center gap-2 mb-4">
                <img src={logoImg} alt="InfinityPDF" className="h-10 w-10 rounded-md object-cover" />
                <span className="text-xl font-semibold tracking-tight">InfinityPDF</span>
              </div>
            </div>

            <Tabs value={activeTab} onValueChange={setActiveTab} className="w-full">
              <TabsList className="w-full mb-6" data-testid="auth-tabs">
                <TabsTrigger value="signin" className="flex-1" data-testid="tab-signin">
                  Sign In
                </TabsTrigger>
                <TabsTrigger value="signup" className="flex-1" data-testid="tab-signup">
                  Sign Up
                </TabsTrigger>
              </TabsList>

              <TabsContent value="signin">
                <Card className="p-6 sm:p-8">
                  <div className="text-center mb-6">
                    <h2 className="text-xl font-bold mb-1" data-testid="text-auth-heading">
                      Welcome back
                    </h2>
                    <p className="text-sm text-muted-foreground">
                      Sign in to access your PDF tools and history
                    </p>
                  </div>

                  <form onSubmit={handleLogin} className="space-y-4">
                    <div className="space-y-2">
                      <Label htmlFor="login-email">Email</Label>
                      <Input
                        id="login-email"
                        type="email"
                        placeholder="you@example.com"
                        value={loginEmail}
                        onChange={(e) => setLoginEmail(e.target.value)}
                        required
                        data-testid="input-login-email"
                      />
                    </div>

                    <div className="space-y-2">
                      <Label htmlFor="login-password">Password</Label>
                      <div className="relative">
                        <Input
                          id="login-password"
                          type={showLoginPassword ? "text" : "password"}
                          placeholder="Enter your password"
                          value={loginPassword}
                          onChange={(e) => setLoginPassword(e.target.value)}
                          required
                          className="pr-10"
                          data-testid="input-login-password"
                        />
                        <button
                          type="button"
                          onClick={() => setShowLoginPassword(!showLoginPassword)}
                          className="absolute right-3 top-1/2 -translate-y-1/2 text-muted-foreground"
                          data-testid="button-toggle-login-password"
                          aria-label={showLoginPassword ? "Hide password" : "Show password"}
                        >
                          {showLoginPassword ? (
                            <EyeOff className="h-4 w-4" />
                          ) : (
                            <Eye className="h-4 w-4" />
                          )}
                        </button>
                      </div>
                    </div>

                    <Button
                      type="submit"
                      className="w-full"
                      disabled={loginMutation.isPending}
                      data-testid="button-login-submit"
                    >
                      {loginMutation.isPending ? (
                        <Loader2 className="h-4 w-4 animate-spin mr-2" />
                      ) : null}
                      Sign In
                    </Button>
                  </form>

                  <p className="mt-6 text-center text-xs text-muted-foreground">
                    Don't have an account?{" "}
                    <button
                      onClick={() => setActiveTab("signup")}
                      className="font-medium text-foreground underline"
                      data-testid="link-switch-signup"
                    >
                      Sign up for free
                    </button>
                  </p>
                </Card>
              </TabsContent>

              <TabsContent value="signup">
                <Card className="p-6 sm:p-8">
                  <div className="text-center mb-6">
                    <h2 className="text-xl font-bold mb-1" data-testid="text-signup-heading">
                      Create your account
                    </h2>
                    <p className="text-sm text-muted-foreground">
                      Get started with InfinityPDF for free
                    </p>
                  </div>

                  <form onSubmit={handleRegister} className="space-y-4">
                    <div className="space-y-2">
                      <Label htmlFor="signup-name">Full Name</Label>
                      <Input
                        id="signup-name"
                        type="text"
                        placeholder="John Doe"
                        value={signupName}
                        onChange={(e) => setSignupName(e.target.value)}
                        required
                        data-testid="input-signup-name"
                      />
                    </div>

                    <div className="space-y-2">
                      <Label htmlFor="signup-email">Email</Label>
                      <Input
                        id="signup-email"
                        type="email"
                        placeholder="you@example.com"
                        value={signupEmail}
                        onChange={(e) => setSignupEmail(e.target.value)}
                        required
                        data-testid="input-signup-email"
                      />
                    </div>

                    <div className="space-y-2">
                      <Label htmlFor="signup-password">Password</Label>
                      <div className="relative">
                        <Input
                          id="signup-password"
                          type={showSignupPassword ? "text" : "password"}
                          placeholder="Create a strong password"
                          value={signupPassword}
                          onChange={(e) => setSignupPassword(e.target.value)}
                          required
                          className="pr-10"
                          data-testid="input-signup-password"
                        />
                        <button
                          type="button"
                          onClick={() => setShowSignupPassword(!showSignupPassword)}
                          className="absolute right-3 top-1/2 -translate-y-1/2 text-muted-foreground"
                          data-testid="button-toggle-signup-password"
                          aria-label={showSignupPassword ? "Hide password" : "Show password"}
                        >
                          {showSignupPassword ? (
                            <EyeOff className="h-4 w-4" />
                          ) : (
                            <Eye className="h-4 w-4" />
                          )}
                        </button>
                      </div>

                      {signupPassword.length > 0 && (
                        <div className="mt-2 space-y-1.5" data-testid="password-strength-rules">
                          {passwordRules.map((rule) => {
                            const passed = rule.test(signupPassword);
                            return (
                              <div key={rule.label} className="flex items-center gap-2">
                                <CheckCircle2
                                  className={`h-3.5 w-3.5 shrink-0 ${
                                    passed ? "text-green-500" : "text-muted-foreground/40"
                                  }`}
                                />
                                <span
                                  className={`text-xs ${
                                    passed ? "text-green-600 dark:text-green-400" : "text-muted-foreground"
                                  }`}
                                >
                                  {rule.label}
                                </span>
                              </div>
                            );
                          })}
                        </div>
                      )}
                    </div>

                    <Button
                      type="submit"
                      className="w-full"
                      disabled={registerMutation.isPending || !allRulesPassed}
                      data-testid="button-signup-submit"
                    >
                      {registerMutation.isPending ? (
                        <Loader2 className="h-4 w-4 animate-spin mr-2" />
                      ) : null}
                      Create Account
                    </Button>
                  </form>

                  <div className="mt-6 space-y-2">
                    {[
                      "Free forever — no credit card required",
                      "Access to all 35 PDF tools",
                      "Secure and private file processing",
                    ].map((text) => (
                      <div key={text} className="flex items-center gap-2">
                        <CheckCircle2 className="h-3.5 w-3.5 text-green-500 shrink-0" />
                        <span className="text-xs text-muted-foreground">{text}</span>
                      </div>
                    ))}
                  </div>

                  <p className="mt-6 text-center text-xs text-muted-foreground">
                    Already have an account?{" "}
                    <button
                      onClick={() => setActiveTab("signin")}
                      className="font-medium text-foreground underline"
                      data-testid="link-switch-signin"
                    >
                      Sign in
                    </button>
                  </p>
                </Card>
              </TabsContent>
            </Tabs>

            <p className="mt-6 text-center text-xs text-muted-foreground">
              By continuing, you agree to our{" "}
              <a href="/terms" className="underline" data-testid="link-terms">Terms of Service</a>{" "}
              and{" "}
              <a href="/privacy" className="underline" data-testid="link-privacy">Privacy Policy</a>
            </p>
          </div>
        </div>
      </div>
    </div>
  );
}
