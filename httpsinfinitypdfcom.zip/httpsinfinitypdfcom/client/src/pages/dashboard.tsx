import { Card } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { PDF_TOOLS, PDF_CATEGORIES, getToolsByCategory } from "@/lib/pdf-tools";
import { useAuth } from "@/hooks/use-auth";
import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { apiRequest } from "@/lib/queryClient";
import { Link } from "wouter";
import { motion } from "framer-motion";
import { useState } from "react";
import { useToast } from "@/hooks/use-toast";
import {
  Merge, Scissors, RotateCw, Hash, FileDown, Stamp,
  Unlock, GitCompare, Crop, EyeOff, Lock as LockIcon, Globe, ScanText,
  Layers, ArrowRightLeft, Pencil, Gauge, Shield, FolderOpen,
  Search, Crown, ArrowRight, Clock, FileText, CreditCard,
  CheckCircle2, XCircle, AlertCircle, Loader2,
  FileX2, ArrowUpDown, LayoutGrid, FileSpreadsheet, FileType,
  Presentation, Table, PenLine, PenTool, Archive,
  Wrench, Copy, ScanLine, Workflow, ImagePlus,
  Image as ImageIcon, ClipboardEdit, Sparkles,
} from "lucide-react";
import type { PdfJob, Order } from "@shared/schema";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogHeader,
  DialogTitle,
  DialogTrigger,
} from "@/components/ui/dialog";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";

const iconMap: Record<string, any> = {
  Merge, Scissors, RotateCw, Hash, FileDown, Stamp, ImageIcon,
  Unlock, GitCompare, Crop, EyeOff, Lock: LockIcon, Globe, ScanText,
  Layers, ArrowRightLeft, Pencil, Gauge, Shield, FolderOpen,
  FileX2, ArrowUpDown, LayoutGrid, FileSpreadsheet, FileType,
  Presentation, Table, PenLine, PenTool, Archive,
  Wrench, Copy, ScanLine, Workflow, ImagePlus, ClipboardEdit, Sparkles,
};

const fadeUp = {
  hidden: { opacity: 0, y: 16 },
  visible: (i: number) => ({
    opacity: 1, y: 0,
    transition: { delay: i * 0.04, duration: 0.35, ease: "easeOut" },
  }),
};

export default function DashboardPage() {
  const { user } = useAuth();
  const [searchQuery, setSearchQuery] = useState("");

  const filteredTools = searchQuery
    ? PDF_TOOLS.filter(
        (t) =>
          t.name.toLowerCase().includes(searchQuery.toLowerCase()) ||
          t.description.toLowerCase().includes(searchQuery.toLowerCase())
      )
    : null;

  const displayName = user?.firstName || "there";

  return (
    <div className="mx-auto max-w-7xl px-4 py-8 sm:px-6">
      <motion.div
        initial={{ opacity: 0, y: 12 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ duration: 0.4 }}
      >
        <div className="flex items-center justify-between gap-4 flex-wrap">
          <div>
            <h1 className="text-2xl font-bold tracking-tight sm:text-3xl" data-testid="text-welcome">
              Welcome back, {displayName}
            </h1>
            <p className="mt-1 text-muted-foreground">
              Choose a tool below or check your recent activity.
            </p>
          </div>
          <div className="flex items-center gap-2 flex-wrap">
            {user?.premiumStatus === "active" && (
              <Badge variant="default" data-testid="badge-premium-active">
                <Crown className="mr-1 h-3 w-3" /> Premium
              </Badge>
            )}
            {user?.premiumStatus === "pending" && (
              <Badge variant="secondary" data-testid="badge-premium-pending">
                <Clock className="mr-1 h-3 w-3" /> Pending Approval
              </Badge>
            )}
            {user?.isAdmin && (
              <Button variant="outline" size="sm" asChild data-testid="link-admin">
                <Link href="/admin">Admin Panel</Link>
              </Button>
            )}
          </div>
        </div>
      </motion.div>

      <Tabs defaultValue="tools" className="mt-6">
        <TabsList data-testid="dashboard-tabs">
          <TabsTrigger value="tools" data-testid="tab-tools">
            <Layers className="mr-1.5 h-4 w-4" /> Tools
          </TabsTrigger>
          <TabsTrigger value="history" data-testid="tab-history">
            <Clock className="mr-1.5 h-4 w-4" /> File History
          </TabsTrigger>
          <TabsTrigger value="billing" data-testid="tab-billing">
            <CreditCard className="mr-1.5 h-4 w-4" /> Billing
          </TabsTrigger>
        </TabsList>

        <TabsContent value="tools">
          <motion.div
            className="mt-4 max-w-md"
            initial={{ opacity: 0, y: 12 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ delay: 0.1, duration: 0.4 }}
          >
            <div className="relative">
              <Search className="absolute left-3 top-1/2 h-4 w-4 -translate-y-1/2 text-muted-foreground" />
              <Input
                type="search"
                placeholder="Search tools..."
                className="pl-9"
                value={searchQuery}
                onChange={(e) => setSearchQuery(e.target.value)}
                data-testid="input-search-tools"
              />
            </div>
          </motion.div>

          {filteredTools ? (
            <div className="mt-6">
              <h2 className="mb-4 text-sm font-medium text-muted-foreground">
                {filteredTools.length} result{filteredTools.length !== 1 ? "s" : ""}
              </h2>
              <div className="grid gap-3 sm:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4">
                {filteredTools.map((tool, i) => (
                  <ToolCard key={tool.id} tool={tool} index={i} userPremium={user?.premiumStatus === "active"} />
                ))}
              </div>
              {filteredTools.length === 0 && (
                <div className="py-12 text-center text-muted-foreground">
                  No tools match your search. Try a different term.
                </div>
              )}
            </div>
          ) : (
            <div className="mt-8 space-y-10">
              {PDF_CATEGORIES.map((category) => {
                const tools = getToolsByCategory(category.id);
                if (tools.length === 0) return null;
                const CategoryIcon = iconMap[category.icon];

                return (
                  <motion.div
                    key={category.id}
                    initial="hidden"
                    whileInView="visible"
                    viewport={{ once: true, margin: "-50px" }}
                  >
                    <div className="mb-4 flex items-center gap-2">
                      {CategoryIcon && <CategoryIcon className="h-4 w-4 text-muted-foreground" />}
                      <h2 className="text-base font-semibold">{category.name}</h2>
                    </div>
                    <div className="grid gap-3 sm:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4">
                      {tools.map((tool, i) => (
                        <ToolCard key={tool.id} tool={tool} index={i} userPremium={user?.premiumStatus === "active"} />
                      ))}
                    </div>
                  </motion.div>
                );
              })}
            </div>
          )}
        </TabsContent>

        <TabsContent value="history">
          <FileHistorySection />
        </TabsContent>

        <TabsContent value="billing">
          <BillingSection userPremiumStatus={user?.premiumStatus || "none"} />
        </TabsContent>
      </Tabs>
    </div>
  );
}

function FileHistorySection() {
  const { data: jobs, isLoading } = useQuery<PdfJob[]>({
    queryKey: ["/api/jobs/me"],
  });

  if (isLoading) {
    return (
      <div className="flex items-center justify-center py-16">
        <Loader2 className="h-6 w-6 animate-spin text-muted-foreground" />
      </div>
    );
  }

  if (!jobs || jobs.length === 0) {
    return (
      <Card className="mt-4 p-8 text-center" data-testid="card-no-history">
        <FileText className="mx-auto h-10 w-10 text-muted-foreground/40" />
        <h3 className="mt-3 font-medium">No file history yet</h3>
        <p className="mt-1 text-sm text-muted-foreground">
          Your processed files will appear here. Start by using any tool above.
        </p>
      </Card>
    );
  }

  return (
    <div className="mt-4 space-y-3" data-testid="file-history-list">
      {jobs.map((job) => (
        <Card key={job.id} className="flex items-center gap-4 p-4" data-testid={`card-job-${job.id}`}>
          <div className="flex h-10 w-10 shrink-0 items-center justify-center rounded-md bg-muted">
            <FileText className="h-5 w-5 text-muted-foreground" />
          </div>
          <div className="min-w-0 flex-1">
            <div className="flex items-center gap-2 flex-wrap">
              <span className="text-sm font-medium">{job.toolName}</span>
              <Badge
                variant={job.status === "completed" ? "default" : job.status === "failed" ? "destructive" : "secondary"}
                className="text-xs"
              >
                {job.status === "completed" && <CheckCircle2 className="mr-1 h-3 w-3" />}
                {job.status === "failed" && <XCircle className="mr-1 h-3 w-3" />}
                {job.status === "processing" && <Loader2 className="mr-1 h-3 w-3 animate-spin" />}
                {job.status}
              </Badge>
            </div>
            <p className="mt-0.5 text-xs text-muted-foreground truncate">
              {job.inputFiles?.join(", ")}
            </p>
            <p className="text-xs text-muted-foreground">
              {job.createdAt ? new Date(job.createdAt).toLocaleString() : ""}
            </p>
          </div>
          {job.status === "completed" && job.outputFile && (
            <Button variant="outline" size="sm" asChild data-testid={`button-download-${job.id}`}>
              <a href={`/api/pdf/download/${job.outputFile}`}>Download</a>
            </Button>
          )}
        </Card>
      ))}
    </div>
  );
}

function BillingSection({ userPremiumStatus }: { userPremiumStatus: string }) {
  const queryClient = useQueryClient();
  const { toast } = useToast();
  const [dialogOpen, setDialogOpen] = useState(false);
  const [planId, setPlanId] = useState("premium");
  const [billingCycle, setBillingCycle] = useState("yearly");
  const [paymentRef, setPaymentRef] = useState("");

  const { data: userOrders, isLoading } = useQuery<Order[]>({
    queryKey: ["/api/orders/me"],
  });

  const createOrderMutation = useMutation({
    mutationFn: async (data: { planId: string; billingCycle: string; paymentReference: string }) => {
      const res = await apiRequest("POST", "/api/orders", data);
      return res.json();
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/orders/me"] });
      toast({ title: "Order submitted", description: "Your order has been submitted for admin review." });
      setDialogOpen(false);
      setPaymentRef("");
    },
    onError: (err: any) => {
      toast({ title: "Error", description: err.message, variant: "destructive" });
    },
  });

  const price = billingCycle === "yearly" ? "$48/year ($4/mo)" : "$7/month";

  return (
    <div className="mt-4 space-y-6">
      <Card className="p-6" data-testid="card-premium-status">
        <div className="flex items-center justify-between gap-4 flex-wrap">
          <div>
            <h3 className="font-semibold">Your Plan</h3>
            <div className="mt-1 flex items-center gap-2">
              {userPremiumStatus === "active" ? (
                <>
                  <Badge variant="default"><Crown className="mr-1 h-3 w-3" /> Premium Active</Badge>
                  <span className="text-sm text-muted-foreground">Full access to all tools</span>
                </>
              ) : userPremiumStatus === "pending" ? (
                <>
                  <Badge variant="secondary"><Clock className="mr-1 h-3 w-3" /> Pending Approval</Badge>
                  <span className="text-sm text-muted-foreground">Your payment is being reviewed</span>
                </>
              ) : userPremiumStatus === "rejected" ? (
                <>
                  <Badge variant="destructive"><XCircle className="mr-1 h-3 w-3" /> Rejected</Badge>
                  <span className="text-sm text-muted-foreground">Please contact support or try again</span>
                </>
              ) : (
                <>
                  <Badge variant="secondary">Free Plan</Badge>
                  <span className="text-sm text-muted-foreground">Limited tools available</span>
                </>
              )}
            </div>
          </div>
          {userPremiumStatus !== "active" && (
            <Dialog open={dialogOpen} onOpenChange={setDialogOpen}>
              <DialogTrigger asChild>
                <Button data-testid="button-upgrade">
                  <Crown className="mr-2 h-4 w-4" /> Upgrade to Premium
                </Button>
              </DialogTrigger>
              <DialogContent>
                <DialogHeader>
                  <DialogTitle>Upgrade to Premium</DialogTitle>
                  <DialogDescription>
                    Complete payment and submit your reference. An admin will review and approve your access.
                  </DialogDescription>
                </DialogHeader>
                <div className="space-y-4 pt-2">
                  <div>
                    <Label>Plan</Label>
                    <Select value={planId} onValueChange={setPlanId}>
                      <SelectTrigger data-testid="select-plan">
                        <SelectValue />
                      </SelectTrigger>
                      <SelectContent>
                        <SelectItem value="premium">Premium</SelectItem>
                      </SelectContent>
                    </Select>
                  </div>
                  <div>
                    <Label>Billing Cycle</Label>
                    <Select value={billingCycle} onValueChange={setBillingCycle}>
                      <SelectTrigger data-testid="select-billing-cycle">
                        <SelectValue />
                      </SelectTrigger>
                      <SelectContent>
                        <SelectItem value="monthly">Monthly - $7/month</SelectItem>
                        <SelectItem value="yearly">Yearly - $48/year ($4/mo)</SelectItem>
                      </SelectContent>
                    </Select>
                  </div>
                  <div>
                    <Label>Payment Reference / Transaction ID</Label>
                    <Textarea
                      placeholder="Enter your payment transaction ID or reference number..."
                      value={paymentRef}
                      onChange={(e) => setPaymentRef(e.target.value)}
                      data-testid="input-payment-ref"
                    />
                    <p className="mt-1 text-xs text-muted-foreground">
                      Complete your payment and paste the transaction reference here.
                    </p>
                  </div>
                  <Button
                    className="w-full"
                    onClick={() => createOrderMutation.mutate({ planId, billingCycle, paymentReference: paymentRef })}
                    disabled={createOrderMutation.isPending || !paymentRef.trim()}
                    data-testid="button-submit-order"
                  >
                    {createOrderMutation.isPending && <Loader2 className="mr-2 h-4 w-4 animate-spin" />}
                    Submit Order for Review
                  </Button>
                </div>
              </DialogContent>
            </Dialog>
          )}
        </div>
      </Card>

      <div>
        <h3 className="font-semibold mb-3">Order History</h3>
        {isLoading ? (
          <div className="flex items-center justify-center py-8">
            <Loader2 className="h-6 w-6 animate-spin text-muted-foreground" />
          </div>
        ) : !userOrders || userOrders.length === 0 ? (
          <Card className="p-6 text-center" data-testid="card-no-orders">
            <CreditCard className="mx-auto h-8 w-8 text-muted-foreground/40" />
            <p className="mt-2 text-sm text-muted-foreground">No orders yet.</p>
          </Card>
        ) : (
          <div className="space-y-3" data-testid="order-history-list">
            {userOrders.map((order) => (
              <Card key={order.id} className="p-4" data-testid={`card-order-${order.id}`}>
                <div className="flex items-center justify-between gap-4 flex-wrap">
                  <div>
                    <div className="flex items-center gap-2 flex-wrap">
                      <span className="text-sm font-medium capitalize">{order.planId} Plan</span>
                      <Badge variant="secondary" className="text-xs capitalize">{order.billingCycle}</Badge>
                      <OrderStatusBadge status={order.status} />
                    </div>
                    <p className="mt-0.5 text-xs text-muted-foreground">
                      ${(order.amount / 100).toFixed(2)} {order.currency} &middot; {order.createdAt ? new Date(order.createdAt).toLocaleDateString() : ""}
                    </p>
                    {order.adminNote && (
                      <p className="mt-1 text-xs text-muted-foreground italic">
                        Admin note: {order.adminNote}
                      </p>
                    )}
                  </div>
                </div>
              </Card>
            ))}
          </div>
        )}
      </div>
    </div>
  );
}

function OrderStatusBadge({ status }: { status: string }) {
  switch (status) {
    case "approved":
      return <Badge variant="default" className="text-xs"><CheckCircle2 className="mr-1 h-3 w-3" /> Approved</Badge>;
    case "rejected":
      return <Badge variant="destructive" className="text-xs"><XCircle className="mr-1 h-3 w-3" /> Rejected</Badge>;
    case "pending":
      return <Badge variant="secondary" className="text-xs"><Clock className="mr-1 h-3 w-3" /> Pending</Badge>;
    default:
      return <Badge variant="secondary" className="text-xs">{status}</Badge>;
  }
}

function ToolCard({ tool, index, userPremium }: { tool: (typeof PDF_TOOLS)[number]; index: number; userPremium: boolean }) {
  const ToolIcon = iconMap[tool.icon];
  const isLocked = tool.isPremium && !userPremium;

  const content = (
    <Card
      className={`group relative flex items-start gap-3 p-4 transition-all duration-200 hover-elevate ${isLocked ? "opacity-75" : ""}`}
      data-testid={`card-tool-${tool.id}`}
    >
      <div
        className="flex h-10 w-10 shrink-0 items-center justify-center rounded-md"
        style={{ backgroundColor: `hsl(${tool.color} / 0.1)` }}
      >
        {ToolIcon && (
          <ToolIcon className="h-5 w-5" style={{ color: `hsl(${tool.color})` }} />
        )}
      </div>
      <div className="min-w-0 flex-1">
        <div className="flex items-center gap-2 flex-wrap">
          <h3 className="text-sm font-medium">{tool.name}</h3>
          {tool.isPremium && (
            <Badge variant="secondary" className="text-xs">
              <Crown className="mr-0.5 h-3 w-3" /> Pro
            </Badge>
          )}
        </div>
        <p className="mt-0.5 text-xs text-muted-foreground leading-relaxed">
          {tool.description}
        </p>
      </div>
      {isLocked ? (
        <LockIcon className="h-4 w-4 shrink-0 text-muted-foreground mt-1" />
      ) : (
        <ArrowRight className="invisible h-4 w-4 shrink-0 text-muted-foreground transition-all group-hover:visible group-hover:translate-x-0.5 mt-1" />
      )}
    </Card>
  );

  return (
    <motion.div variants={fadeUp} custom={index}>
      <Link href={`/${tool.slug}`} data-testid={`link-tool-${tool.id}`}>
        {content}
      </Link>
    </motion.div>
  );
}
