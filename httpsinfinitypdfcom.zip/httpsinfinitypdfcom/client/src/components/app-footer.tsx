import { FileText } from "lucide-react";

const footerSections = [
  {
    title: "Popular Tools",
    links: [
      { label: "Merge PDF", href: "/merge-pdf" },
      { label: "Split PDF", href: "/split-pdf" },
      { label: "Compress PDF", href: "/compress-pdf" },
      { label: "PDF to Word", href: "/pdf-to-word" },
      { label: "Rotate PDF", href: "/rotate-pdf" },
      { label: "Unlock PDF", href: "/unlock-pdf" },
    ],
  },
  {
    title: "Convert",
    links: [
      { label: "Word to PDF", href: "/word-to-pdf" },
      { label: "Excel to PDF", href: "/excel-to-pdf" },
      { label: "PPT to PDF", href: "/powerpoint-to-pdf" },
      { label: "Image to PDF", href: "/image-to-pdf" },
      { label: "PDF to JPG", href: "/pdf-to-jpg" },
      { label: "HTML to PDF", href: "/html-to-pdf" },
    ],
  },
  {
    title: "Product",
    links: [
      { label: "All Tools", href: "/#tools" },
      { label: "Features", href: "/features" },
      { label: "Pricing", href: "/pricing" },
      { label: "FAQ", href: "/faq" },
      { label: "Solutions", href: "/solutions" },
    ],
  },
  {
    title: "Legal",
    links: [
      { label: "Security", href: "/security" },
      { label: "Privacy Policy", href: "/privacy" },
      { label: "Terms & Conditions", href: "/terms" },
      { label: "Cookies", href: "/cookies" },
    ],
  },
  {
    title: "Company",
    links: [
      { label: "About Us", href: "/about" },
      { label: "Contact Us", href: "/contact" },
      { label: "Blog", href: "/blog" },
      { label: "Press", href: "/press" },
    ],
  },
];

export function AppFooter() {
  return (
    <footer
      className="dark py-12"
      style={{ backgroundColor: "#2d3748" }}
      data-testid="app-footer"
    >
      <div className="mx-auto max-w-7xl px-4 sm:px-6">
        <div className="grid grid-cols-2 gap-8 sm:grid-cols-3 md:grid-cols-5 lg:grid-cols-6">
          <div className="col-span-2 sm:col-span-3 md:col-span-5 lg:col-span-1 mb-4 lg:mb-0">
            <a href="/" className="flex items-center gap-2 mb-3" data-testid="footer-logo">
              <div className="flex h-8 w-8 items-center justify-center rounded-md bg-white/10">
                <FileText className="h-4 w-4 text-white" />
              </div>
              <span className="font-semibold text-lg text-white">InfinityPDF</span>
            </a>
            <p className="text-xs leading-relaxed max-w-[220px] text-white/50">
              Unlimited PDF Tools. One Powerful Platform.
            </p>
          </div>

          {footerSections.map((section) => (
            <div key={section.title}>
              <h3
                className="font-semibold text-sm mb-3 text-white"
                data-testid={`footer-section-${section.title.toLowerCase().replace(/\s+/g, "-")}`}
              >
                {section.title}
              </h3>
              <ul className="space-y-2">
                {section.links.map((link) => (
                  <li key={link.label}>
                    <a
                      href={link.href}
                      className="text-sm text-white/60 transition-colors"
                      data-testid={`footer-link-${link.label.toLowerCase().replace(/\s+/g, "-")}`}
                    >
                      {link.label}
                    </a>
                  </li>
                ))}
              </ul>
            </div>
          ))}
        </div>

        <div className="mt-8 pt-6" style={{ borderTopColor: "rgba(255,255,255,0.1)", borderTopWidth: "1px", borderTopStyle: "solid" }}>
          <p className="text-xs text-white/40 leading-relaxed max-w-3xl">
            InfinityPDF provides free and premium online PDF tools including merge PDF, split PDF, compress PDF,
            convert PDF to Word, edit PDF online, compare PDF files, and HTML to PDF conversion. Our platform ensures
            secure, fast, and reliable document processing for users worldwide.
          </p>
        </div>

        <div
          className="mt-6 pt-4 flex flex-col items-center justify-between gap-4 sm:flex-row"
          style={{ borderTopColor: "rgba(255,255,255,0.06)", borderTopWidth: "1px", borderTopStyle: "solid" }}
        >
          <p className="text-xs text-white/40">
            &copy; {new Date().getFullYear()} InfinityPDF. All rights reserved.
          </p>
          <div className="flex items-center gap-4 flex-wrap">
            <a href="/privacy" className="text-xs text-white/40 transition-colors" data-testid="footer-bottom-privacy">Privacy</a>
            <a href="/terms" className="text-xs text-white/40 transition-colors" data-testid="footer-bottom-terms">Terms</a>
            <a href="/cookies" className="text-xs text-white/40 transition-colors" data-testid="footer-bottom-cookies">Cookies</a>
          </div>
        </div>
      </div>
    </footer>
  );
}
