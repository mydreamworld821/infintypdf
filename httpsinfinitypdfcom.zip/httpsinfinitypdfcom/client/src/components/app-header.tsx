import { Button } from "@/components/ui/button";
import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar";
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuSeparator,
  DropdownMenuTrigger,
} from "@/components/ui/dropdown-menu";
import { Popover, PopoverContent, PopoverTrigger } from "@/components/ui/popover";
import { useTheme } from "@/components/theme-provider";
import { useAuth } from "@/hooks/use-auth";
import { Moon, Sun, LogOut, User, ChevronDown } from "lucide-react";
import logoImg from "@assets/ChatGPT_Image_Feb_13,_2026,_08_10_21_PM_1770995717930.png";
import { Link } from "wouter";
import { PDF_CATEGORIES, getToolsByCategory } from "@/lib/pdf-tools";

const quickLinks = [
  { label: "Merge PDF", href: "/merge-pdf" },
  { label: "Split PDF", href: "/split-pdf" },
  { label: "Compress PDF", href: "/compress-pdf" },
];

export function AppHeader() {
  const { theme, toggleTheme } = useTheme();
  const { user, isAuthenticated, isLoading } = useAuth();
  const conversionTools = getToolsByCategory("conversion");

  return (
    <header className="sticky top-0 z-50 border-b bg-background/80 backdrop-blur-md">
      <div className="mx-auto flex h-14 max-w-7xl items-center justify-between gap-4 px-4 sm:px-6">
        <div className="flex items-center gap-6">
          <Link href="/" data-testid="link-home">
            <div className="flex items-center gap-2 cursor-pointer">
              <img src={logoImg} alt="InfinityPDF" className="h-8 w-8 rounded-md object-cover" />
              <span className="text-lg font-semibold tracking-tight">InfinityPDF</span>
            </div>
          </Link>

          <nav className="hidden md:flex items-center gap-4" data-testid="nav-links">
            {quickLinks.map((link) => (
              <a
                key={link.href}
                href={link.href}
                className="text-sm font-medium text-muted-foreground transition-colors"
                data-testid={`nav-${link.label.toLowerCase().replace(/\s+/g, "-")}`}
              >
                {link.label}
              </a>
            ))}

            <Popover>
              <PopoverTrigger asChild>
                <Button variant="ghost" size="sm" className="gap-1 text-muted-foreground font-medium" data-testid="nav-convert-pdf">
                  Convert PDF
                  <ChevronDown className="h-3 w-3" />
                </Button>
              </PopoverTrigger>
              <PopoverContent align="start" className="w-56 p-1">
                {conversionTools.map((tool) => (
                  <a
                    key={tool.id}
                    href={`/${tool.slug}`}
                    className="block rounded-md px-3 py-2 text-sm hover-elevate"
                    data-testid={`nav-convert-${tool.id}`}
                  >
                    {tool.name}
                  </a>
                ))}
              </PopoverContent>
            </Popover>

            <Popover>
              <PopoverTrigger asChild>
                <Button variant="ghost" size="sm" className="gap-1 text-muted-foreground font-medium" data-testid="nav-all-tools">
                  All PDF Tools
                  <ChevronDown className="h-3 w-3" />
                </Button>
              </PopoverTrigger>
              <PopoverContent align="end" className="w-[600px] p-4">
                <div className="grid grid-cols-2 gap-4">
                  {PDF_CATEGORIES.map((cat) => {
                    const tools = getToolsByCategory(cat.id);
                    return (
                      <div key={cat.id}>
                        <h4 className="text-xs font-semibold text-muted-foreground uppercase tracking-wider mb-2">
                          {cat.name}
                        </h4>
                        <div className="space-y-0.5">
                          {tools.map((tool) => (
                            <a
                              key={tool.id}
                              href={`/${tool.slug}`}
                              className="block rounded-md px-2 py-1.5 text-sm hover-elevate"
                              data-testid={`nav-tool-${tool.id}`}
                            >
                              {tool.name}
                            </a>
                          ))}
                        </div>
                      </div>
                    );
                  })}
                </div>
              </PopoverContent>
            </Popover>
          </nav>
        </div>

        <div className="flex items-center gap-2">
          <Button
            size="icon"
            variant="ghost"
            onClick={toggleTheme}
            data-testid="button-theme-toggle"
          >
            {theme === "dark" ? <Sun className="h-4 w-4" /> : <Moon className="h-4 w-4" />}
          </Button>

          {isLoading ? (
            <div className="h-8 w-8 animate-pulse rounded-full bg-muted" />
          ) : isAuthenticated && user ? (
            <DropdownMenu>
              <DropdownMenuTrigger asChild>
                <Button variant="ghost" className="relative h-8 w-8 rounded-full" data-testid="button-user-menu">
                  <Avatar className="h-8 w-8">
                    <AvatarImage src={user.profileImageUrl || undefined} alt={user.firstName || "User"} />
                    <AvatarFallback className="text-xs">
                      {(user.firstName?.[0] || "U").toUpperCase()}
                    </AvatarFallback>
                  </Avatar>
                </Button>
              </DropdownMenuTrigger>
              <DropdownMenuContent align="end" className="w-56">
                <div className="flex items-center gap-2 p-2">
                  <Avatar className="h-8 w-8">
                    <AvatarImage src={user.profileImageUrl || undefined} />
                    <AvatarFallback className="text-xs">
                      {(user.firstName?.[0] || "U").toUpperCase()}
                    </AvatarFallback>
                  </Avatar>
                  <div className="flex flex-col">
                    <span className="text-sm font-medium">
                      {user.firstName} {user.lastName}
                    </span>
                    <span className="text-xs text-muted-foreground">{user.email}</span>
                  </div>
                </div>
                <DropdownMenuSeparator />
                <DropdownMenuItem
                  onClick={() => {
                    fetch("/api/auth/logout", { method: "POST", credentials: "include" })
                      .then(() => { window.location.href = "/"; });
                  }}
                  className="cursor-pointer"
                  data-testid="button-logout"
                >
                  <LogOut className="mr-2 h-4 w-4" />
                  Sign out
                </DropdownMenuItem>
              </DropdownMenuContent>
            </DropdownMenu>
          ) : (
            <>
              <a
                href="/auth"
                className="hidden sm:inline-flex text-sm font-medium text-muted-foreground transition-colors"
                data-testid="link-login"
              >
                Login
              </a>
              <Button asChild data-testid="button-signup">
                <a href="/auth">Sign up</a>
              </Button>
            </>
          )}
        </div>
      </div>
    </header>
  );
}
