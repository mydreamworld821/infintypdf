import {
  users, pdfJobs, orders,
  type User, type UpsertUser,
  type PdfJob, type InsertPdfJob,
  type Order, type InsertOrder,
} from "@shared/schema";
import { db } from "./db";
import { eq, desc } from "drizzle-orm";

export interface IStorage {
  getUser(id: string): Promise<User | undefined>;
  getUserByEmail(email: string): Promise<User | undefined>;
  upsertUser(user: UpsertUser): Promise<User>;
  createLocalUser(user: UpsertUser): Promise<User>;
  updateUserPremiumStatus(userId: string, status: string): Promise<User>;

  createJob(job: InsertPdfJob): Promise<PdfJob>;
  updateJobStatus(jobId: string, status: string, outputFile?: string): Promise<void>;
  getJobsByUser(userId: string): Promise<PdfJob[]>;

  createOrder(order: InsertOrder): Promise<Order>;
  getOrdersByUser(userId: string): Promise<Order[]>;
  getAllOrders(): Promise<(Order & { userEmail: string | null; userName: string | null })[]>;
  updateOrderStatus(orderId: string, status: string, adminNote?: string): Promise<Order>;

  getAllUsers(): Promise<User[]>;
  setUserAdmin(userId: string, isAdmin: boolean): Promise<void>;
}

export class DatabaseStorage implements IStorage {
  async getUser(id: string): Promise<User | undefined> {
    const [user] = await db.select().from(users).where(eq(users.id, id));
    return user;
  }

  async getUserByEmail(email: string): Promise<User | undefined> {
    const [user] = await db.select().from(users).where(eq(users.email, email));
    return user;
  }

  async upsertUser(userData: UpsertUser): Promise<User> {
    const [user] = await db
      .insert(users)
      .values(userData)
      .onConflictDoUpdate({
        target: users.id,
        set: {
          ...userData,
          updatedAt: new Date(),
        },
      })
      .returning();
    return user;
  }

  async createLocalUser(userData: UpsertUser): Promise<User> {
    const [user] = await db.insert(users).values(userData).returning();
    return user;
  }

  async updateUserPremiumStatus(userId: string, status: string): Promise<User> {
    const updates: Record<string, any> = {
      premiumStatus: status,
      updatedAt: new Date(),
    };
    if (status === "active") {
      updates.premiumApprovedAt = new Date();
    }
    const [user] = await db.update(users).set(updates).where(eq(users.id, userId)).returning();
    return user;
  }

  async createJob(job: InsertPdfJob): Promise<PdfJob> {
    const [created] = await db.insert(pdfJobs).values(job).returning();
    return created;
  }

  async updateJobStatus(jobId: string, status: string, outputFile?: string): Promise<void> {
    const updates: Record<string, any> = { status };
    if (outputFile) updates.outputFile = outputFile;
    await db.update(pdfJobs).set(updates).where(eq(pdfJobs.id, jobId));
  }

  async getJobsByUser(userId: string): Promise<PdfJob[]> {
    return db.select().from(pdfJobs).where(eq(pdfJobs.userId, userId)).orderBy(desc(pdfJobs.createdAt));
  }

  async createOrder(order: InsertOrder): Promise<Order> {
    const [created] = await db.insert(orders).values(order).returning();
    return created;
  }

  async getOrdersByUser(userId: string): Promise<Order[]> {
    return db.select().from(orders).where(eq(orders.userId, userId)).orderBy(desc(orders.createdAt));
  }

  async getAllOrders(): Promise<(Order & { userEmail: string | null; userName: string | null })[]> {
    const rows = await db
      .select({
        id: orders.id,
        userId: orders.userId,
        planId: orders.planId,
        billingCycle: orders.billingCycle,
        amount: orders.amount,
        currency: orders.currency,
        status: orders.status,
        paymentReference: orders.paymentReference,
        adminNote: orders.adminNote,
        createdAt: orders.createdAt,
        updatedAt: orders.updatedAt,
        userEmail: users.email,
        userName: users.firstName,
      })
      .from(orders)
      .leftJoin(users, eq(orders.userId, users.id))
      .orderBy(desc(orders.createdAt));
    return rows;
  }

  async updateOrderStatus(orderId: string, status: string, adminNote?: string): Promise<Order> {
    const updates: Record<string, any> = { status, updatedAt: new Date() };
    if (adminNote !== undefined) updates.adminNote = adminNote;
    const [order] = await db.update(orders).set(updates).where(eq(orders.id, orderId)).returning();
    return order;
  }

  async getAllUsers(): Promise<User[]> {
    return db.select().from(users).orderBy(desc(users.createdAt));
  }

  async setUserAdmin(userId: string, isAdmin: boolean): Promise<void> {
    await db.update(users).set({ isAdmin, updatedAt: new Date() }).where(eq(users.id, userId));
  }
}

export const storage = new DatabaseStorage();
