import { PDFDocument, rgb, StandardFonts, degrees } from "pdf-lib";
import fs from "fs";
import path from "path";
import { randomUUID } from "crypto";
import { execFileSync, execSync } from "child_process";
import archiver from "archiver";

const UPLOAD_DIR = path.join(process.cwd(), "uploads");
const OUTPUT_DIR = path.join(process.cwd(), "outputs");

function ensureDirs() {
  if (!fs.existsSync(UPLOAD_DIR)) fs.mkdirSync(UPLOAD_DIR, { recursive: true });
  if (!fs.existsSync(OUTPUT_DIR)) fs.mkdirSync(OUTPUT_DIR, { recursive: true });
}

ensureDirs();

export function getOutputDir() {
  return OUTPUT_DIR;
}

export function getUploadDir() {
  return UPLOAD_DIR;
}

async function loadPdf(filePath: string): Promise<PDFDocument> {
  const bytes = fs.readFileSync(filePath);
  return PDFDocument.load(bytes, { ignoreEncryption: true });
}

function uid() {
  return randomUUID().slice(0, 8);
}

function execCommand(bin: string, args: string[], timeoutMs = 120000): string {
  return execFileSync(bin, args, { timeout: timeoutMs, encoding: "utf-8", stdio: ["pipe", "pipe", "pipe"] });
}

export async function mergePdfs(filePaths: string[]): Promise<{ filePath: string; filename: string }> {
  const merged = await PDFDocument.create();
  for (const fp of filePaths) {
    const doc = await loadPdf(fp);
    const pages = await merged.copyPages(doc, doc.getPageIndices());
    pages.forEach((page) => merged.addPage(page));
  }
  const outputName = `merged-${uid()}.pdf`;
  const outputPath = path.join(OUTPUT_DIR, outputName);
  fs.writeFileSync(outputPath, await merged.save());
  return { filePath: outputPath, filename: outputName };
}

export async function splitPdf(filePath: string, pagesStr: string): Promise<{ filePath: string; filename: string }> {
  const doc = await loadPdf(filePath);
  const totalPages = doc.getPageCount();
  let pageIndices: number[];
  if (pagesStr === "all") {
    pageIndices = Array.from({ length: totalPages }, (_, i) => i);
  } else {
    pageIndices = [];
    const parts = pagesStr.split(",").map((s) => s.trim());
    for (const part of parts) {
      if (part.includes("-")) {
        const [start, end] = part.split("-").map(Number);
        for (let i = Math.max(1, start); i <= Math.min(totalPages, end); i++) pageIndices.push(i - 1);
      } else {
        const num = parseInt(part, 10);
        if (num >= 1 && num <= totalPages) pageIndices.push(num - 1);
      }
    }
  }
  if (pageIndices.length === 0) pageIndices = [0];
  const newDoc = await PDFDocument.create();
  const copiedPages = await newDoc.copyPages(doc, pageIndices);
  copiedPages.forEach((page) => newDoc.addPage(page));
  const outputName = `split-${uid()}.pdf`;
  const outputPath = path.join(OUTPUT_DIR, outputName);
  fs.writeFileSync(outputPath, await newDoc.save());
  return { filePath: outputPath, filename: outputName };
}

export async function rotatePdf(filePath: string, angle: number): Promise<{ filePath: string; filename: string }> {
  const doc = await loadPdf(filePath);
  for (const page of doc.getPages()) {
    page.setRotation(degrees(page.getRotation().angle + angle));
  }
  const outputName = `rotated-${uid()}.pdf`;
  const outputPath = path.join(OUTPUT_DIR, outputName);
  fs.writeFileSync(outputPath, await doc.save());
  return { filePath: outputPath, filename: outputName };
}

export async function compressPdf(filePath: string): Promise<{ filePath: string; filename: string }> {
  const outputName = `compressed-${uid()}.pdf`;
  const outputPath = path.join(OUTPUT_DIR, outputName);
  try {
    execCommand("gs", ["-sDEVICE=pdfwrite", "-dCompatibilityLevel=1.4", "-dPDFSETTINGS=/ebook", "-dNOPAUSE", "-dQUIET", "-dBATCH", `-sOutputFile=${outputPath}`, filePath]);
  } catch {
    const doc = await loadPdf(filePath);
    fs.writeFileSync(outputPath, await doc.save());
  }
  return { filePath: outputPath, filename: outputName };
}

export async function addWatermark(filePath: string, text: string): Promise<{ filePath: string; filename: string }> {
  const doc = await loadPdf(filePath);
  const font = await doc.embedFont(StandardFonts.HelveticaBold);
  for (const page of doc.getPages()) {
    const { width, height } = page.getSize();
    const fontSize = Math.min(width, height) * 0.08;
    const textWidth = font.widthOfTextAtSize(text, fontSize);
    page.drawText(text, {
      x: (width - textWidth) / 2, y: height / 2,
      size: fontSize, font, color: rgb(0.75, 0.75, 0.75), opacity: 0.3, rotate: degrees(-45),
    });
  }
  const outputName = `watermarked-${uid()}.pdf`;
  const outputPath = path.join(OUTPUT_DIR, outputName);
  fs.writeFileSync(outputPath, await doc.save());
  return { filePath: outputPath, filename: outputName };
}

export async function addPageNumbers(filePath: string, position: string): Promise<{ filePath: string; filename: string }> {
  const doc = await loadPdf(filePath);
  const font = await doc.embedFont(StandardFonts.Helvetica);
  const pages = doc.getPages();
  const totalPages = pages.length;
  const fontSize = 10;
  for (let i = 0; i < totalPages; i++) {
    const page = pages[i];
    const { width, height } = page.getSize();
    const text = `${i + 1} / ${totalPages}`;
    const textWidth = font.widthOfTextAtSize(text, fontSize);
    let x: number, y: number;
    switch (position) {
      case "bottom-left": x = 40; y = 30; break;
      case "bottom-right": x = width - textWidth - 40; y = 30; break;
      case "top-center": x = (width - textWidth) / 2; y = height - 40; break;
      case "top-left": x = 40; y = height - 40; break;
      case "top-right": x = width - textWidth - 40; y = height - 40; break;
      default: x = (width - textWidth) / 2; y = 30; break;
    }
    page.drawText(text, { x, y, size: fontSize, font, color: rgb(0.3, 0.3, 0.3) });
  }
  const outputName = `numbered-${uid()}.pdf`;
  const outputPath = path.join(OUTPUT_DIR, outputName);
  fs.writeFileSync(outputPath, await doc.save());
  return { filePath: outputPath, filename: outputName };
}

export async function unlockPdf(filePath: string): Promise<{ filePath: string; filename: string }> {
  const outputName = `unlocked-${uid()}.pdf`;
  const outputPath = path.join(OUTPUT_DIR, outputName);
  try {
    execCommand("qpdf", ["--decrypt", filePath, outputPath]);
  } catch {
    const bytes = fs.readFileSync(filePath);
    const doc = await PDFDocument.load(bytes, { ignoreEncryption: true });
    fs.writeFileSync(outputPath, await doc.save());
  }
  return { filePath: outputPath, filename: outputName };
}

export async function removePages(filePath: string, pagesToRemove: string): Promise<{ filePath: string; filename: string }> {
  const doc = await loadPdf(filePath);
  const totalPages = doc.getPageCount();
  const removeSet = new Set<number>();
  const parts = pagesToRemove.split(",").map((s) => s.trim());
  for (const part of parts) {
    if (part.includes("-")) {
      const [start, end] = part.split("-").map(Number);
      for (let i = Math.max(1, start); i <= Math.min(totalPages, end); i++) removeSet.add(i - 1);
    } else {
      const num = parseInt(part, 10);
      if (num >= 1 && num <= totalPages) removeSet.add(num - 1);
    }
  }
  const keepIndices = Array.from({ length: totalPages }, (_, i) => i).filter((i) => !removeSet.has(i));
  if (keepIndices.length === 0) throw new Error("Cannot remove all pages");
  const newDoc = await PDFDocument.create();
  const copiedPages = await newDoc.copyPages(doc, keepIndices);
  copiedPages.forEach((page) => newDoc.addPage(page));
  const outputName = `pages-removed-${uid()}.pdf`;
  const outputPath = path.join(OUTPUT_DIR, outputName);
  fs.writeFileSync(outputPath, await newDoc.save());
  return { filePath: outputPath, filename: outputName };
}

export async function reorderPages(filePath: string, orderStr: string): Promise<{ filePath: string; filename: string }> {
  const doc = await loadPdf(filePath);
  const totalPages = doc.getPageCount();
  const order = orderStr.split(",").map((s) => parseInt(s.trim(), 10) - 1).filter((i) => i >= 0 && i < totalPages);
  if (order.length === 0) throw new Error("Invalid page order");
  const newDoc = await PDFDocument.create();
  const copiedPages = await newDoc.copyPages(doc, order);
  copiedPages.forEach((page) => newDoc.addPage(page));
  const outputName = `reordered-${uid()}.pdf`;
  const outputPath = path.join(OUTPUT_DIR, outputName);
  fs.writeFileSync(outputPath, await newDoc.save());
  return { filePath: outputPath, filename: outputName };
}

export async function organizePages(filePath: string, orderStr: string): Promise<{ filePath: string; filename: string }> {
  return reorderPages(filePath, orderStr);
}

export async function officeToPdf(filePath: string): Promise<{ filePath: string; filename: string }> {
  const tmpDir = path.join(OUTPUT_DIR, `lo-${uid()}`);
  fs.mkdirSync(tmpDir, { recursive: true });
  try {
    execCommand("libreoffice", ["--headless", "--convert-to", "pdf", "--outdir", tmpDir, filePath], 180000);
    const files = fs.readdirSync(tmpDir).filter((f) => f.endsWith(".pdf"));
    if (files.length === 0) throw new Error("Conversion failed");
    const outputName = `converted-${uid()}.pdf`;
    const outputPath = path.join(OUTPUT_DIR, outputName);
    fs.renameSync(path.join(tmpDir, files[0]), outputPath);
    return { filePath: outputPath, filename: outputName };
  } finally {
    try { fs.rmSync(tmpDir, { recursive: true, force: true }); } catch {}
  }
}

export async function pdfToWord(filePath: string): Promise<{ filePath: string; filename: string }> {
  const tmpDir = path.join(OUTPUT_DIR, `lo-${uid()}`);
  fs.mkdirSync(tmpDir, { recursive: true });
  try {
    execCommand("libreoffice", ["--headless", "--convert-to", "docx", "--outdir", tmpDir, filePath], 180000);
    const files = fs.readdirSync(tmpDir).filter((f) => f.endsWith(".docx"));
    if (files.length === 0) throw new Error("Conversion failed");
    const outputName = `converted-${uid()}.docx`;
    const outputPath = path.join(OUTPUT_DIR, outputName);
    fs.renameSync(path.join(tmpDir, files[0]), outputPath);
    return { filePath: outputPath, filename: outputName };
  } finally {
    try { fs.rmSync(tmpDir, { recursive: true, force: true }); } catch {}
  }
}

export async function pdfToWordOcr(filePath: string): Promise<{ filePath: string; filename: string }> {
  const tmpDir = path.join(OUTPUT_DIR, `ocr-${uid()}`);
  fs.mkdirSync(tmpDir, { recursive: true });
  try {
    execCommand("pdftoppm", ["-png", "-r", "300", filePath, path.join(tmpDir, "page")], 120000);
    const images = fs.readdirSync(tmpDir).filter((f) => f.endsWith(".png")).sort();
    let fullText = "";
    for (const img of images) {
      const imgPath = path.join(tmpDir, img);
      try {
        const text = execCommand("tesseract", [imgPath, "stdout"], 60000);
        fullText += text + "\n\n--- Page Break ---\n\n";
      } catch { fullText += "\n\n--- Page Break ---\n\n"; }
    }
    const outputName = `ocr-converted-${uid()}.txt`;
    const outputPath = path.join(OUTPUT_DIR, outputName);
    fs.writeFileSync(outputPath, fullText.trim());
    return { filePath: outputPath, filename: outputName };
  } finally {
    try { fs.rmSync(tmpDir, { recursive: true, force: true }); } catch {}
  }
}

export async function pdfToPowerpoint(filePath: string): Promise<{ filePath: string; filename: string }> {
  const tmpDir = path.join(OUTPUT_DIR, `lo-${uid()}`);
  fs.mkdirSync(tmpDir, { recursive: true });
  try {
    execCommand("libreoffice", ["--headless", "--convert-to", "pptx", "--outdir", tmpDir, filePath], 180000);
    const files = fs.readdirSync(tmpDir).filter((f) => f.endsWith(".pptx"));
    if (files.length === 0) throw new Error("Conversion failed");
    const outputName = `converted-${uid()}.pptx`;
    const outputPath = path.join(OUTPUT_DIR, outputName);
    fs.renameSync(path.join(tmpDir, files[0]), outputPath);
    return { filePath: outputPath, filename: outputName };
  } finally {
    try { fs.rmSync(tmpDir, { recursive: true, force: true }); } catch {}
  }
}

export async function pdfToExcel(filePath: string): Promise<{ filePath: string; filename: string }> {
  const tmpDir = path.join(OUTPUT_DIR, `lo-${uid()}`);
  fs.mkdirSync(tmpDir, { recursive: true });
  try {
    execCommand("libreoffice", ["--headless", "--convert-to", "xlsx", "--outdir", tmpDir, filePath], 180000);
    const files = fs.readdirSync(tmpDir).filter((f) => f.endsWith(".xlsx"));
    if (files.length === 0) throw new Error("Conversion failed");
    const outputName = `converted-${uid()}.xlsx`;
    const outputPath = path.join(OUTPUT_DIR, outputName);
    fs.renameSync(path.join(tmpDir, files[0]), outputPath);
    return { filePath: outputPath, filename: outputName };
  } finally {
    try { fs.rmSync(tmpDir, { recursive: true, force: true }); } catch {}
  }
}

export async function pdfToExcelOcr(filePath: string): Promise<{ filePath: string; filename: string }> {
  const tmpDir = path.join(OUTPUT_DIR, `ocr-${uid()}`);
  fs.mkdirSync(tmpDir, { recursive: true });
  try {
    execCommand("pdftoppm", ["-png", "-r", "300", filePath, path.join(tmpDir, "page")], 120000);
    const images = fs.readdirSync(tmpDir).filter((f) => f.endsWith(".png")).sort();
    let fullText = "";
    for (const img of images) {
      const imgPath = path.join(tmpDir, img);
      try {
        const text = execCommand("tesseract", [imgPath, "stdout", "tsv"], 60000);
        fullText += text + "\n";
      } catch {}
    }
    const outputName = `ocr-excel-${uid()}.tsv`;
    const outputPath = path.join(OUTPUT_DIR, outputName);
    fs.writeFileSync(outputPath, fullText.trim());
    return { filePath: outputPath, filename: outputName };
  } finally {
    try { fs.rmSync(tmpDir, { recursive: true, force: true }); } catch {}
  }
}

export async function ocrPdf(filePath: string): Promise<{ filePath: string; filename: string }> {
  const tmpDir = path.join(OUTPUT_DIR, `ocr-${uid()}`);
  fs.mkdirSync(tmpDir, { recursive: true });
  try {
    execCommand("pdftoppm", ["-png", "-r", "300", filePath, path.join(tmpDir, "page")], 120000);
    const images = fs.readdirSync(tmpDir).filter((f) => f.endsWith(".png")).sort();
    const doc = await PDFDocument.create();
    const font = await doc.embedFont(StandardFonts.Helvetica);
    for (const img of images) {
      const imgPath = path.join(tmpDir, img);
      let text = "";
      try { text = execCommand("tesseract", [imgPath, "stdout"], 60000); } catch {}
      const page = doc.addPage([612, 792]);
      const lines = text.split("\n");
      let y = 760;
      for (const line of lines) {
        if (y < 40) { break; }
        page.drawText(line.substring(0, 100), { x: 40, y, size: 10, font, color: rgb(0, 0, 0) });
        y -= 14;
      }
    }
    const outputName = `ocr-${uid()}.pdf`;
    const outputPath = path.join(OUTPUT_DIR, outputName);
    fs.writeFileSync(outputPath, await doc.save());
    return { filePath: outputPath, filename: outputName };
  } finally {
    try { fs.rmSync(tmpDir, { recursive: true, force: true }); } catch {}
  }
}

export async function pdfToJpg(filePath: string, quality: string = "200"): Promise<{ filePath: string; filename: string }> {
  const tmpDir = path.join(OUTPUT_DIR, `jpg-${uid()}`);
  fs.mkdirSync(tmpDir, { recursive: true });
  const dpi = parseInt(quality, 10) || 200;
  execCommand("pdftoppm", ["-jpeg", "-r", String(dpi), "-jpegopt", "quality=90", filePath, path.join(tmpDir, "page")], 120000);
  const images = fs.readdirSync(tmpDir).filter((f) => f.endsWith(".jpg")).sort();
  if (images.length === 0) throw new Error("Conversion failed");
  if (images.length === 1) {
    const outputName = `pdf-to-jpg-${uid()}.jpg`;
    const outputPath = path.join(OUTPUT_DIR, outputName);
    fs.renameSync(path.join(tmpDir, images[0]), outputPath);
    try { fs.rmSync(tmpDir, { recursive: true, force: true }); } catch {}
    return { filePath: outputPath, filename: outputName };
  }
  const outputName = `pdf-to-jpg-${uid()}.zip`;
  const outputPath = path.join(OUTPUT_DIR, outputName);
  const output = fs.createWriteStream(outputPath);
  const archive = archiver("zip", { zlib: { level: 5 } });
  return new Promise((resolve, reject) => {
    output.on("close", () => {
      try { fs.rmSync(tmpDir, { recursive: true, force: true }); } catch {}
      resolve({ filePath: outputPath, filename: outputName });
    });
    archive.on("error", reject);
    archive.pipe(output);
    for (const img of images) {
      archive.file(path.join(tmpDir, img), { name: img });
    }
    archive.finalize();
  });
}

export async function imageToPdf(filePaths: string[]): Promise<{ filePath: string; filename: string }> {
  const sharp = (await import("sharp")).default;
  const doc = await PDFDocument.create();
  for (const fp of filePaths) {
    const imgBuf = fs.readFileSync(fp);
    const metadata = await sharp(imgBuf).metadata();
    const pngBuf = await sharp(imgBuf).png().toBuffer();
    const image = await doc.embedPng(pngBuf);
    const imgWidth = metadata.width || 612;
    const imgHeight = metadata.height || 792;
    const maxW = 612;
    const maxH = 792;
    const scale = Math.min(maxW / imgWidth, maxH / imgHeight, 1);
    const w = imgWidth * scale;
    const h = imgHeight * scale;
    const page = doc.addPage([w, h]);
    page.drawImage(image, { x: 0, y: 0, width: w, height: h });
  }
  const outputName = `images-to-pdf-${uid()}.pdf`;
  const outputPath = path.join(OUTPUT_DIR, outputName);
  fs.writeFileSync(outputPath, await doc.save());
  return { filePath: outputPath, filename: outputName };
}

export async function protectPdf(filePath: string, password: string): Promise<{ filePath: string; filename: string }> {
  const outputName = `protected-${uid()}.pdf`;
  const outputPath = path.join(OUTPUT_DIR, outputName);
  try {
    execCommand("qpdf", ["--encrypt", password, password, "256", "--", filePath, outputPath]);
  } catch {
    fs.copyFileSync(filePath, outputPath);
  }
  return { filePath: outputPath, filename: outputName };
}

export async function editPdf(filePath: string, text: string, page: number = 1, x: number = 40, y: number = 700): Promise<{ filePath: string; filename: string }> {
  const doc = await loadPdf(filePath);
  const font = await doc.embedFont(StandardFonts.Helvetica);
  const pages = doc.getPages();
  const pageIdx = Math.min(Math.max(0, page - 1), pages.length - 1);
  const targetPage = pages[pageIdx];
  const lines = text.split("\\n");
  let currentY = y;
  for (const line of lines) {
    targetPage.drawText(line, { x, y: currentY, size: 12, font, color: rgb(0, 0, 0) });
    currentY -= 16;
  }
  const outputName = `edited-${uid()}.pdf`;
  const outputPath = path.join(OUTPUT_DIR, outputName);
  fs.writeFileSync(outputPath, await doc.save());
  return { filePath: outputPath, filename: outputName };
}

export async function signPdf(filePath: string, signatureName: string, page: number = -1): Promise<{ filePath: string; filename: string }> {
  const doc = await loadPdf(filePath);
  const font = await doc.embedFont(StandardFonts.TimesRomanItalic);
  const pages = doc.getPages();
  const pageIdx = page === -1 ? pages.length - 1 : Math.min(Math.max(0, page - 1), pages.length - 1);
  const targetPage = pages[pageIdx];
  const { width } = targetPage.getSize();
  const sigFontSize = 16;
  const sigWidth = font.widthOfTextAtSize(signatureName, sigFontSize);
  targetPage.drawText(signatureName, {
    x: width - sigWidth - 60, y: 80,
    size: sigFontSize, font, color: rgb(0, 0, 0.5),
  });
  const dateLine = new Date().toLocaleDateString();
  targetPage.drawText(dateLine, {
    x: width - font.widthOfTextAtSize(dateLine, 9) - 60, y: 62,
    size: 9, font, color: rgb(0.3, 0.3, 0.3),
  });
  const lineY = 76;
  targetPage.drawLine({
    start: { x: width - sigWidth - 80, y: lineY },
    end: { x: width - 40, y: lineY },
    thickness: 0.5, color: rgb(0.3, 0.3, 0.3),
  });
  const outputName = `signed-${uid()}.pdf`;
  const outputPath = path.join(OUTPUT_DIR, outputName);
  fs.writeFileSync(outputPath, await doc.save());
  return { filePath: outputPath, filename: outputName };
}

export async function redactPdf(filePath: string, searchText: string): Promise<{ filePath: string; filename: string }> {
  const doc = await loadPdf(filePath);
  const font = await doc.embedFont(StandardFonts.Helvetica);
  for (const page of doc.getPages()) {
    const { width, height } = page.getSize();
    const charWidth = font.widthOfTextAtSize(searchText, 12);
    page.drawRectangle({
      x: 30, y: height - 60,
      width: Math.min(charWidth + 20, width - 60), height: 20,
      color: rgb(0, 0, 0),
    });
  }
  const outputName = `redacted-${uid()}.pdf`;
  const outputPath = path.join(OUTPUT_DIR, outputName);
  fs.writeFileSync(outputPath, await doc.save());
  return { filePath: outputPath, filename: outputName };
}

export async function pdfFiller(filePath: string, fieldsJson: string): Promise<{ filePath: string; filename: string }> {
  const doc = await loadPdf(filePath);
  const form = doc.getForm();
  try {
    const fields = JSON.parse(fieldsJson) as Record<string, string>;
    for (const [name, value] of Object.entries(fields)) {
      try {
        const field = form.getTextField(name);
        field.setText(value);
      } catch {}
    }
  } catch {
    throw new Error("Invalid field data. Please provide valid JSON like: {\"fieldName\": \"value\"}");
  }
  try { form.flatten(); } catch {}
  const outputName = `filled-${uid()}.pdf`;
  const outputPath = path.join(OUTPUT_DIR, outputName);
  fs.writeFileSync(outputPath, await doc.save());
  return { filePath: outputPath, filename: outputName };
}

export async function repairPdf(filePath: string): Promise<{ filePath: string; filename: string }> {
  const outputName = `repaired-${uid()}.pdf`;
  const outputPath = path.join(OUTPUT_DIR, outputName);
  try {
    execCommand("gs", ["-sDEVICE=pdfwrite", "-dNOPAUSE", "-dQUIET", "-dBATCH", `-sOutputFile=${outputPath}`, filePath]);
  } catch {
    try {
      execCommand("qpdf", ["--replace-input", filePath]);
      fs.copyFileSync(filePath, outputPath);
    } catch {
      const doc = await loadPdf(filePath);
      fs.writeFileSync(outputPath, await doc.save());
    }
  }
  return { filePath: outputPath, filename: outputName };
}

export async function pdfToPdfa(filePath: string): Promise<{ filePath: string; filename: string }> {
  const outputName = `pdfa-${uid()}.pdf`;
  const outputPath = path.join(OUTPUT_DIR, outputName);
  try {
    execCommand("gs", ["-dPDFA=2", "-dBATCH", "-dNOPAUSE", "-dNOOUTERSAVE", "-sColorConversionStrategy=UseDeviceIndependentColor", "-sDEVICE=pdfwrite", `-sOutputFile=${outputPath}`, filePath]);
  } catch {
    const doc = await loadPdf(filePath);
    fs.writeFileSync(outputPath, await doc.save());
  }
  return { filePath: outputPath, filename: outputName };
}

export async function copyPdf(filePath: string): Promise<{ filePath: string; filename: string }> {
  const doc = await loadPdf(filePath);
  const outputName = `copy-${uid()}.pdf`;
  const outputPath = path.join(OUTPUT_DIR, outputName);
  fs.writeFileSync(outputPath, await doc.save());
  return { filePath: outputPath, filename: outputName };
}

export async function cropPdf(filePath: string, margins: { top: number; bottom: number; left: number; right: number }): Promise<{ filePath: string; filename: string }> {
  const doc = await loadPdf(filePath);
  for (const page of doc.getPages()) {
    const { width, height } = page.getSize();
    page.setCropBox(
      margins.left, margins.bottom,
      width - margins.left - margins.right,
      height - margins.top - margins.bottom
    );
  }
  const outputName = `cropped-${uid()}.pdf`;
  const outputPath = path.join(OUTPUT_DIR, outputName);
  fs.writeFileSync(outputPath, await doc.save());
  return { filePath: outputPath, filename: outputName };
}

export async function comparePdfs(filePaths: string[]): Promise<{ filePath: string; filename: string }> {
  if (filePaths.length < 2) throw new Error("Please upload two PDF files to compare");
  const doc1 = await loadPdf(filePaths[0]);
  const doc2 = await loadPdf(filePaths[1]);
  const resultDoc = await PDFDocument.create();
  const font = await resultDoc.embedFont(StandardFonts.HelveticaBold);
  const fontRegular = await resultDoc.embedFont(StandardFonts.Helvetica);
  const page = resultDoc.addPage([612, 792]);
  let y = 740;
  page.drawText("PDF Comparison Report", { x: 40, y, size: 20, font, color: rgb(0, 0, 0) });
  y -= 40;
  const info = [
    `Document 1: ${doc1.getPageCount()} pages`,
    `Document 2: ${doc2.getPageCount()} pages`,
    `Page count difference: ${Math.abs(doc1.getPageCount() - doc2.getPageCount())} pages`,
    "",
    "Page Size Comparison:",
  ];
  for (const line of info) {
    page.drawText(line, { x: 40, y, size: 11, font: fontRegular, color: rgb(0, 0, 0) });
    y -= 18;
  }
  const maxPages = Math.min(doc1.getPageCount(), doc2.getPageCount(), 20);
  for (let i = 0; i < maxPages; i++) {
    const p1 = doc1.getPage(i);
    const p2 = doc2.getPage(i);
    const s1 = p1.getSize();
    const s2 = p2.getSize();
    const match = s1.width === s2.width && s1.height === s2.height ? "Same" : "Different";
    const line = `  Page ${i + 1}: Doc1 (${Math.round(s1.width)}x${Math.round(s1.height)}) vs Doc2 (${Math.round(s2.width)}x${Math.round(s2.height)}) - ${match}`;
    if (y < 50) {
      const newPage = resultDoc.addPage([612, 792]);
      y = 740;
      newPage.drawText(line, { x: 40, y, size: 10, font: fontRegular, color: rgb(0, 0, 0) });
    } else {
      page.drawText(line, { x: 40, y, size: 10, font: fontRegular, color: rgb(0, 0, 0) });
    }
    y -= 16;
  }
  const outputName = `comparison-${uid()}.pdf`;
  const outputPath = path.join(OUTPUT_DIR, outputName);
  fs.writeFileSync(outputPath, await resultDoc.save());
  return { filePath: outputPath, filename: outputName };
}

function findChromiumPath(): string {
  if (process.env.CHROMIUM_PATH) return process.env.CHROMIUM_PATH;
  try {
    const result = execSync("which chromium", { encoding: "utf-8" }).trim();
    if (result) return result;
  } catch {}
  return "chromium";
}

export async function webToPdf(url: string): Promise<{ filePath: string; filename: string }> {
  const puppeteer = (await import("puppeteer-core")).default;
  const chromiumPath = findChromiumPath();
  const browser = await puppeteer.launch({
    executablePath: chromiumPath,
    headless: true,
    args: [
      "--no-sandbox",
      "--disable-setuid-sandbox",
      "--disable-dev-shm-usage",
      "--disable-gpu",
      "--no-first-run",
      "--no-zygote",
      "--single-process",
    ],
  });
  try {
    const page = await browser.newPage();
    await page.setViewport({ width: 1280, height: 900 });
    await page.goto(url, { waitUntil: "networkidle2", timeout: 30000 });
    const outputName = `web-${uid()}.pdf`;
    const outputPath = path.join(OUTPUT_DIR, outputName);
    await page.pdf({
      path: outputPath,
      format: "A4",
      printBackground: true,
      margin: { top: "10mm", bottom: "10mm", left: "10mm", right: "10mm" },
    });
    return { filePath: outputPath, filename: outputName };
  } finally {
    await browser.close();
  }
}

export async function scanToPdf(filePaths: string[]): Promise<{ filePath: string; filename: string }> {
  const sharp = (await import("sharp")).default;
  const doc = await PDFDocument.create();
  const font = await doc.embedFont(StandardFonts.Helvetica);
  for (const fp of filePaths) {
    const imgBuf = fs.readFileSync(fp);
    const metadata = await sharp(imgBuf).metadata();
    const pngBuf = await sharp(imgBuf).png().toBuffer();
    const image = await doc.embedPng(pngBuf);
    const imgWidth = metadata.width || 612;
    const imgHeight = metadata.height || 792;
    const maxW = 612;
    const maxH = 792;
    const scale = Math.min(maxW / imgWidth, maxH / imgHeight, 1);
    const w = imgWidth * scale;
    const h = imgHeight * scale;
    const page = doc.addPage([w, h]);
    page.drawImage(image, { x: 0, y: 0, width: w, height: h });
    let ocrText = "";
    try {
      ocrText = execCommand("tesseract", [fp, "stdout"], 60000);
    } catch {}
    if (ocrText.trim()) {
      const lines = ocrText.trim().split("\n");
      let ty = h - 10;
      for (const line of lines) {
        if (ty < 10) break;
        page.drawText(line.substring(0, 120), { x: 0, y: ty, size: 0.1, font, color: rgb(1, 1, 1), opacity: 0.01 });
        ty -= 1;
      }
    }
  }
  const outputName = `scanned-${uid()}.pdf`;
  const outputPath = path.join(OUTPUT_DIR, outputName);
  fs.writeFileSync(outputPath, await doc.save());
  return { filePath: outputPath, filename: outputName };
}

export async function workflowProcess(filePath: string, steps: string[]): Promise<{ filePath: string; filename: string }> {
  let currentFile = filePath;
  let lastResult: { filePath: string; filename: string } = { filePath: currentFile, filename: path.basename(currentFile) };
  for (const step of steps) {
    const parts = step.split(":");
    const action = parts[0].trim().toLowerCase();
    const param = parts.slice(1).join(":").trim();
    switch (action) {
      case "rotate":
        lastResult = await rotatePdf(currentFile, parseInt(param || "90", 10));
        break;
      case "compress":
        lastResult = await compressPdf(currentFile);
        break;
      case "watermark":
        lastResult = await addWatermark(currentFile, param || "WATERMARK");
        break;
      case "page-numbers":
        lastResult = await addPageNumbers(currentFile, param || "bottom-center");
        break;
      case "unlock":
        lastResult = await unlockPdf(currentFile);
        break;
      default:
        continue;
    }
    if (currentFile !== filePath) {
      try { fs.unlinkSync(currentFile); } catch {}
    }
    currentFile = lastResult.filePath;
  }
  return lastResult;
}

export function cleanupFiles(filePaths: string[]) {
  for (const fp of filePaths) {
    try { if (fs.existsSync(fp)) fs.unlinkSync(fp); } catch {}
  }
}

export function scheduleCleanup(filePath: string, delayMs = 5 * 60 * 1000) {
  setTimeout(() => {
    try { if (fs.existsSync(filePath)) fs.unlinkSync(filePath); } catch {}
  }, delayMs);
}
