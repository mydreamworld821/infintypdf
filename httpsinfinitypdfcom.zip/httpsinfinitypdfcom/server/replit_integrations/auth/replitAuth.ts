import session from "express-session";
import type { Express, RequestHandler } from "express";
import connectPg from "connect-pg-simple";
import { authStorage } from "./storage";

export function getSession() {
  const sessionTtl = 7 * 24 * 60 * 60 * 1000; // 1 week
  const pgStore = connectPg(session);
  const sessionStore = new pgStore({
    conString: process.env.DATABASE_URL,
    createTableIfMissing: false,
    ttl: sessionTtl,
    tableName: "sessions",
  });
  return session({
    secret: process.env.SESSION_SECRET || "infinitypdf-secret-key-change-in-production",
    store: sessionStore,
    resave: false,
    saveUninitialized: false,
    proxy: true,
    cookie: {
      httpOnly: true,
      secure: "auto" as any,
      sameSite: "lax",
      maxAge: sessionTtl,
    },
  });
}

export async function setupAuth(app: Express) {
  app.set("trust proxy", 1);
  app.use(getSession());

  app.use(async (req: any, _res, next) => {
    if (req.session?.localUser?.id) {
      try {
        const user = await authStorage.getUser(req.session.localUser.id);
        if (user) {
          req.user = user;
        }
      } catch {}
    }
    next();
  });
}

export const isAuthenticated: RequestHandler = async (req, res, next) => {
  const localUser = (req.session as any)?.localUser;
  if (!localUser?.id) {
    return res.status(401).json({ message: "Unauthorized" });
  }
  return next();
};
