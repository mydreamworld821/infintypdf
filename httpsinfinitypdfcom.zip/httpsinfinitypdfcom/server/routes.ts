import type { Express, Request, Response } from "express";
import { createServer, type Server } from "http";
import multer from "multer";
import path from "path";
import fs from "fs";
import { randomUUID } from "crypto";
import { setupAuth, registerAuthRoutes } from "./replit_integrations/auth";
import { storage as dbStorage } from "./storage";
import {
  mergePdfs, splitPdf, rotatePdf, compressPdf, addWatermark, addPageNumbers,
  unlockPdf, removePages, reorderPages, organizePages, officeToPdf, pdfToWord,
  pdfToWordOcr, pdfToPowerpoint, pdfToExcel, pdfToExcelOcr, ocrPdf, pdfToJpg,
  imageToPdf, protectPdf, editPdf, signPdf, redactPdf, pdfFiller, repairPdf,
  pdfToPdfa, copyPdf, cropPdf, comparePdfs, webToPdf, scanToPdf, workflowProcess,
  cleanupFiles, scheduleCleanup, getOutputDir,
} from "./pdf-processor";

const UPLOAD_DIR = path.join(process.cwd(), "uploads");
if (!fs.existsSync(UPLOAD_DIR)) fs.mkdirSync(UPLOAD_DIR, { recursive: true });

const PREMIUM_TOOLS = [
  "pdf-to-word-ocr", "pdf-to-excel-ocr", "ocr", "redact", "pdf-filler",
  "pdf-to-pdfa", "compare", "workflow", "web-to-pdf", "sign-pdf",
  "watermark", "edit-pdf", "crop",
];

const TOOL_NAMES: Record<string, string> = {
  "merge": "Merge PDF", "split": "Split PDF", "rotate": "Rotate PDF",
  "compress": "Compress PDF", "watermark": "Watermark", "page-numbers": "Page Numbers",
  "unlock": "Unlock PDF", "remove-pages": "Remove Pages", "reorder-pages": "Reorder Pages",
  "organize-pages": "Organize Pages", "office-to-pdf": "Office to PDF",
  "word-to-pdf": "Word to PDF", "powerpoint-to-pdf": "PowerPoint to PDF",
  "excel-to-pdf": "Excel to PDF", "pdf-to-word": "PDF to Word",
  "pdf-to-word-ocr": "PDF to Word (OCR)", "pdf-to-powerpoint": "PDF to PowerPoint",
  "pdf-to-excel": "PDF to Excel", "pdf-to-excel-ocr": "PDF to Excel (OCR)",
  "ocr": "OCR PDF", "pdf-to-jpg": "PDF to JPG", "image-to-pdf": "Image to PDF",
  "edit-pdf": "Edit PDF", "sign-pdf": "Sign PDF", "redact": "Redact PDF",
  "pdf-filler": "PDF Filler", "protect": "Protect PDF", "repair": "Repair PDF",
  "pdf-to-pdfa": "PDF to PDF/A", "copy-pdf": "Copy PDF", "crop": "Crop PDF",
  "compare": "Compare PDF", "web-to-pdf": "Web to PDF", "scan-to-pdf": "Scan to PDF",
  "workflow": "Workflow",
};

const TOOL_SLUGS: Record<string, string> = {
  "merge": "merge-pdf", "split": "split-pdf", "rotate": "rotate-pdf",
  "compress": "compress-pdf", "watermark": "watermark-pdf", "page-numbers": "add-page-numbers-pdf",
  "unlock": "unlock-pdf", "remove-pages": "remove-pdf-pages", "reorder-pages": "reorder-pdf-pages",
  "organize-pages": "organize-pdf-pages", "office-to-pdf": "office-to-pdf",
  "word-to-pdf": "word-to-pdf", "powerpoint-to-pdf": "powerpoint-to-pdf",
  "excel-to-pdf": "excel-to-pdf", "pdf-to-word": "pdf-to-word",
  "pdf-to-word-ocr": "pdf-to-word-ocr", "pdf-to-powerpoint": "pdf-to-powerpoint",
  "pdf-to-excel": "pdf-to-excel", "pdf-to-excel-ocr": "pdf-to-excel-ocr",
  "ocr": "ocr-pdf", "pdf-to-jpg": "pdf-to-jpg", "image-to-pdf": "image-to-pdf",
  "edit-pdf": "edit-pdf", "sign-pdf": "sign-pdf", "redact": "redact-pdf",
  "pdf-filler": "pdf-filler", "protect": "protect-pdf", "repair": "repair-pdf",
  "pdf-to-pdfa": "pdf-to-pdfa", "copy-pdf": "copy-pdf", "crop": "crop-pdf",
  "compare": "compare-pdf", "web-to-pdf": "html-to-pdf", "scan-to-pdf": "scan-to-pdf",
  "workflow": "pdf-workflow",
};

function requireAuth(req: Request, res: Response): string | null {
  const user = (req as any).user;
  if (!user?.id) {
    res.status(401).json({ message: "Authentication required" });
    return null;
  }
  return user.id;
}

function requireAdmin(req: Request, res: Response): string | null {
  const user = (req as any).user;
  if (!user?.id) {
    res.status(401).json({ message: "Authentication required" });
    return null;
  }
  if (!user.isAdmin) {
    res.status(403).json({ message: "Admin access required" });
    return null;
  }
  return user.id;
}

const pdfOnlyFilter = (_req: any, file: Express.Multer.File, cb: multer.FileFilterCallback) => {
  if (file.mimetype === "application/pdf") {
    cb(null, true);
  } else {
    cb(new Error("Only PDF files are allowed"));
  }
};

const anyFileFilter = (_req: any, _file: Express.Multer.File, cb: multer.FileFilterCallback) => {
  cb(null, true);
};

const multerStorage = multer.diskStorage({
  destination: (_req, _file, cb) => cb(null, UPLOAD_DIR),
  filename: (_req, file, cb) => {
    const ext = path.extname(file.originalname);
    cb(null, `${randomUUID()}${ext}`);
  },
});

const uploadPdf = multer({ storage: multerStorage, fileFilter: pdfOnlyFilter, limits: { fileSize: 50 * 1024 * 1024 } });
const uploadAny = multer({ storage: multerStorage, fileFilter: anyFileFilter, limits: { fileSize: 50 * 1024 * 1024 } });

const OFFICE_TOOLS = ["office-to-pdf", "word-to-pdf", "powerpoint-to-pdf", "excel-to-pdf"];
const IMAGE_TOOLS = ["image-to-pdf", "scan-to-pdf"];
const NON_PDF_INPUT_TOOLS = [...OFFICE_TOOLS, ...IMAGE_TOOLS];

export async function registerRoutes(
  httpServer: Server,
  app: Express
): Promise<Server> {
  await setupAuth(app);
  registerAuthRoutes(app);

  app.get("/api/jobs/me", async (req, res) => {
    const userId = requireAuth(req, res);
    if (!userId) return;
    const jobs = await dbStorage.getJobsByUser(userId);
    res.json(jobs);
  });

  app.post("/api/orders", async (req, res) => {
    const userId = requireAuth(req, res);
    if (!userId) return;
    const { planId, billingCycle, paymentReference } = req.body;
    if (!planId || !billingCycle) {
      return res.status(400).json({ message: "Plan and billing cycle are required" });
    }
    const amount = planId === "premium"
      ? (billingCycle === "yearly" ? 4800 : 700)
      : 0;
    const order = await dbStorage.createOrder({
      userId,
      planId,
      billingCycle,
      amount,
      currency: "USD",
      status: "pending",
      paymentReference: paymentReference || null,
    });
    res.json(order);
  });

  app.get("/api/orders/me", async (req, res) => {
    const userId = requireAuth(req, res);
    if (!userId) return;
    const userOrders = await dbStorage.getOrdersByUser(userId);
    res.json(userOrders);
  });

  app.get("/api/admin/orders", async (req, res) => {
    if (!requireAdmin(req, res)) return;
    const allOrders = await dbStorage.getAllOrders();
    res.json(allOrders);
  });

  app.patch("/api/admin/orders/:id", async (req, res) => {
    if (!requireAdmin(req, res)) return;
    const { status, adminNote } = req.body;
    if (!status) return res.status(400).json({ message: "Status is required" });
    const order = await dbStorage.updateOrderStatus(req.params.id, status, adminNote);
    if (status === "approved") {
      await dbStorage.updateUserPremiumStatus(order.userId, "active");
    } else if (status === "rejected") {
      await dbStorage.updateUserPremiumStatus(order.userId, "rejected");
    }
    res.json(order);
  });

  app.get("/api/admin/users", async (req, res) => {
    if (!requireAdmin(req, res)) return;
    const allUsers = await dbStorage.getAllUsers();
    const safeUsers = allUsers.map(({ passwordHash, ...u }) => u);
    res.json(safeUsers);
  });

  app.patch("/api/admin/users/:id/premium", async (req, res) => {
    if (!requireAdmin(req, res)) return;
    const { premiumStatus } = req.body;
    if (!premiumStatus) return res.status(400).json({ message: "Premium status is required" });
    const user = await dbStorage.updateUserPremiumStatus(req.params.id, premiumStatus);
    const { passwordHash, ...safeUser } = user;
    res.json(safeUser);
  });

  app.post("/api/merge/ad-unlock", (req: any, res) => {
    if (!req.session) {
      return res.status(400).json({ message: "Session required" });
    }
    req.session.mergeAdUnlocked = true;
    req.session.mergeAdUnlockedAt = Date.now();
    res.json({ success: true, expiresIn: "session" });
  });

  app.get("/api/merge/ad-status", (req: any, res) => {
    const unlocked = req.session?.mergeAdUnlocked === true;
    res.json({ adUnlocked: unlocked });
  });

  app.post("/api/pdf/process", uploadAny.array("files", 30), async (req, res) => {
    const files = req.files as Express.Multer.File[];
    const toolId = req.body.toolId;
    const user = (req as any).user;

    if (PREMIUM_TOOLS.includes(toolId)) {
      if (!user?.id) {
        if (files) cleanupFiles(files.map(f => f.path));
        return res.status(401).json({ message: "Please sign in to use premium tools" });
      }
      if (user.premiumStatus !== "active") {
        if (files) cleanupFiles(files.map(f => f.path));
        return res.status(403).json({ message: "This is a premium tool. Please upgrade your plan to use it." });
      }
    }

    let jobId: string | null = null;
    if (user?.id) {
      const inputFileNames = files ? files.map(f => f.originalname) : [req.body.url || "web-page"];
      const job = await dbStorage.createJob({
        userId: user.id,
        toolId,
        toolName: TOOL_NAMES[toolId] || toolId,
        inputFiles: inputFileNames,
        status: "processing",
      });
      jobId = job.id;
    }

    if (toolId === "web-to-pdf") {
      const url = (req.body.url || "").trim();
      if (!url) {
        if (jobId) await dbStorage.updateJobStatus(jobId, "failed");
        return res.status(400).json({ message: "URL is required" });
      }
      try {
        const parsed = new URL(url);
        if (!["http:", "https:"].includes(parsed.protocol)) {
          if (jobId) await dbStorage.updateJobStatus(jobId, "failed");
          return res.status(400).json({ message: "Only http and https URLs are allowed" });
        }
        const hostname = parsed.hostname;
        if (hostname === "localhost" || hostname === "127.0.0.1" || hostname === "0.0.0.0" || hostname.startsWith("10.") || hostname.startsWith("192.168.") || hostname.startsWith("172.") || hostname === "::1" || hostname === "[::1]") {
          if (jobId) await dbStorage.updateJobStatus(jobId, "failed");
          return res.status(400).json({ message: "Private/internal URLs are not allowed" });
        }
        const result = await webToPdf(url);
        scheduleCleanup(result.filePath);
        if (jobId) await dbStorage.updateJobStatus(jobId, "completed", result.filename);
        return res.json({ downloadUrl: `/api/pdf/download/${result.filename}`, filename: result.filename });
      } catch (err: any) {
        if (jobId) await dbStorage.updateJobStatus(jobId, "failed");
        if (err.message?.includes("not allowed")) return res.status(400).json({ message: err.message });
        return res.status(500).json({ message: err.message || "Failed to convert web page" });
      }
    }

    if (!files || files.length === 0) {
      if (jobId) await dbStorage.updateJobStatus(jobId, "failed");
      return res.status(400).json({ message: "No files uploaded" });
    }

    const filePaths = files.map((f) => f.path);

    const PDF_ONLY_TOOLS = [
      "merge", "split", "rotate", "compress", "watermark", "page-numbers", "unlock",
      "remove-pages", "reorder-pages", "organize-pages", "pdf-to-word", "pdf-to-word-ocr",
      "pdf-to-powerpoint", "pdf-to-excel", "pdf-to-excel-ocr", "ocr", "pdf-to-jpg",
      "protect", "edit-pdf", "sign-pdf", "redact", "pdf-filler", "repair", "pdf-to-pdfa",
      "copy-pdf", "crop", "compare", "workflow",
    ];
    if (PDF_ONLY_TOOLS.includes(toolId)) {
      const invalidFiles = files.filter((f) => f.mimetype !== "application/pdf" && !f.originalname.toLowerCase().endsWith(".pdf"));
      if (invalidFiles.length > 0) {
        cleanupFiles(filePaths);
        if (jobId) await dbStorage.updateJobStatus(jobId, "failed");
        return res.status(400).json({ message: "This tool requires PDF files only" });
      }
    }

    try {
      let result: { filePath: string; filename: string };

      switch (toolId) {
        case "merge": {
          if (filePaths.length < 2) {
            cleanupFiles(filePaths);
            if (jobId) await dbStorage.updateJobStatus(jobId, "failed");
            return res.status(400).json({ message: "Please upload at least 2 PDF files to merge" });
          }
          const FREE_MERGE_LIMIT = 10;
          const AD_MERGE_LIMIT = 30;
          const isPremium = user?.premiumStatus === "active";
          const hasAdUnlock = (req as any).session?.mergeAdUnlocked === true;
          const mergeLimit = isPremium ? Infinity : hasAdUnlock ? AD_MERGE_LIMIT : FREE_MERGE_LIMIT;
          if (filePaths.length > mergeLimit) {
            cleanupFiles(filePaths);
            if (jobId) await dbStorage.updateJobStatus(jobId, "failed");
            const limitMsg = hasAdUnlock
              ? `Ad unlock allows up to ${AD_MERGE_LIMIT} files. Upgrade to Premium for unlimited merging.`
              : `Free users can merge up to ${FREE_MERGE_LIMIT} files. Watch an ad to unlock ${AD_MERGE_LIMIT} files or upgrade to Premium.`;
            return res.status(403).json({ message: limitMsg });
          }
          result = await mergePdfs(filePaths);
          break;
        }
        case "split":
          result = await splitPdf(filePaths[0], req.body.splitPages || "all");
          break;
        case "rotate":
          result = await rotatePdf(filePaths[0], parseInt(req.body.angle || "90", 10));
          break;
        case "compress":
          result = await compressPdf(filePaths[0]);
          break;
        case "watermark":
          if (!req.body.watermarkText?.trim()) {
            cleanupFiles(filePaths);
            if (jobId) await dbStorage.updateJobStatus(jobId, "failed");
            return res.status(400).json({ message: "Watermark text is required" });
          }
          result = await addWatermark(filePaths[0], req.body.watermarkText);
          break;
        case "page-numbers":
          result = await addPageNumbers(filePaths[0], req.body.position || "bottom-center");
          break;
        case "unlock":
          result = await unlockPdf(filePaths[0]);
          break;
        case "remove-pages":
          if (!req.body.pagesToRemove?.trim()) {
            cleanupFiles(filePaths);
            if (jobId) await dbStorage.updateJobStatus(jobId, "failed");
            return res.status(400).json({ message: "Please specify pages to remove" });
          }
          result = await removePages(filePaths[0], req.body.pagesToRemove);
          break;
        case "reorder-pages":
        case "organize-pages":
          if (!req.body.pageOrder?.trim()) {
            cleanupFiles(filePaths);
            if (jobId) await dbStorage.updateJobStatus(jobId, "failed");
            return res.status(400).json({ message: "Please specify page order" });
          }
          result = await reorderPages(filePaths[0], req.body.pageOrder);
          break;
        case "office-to-pdf":
        case "word-to-pdf":
        case "powerpoint-to-pdf":
        case "excel-to-pdf":
          result = await officeToPdf(filePaths[0]);
          break;
        case "pdf-to-word":
          result = await pdfToWord(filePaths[0]);
          break;
        case "pdf-to-word-ocr":
          result = await pdfToWordOcr(filePaths[0]);
          break;
        case "pdf-to-powerpoint":
          result = await pdfToPowerpoint(filePaths[0]);
          break;
        case "pdf-to-excel":
          result = await pdfToExcel(filePaths[0]);
          break;
        case "pdf-to-excel-ocr":
          result = await pdfToExcelOcr(filePaths[0]);
          break;
        case "ocr":
          result = await ocrPdf(filePaths[0]);
          break;
        case "pdf-to-jpg":
          result = await pdfToJpg(filePaths[0], req.body.quality || "200");
          break;
        case "image-to-pdf":
          result = await imageToPdf(filePaths);
          break;
        case "protect":
          if (!req.body.password?.trim()) {
            cleanupFiles(filePaths);
            if (jobId) await dbStorage.updateJobStatus(jobId, "failed");
            return res.status(400).json({ message: "Password is required" });
          }
          result = await protectPdf(filePaths[0], req.body.password);
          break;
        case "edit-pdf":
          result = await editPdf(
            filePaths[0],
            req.body.editText || "Sample Text",
            parseInt(req.body.editPage || "1", 10),
            parseInt(req.body.editX || "40", 10),
            parseInt(req.body.editY || "700", 10)
          );
          break;
        case "sign-pdf":
          if (!req.body.signatureName?.trim()) {
            cleanupFiles(filePaths);
            if (jobId) await dbStorage.updateJobStatus(jobId, "failed");
            return res.status(400).json({ message: "Signature name is required" });
          }
          result = await signPdf(filePaths[0], req.body.signatureName);
          break;
        case "redact":
          if (!req.body.redactText?.trim()) {
            cleanupFiles(filePaths);
            if (jobId) await dbStorage.updateJobStatus(jobId, "failed");
            return res.status(400).json({ message: "Text to redact is required" });
          }
          result = await redactPdf(filePaths[0], req.body.redactText);
          break;
        case "pdf-filler":
          if (!req.body.fieldData?.trim()) {
            cleanupFiles(filePaths);
            if (jobId) await dbStorage.updateJobStatus(jobId, "failed");
            return res.status(400).json({ message: "Field data is required" });
          }
          result = await pdfFiller(filePaths[0], req.body.fieldData);
          break;
        case "repair":
          result = await repairPdf(filePaths[0]);
          break;
        case "pdf-to-pdfa":
          result = await pdfToPdfa(filePaths[0]);
          break;
        case "copy-pdf":
          result = await copyPdf(filePaths[0]);
          break;
        case "crop":
          result = await cropPdf(filePaths[0], {
            top: parseInt(req.body.cropTop || "0", 10),
            bottom: parseInt(req.body.cropBottom || "0", 10),
            left: parseInt(req.body.cropLeft || "0", 10),
            right: parseInt(req.body.cropRight || "0", 10),
          });
          break;
        case "compare":
          if (filePaths.length < 2) {
            cleanupFiles(filePaths);
            if (jobId) await dbStorage.updateJobStatus(jobId, "failed");
            return res.status(400).json({ message: "Please upload 2 PDF files to compare" });
          }
          result = await comparePdfs(filePaths);
          break;
        case "scan-to-pdf":
          result = await scanToPdf(filePaths);
          break;
        case "workflow":
          if (!req.body.workflowSteps?.trim()) {
            cleanupFiles(filePaths);
            if (jobId) await dbStorage.updateJobStatus(jobId, "failed");
            return res.status(400).json({ message: "Workflow steps are required" });
          }
          result = await workflowProcess(filePaths[0], req.body.workflowSteps.split("\n").filter((s: string) => s.trim()));
          break;
        default:
          cleanupFiles(filePaths);
          if (jobId) await dbStorage.updateJobStatus(jobId, "failed");
          return res.status(400).json({ message: "Unknown tool" });
      }

      cleanupFiles(filePaths);
      scheduleCleanup(result.filePath);

      if (jobId) await dbStorage.updateJobStatus(jobId, "completed", result.filename);

      res.json({
        downloadUrl: `/api/pdf/download/${result.filename}`,
        filename: result.filename,
      });
    } catch (err: any) {
      cleanupFiles(filePaths);
      if (jobId) await dbStorage.updateJobStatus(jobId, "failed");
      console.error("PDF processing error:", err);
      res.status(500).json({ message: err.message || "Failed to process PDF" });
    }
  });

  app.get("/robots.txt", (_req, res) => {
    res.type("text/plain").send(
      `User-agent: *\nAllow: /\nSitemap: https://infinitypdf.com/sitemap.xml\n`
    );
  });

  app.get("/sitemap.xml", (_req, res) => {
    const toolSlugs = Object.values(TOOL_SLUGS);
    const staticPages = [
      "", "features", "pricing", "faq", "security", "privacy",
      "terms", "cookies", "about", "contact", "blog", "press", "solutions", "auth",
    ];
    const today = new Date().toISOString().split("T")[0];
    const urls = [
      ...staticPages.map((p) => `  <url>\n    <loc>https://infinitypdf.com/${p}</loc>\n    <lastmod>${today}</lastmod>\n    <changefreq>${p === "" ? "daily" : "weekly"}</changefreq>\n    <priority>${p === "" ? "1.0" : "0.7"}</priority>\n  </url>`),
      ...toolSlugs.map((slug) => `  <url>\n    <loc>https://infinitypdf.com/${slug}</loc>\n    <lastmod>${today}</lastmod>\n    <changefreq>weekly</changefreq>\n    <priority>0.8</priority>\n  </url>`),
    ];
    res.type("application/xml").send(
      `<?xml version="1.0" encoding="UTF-8"?>\n<urlset xmlns="http://www.sitemaps.org/schemas/sitemap/0.9">\n${urls.join("\n")}\n</urlset>`
    );
  });

  app.get("/api/pdf/download/:filename", (req, res) => {
    const filename = req.params.filename;
    if (!filename || filename.includes("..")) {
      return res.status(400).json({ message: "Invalid filename" });
    }
    const filePath = path.join(getOutputDir(), filename);
    if (!fs.existsSync(filePath)) {
      return res.status(404).json({ message: "File not found or expired" });
    }
    res.download(filePath, filename);
  });

  return httpServer;
}
